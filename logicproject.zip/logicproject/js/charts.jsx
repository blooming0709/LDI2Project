/* ============ charts.jsx : hand-made animated SVG charts (no libraries) ============ */
const niceMax = (v) => {
  if (!isFinite(v) || v <= 0) return 10;
  const p = Math.pow(10, Math.floor(Math.log10(v))), n = v / p;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p;
};
const polar = (cx, cy, r, a) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
function slicePath(cx, cy, r, a0, a1, ri = 0) {
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const [x0, y0] = polar(cx, cy, r, a0), [x1, y1] = polar(cx, cy, r, a1);
  if (ri > 0) {
    const [x2, y2] = polar(cx, cy, ri, a1), [x3, y3] = polar(cx, cy, ri, a0);
    return `M${x0} ${y0}A${r} ${r} 0 ${large} 1 ${x1} ${y1}L${x2} ${y2}A${ri} ${ri} 0 ${large} 0 ${x3} ${y3}Z`;
  }
  return `M${cx} ${cy}L${x0} ${y0}A${r} ${r} 0 ${large} 1 ${x1} ${y1}Z`;
}
function Legend({ items }) {
  return <div className="legend">{items.map((it, i) => <span key={i}><i style={{ background: it.color }} />{it.label}</span>)}</div>;
}
const Defs = () => (
  <defs>
    {PALETTE.map((c, i) => (
      <linearGradient key={i} id={'bgrad' + i} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={c} /><stop offset="1" stopColor={c} stopOpacity=".55" />
      </linearGradient>
    ))}
    <linearGradient id="areag" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#029EFF" stopOpacity=".45" /><stop offset="1" stopColor="#029EFF" stopOpacity="0" /></linearGradient>
  </defs>
);

/* ---------- Bar chart (single or grouped) ---------- */
function BarChart({ labels, series, unit = '', showValues = true }) {
  const W = 640, H = 340, m = { l: 52, r: 16, t: 26, b: 44 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const mounted = useMounted();
  const [hv, setHv] = useState(null);
  const max = niceMax(Math.max(...series.flatMap((s) => s.values), 5));
  const gw = iw / labels.length, bw = Math.min(54, (gw * 0.72) / series.length);
  const y = (v) => m.t + ih - (v / max) * ih;
  return (
    <div className="chart-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="chart"><Defs />
        {[0, 1, 2, 3, 4, 5].map((i) => { const v = (max * i) / 5; return (
          <g key={i}><line x1={m.l} x2={W - m.r} y1={y(v)} y2={y(v)} className="grid" /><text x={m.l - 8} y={y(v) + 4} textAnchor="end" className="ax">{fmt(v, 1)}</text></g>); })}
        <line x1={m.l} x2={W - m.r} y1={m.t + ih} y2={m.t + ih} className="axl" />
        {labels.map((lb, i) => (
          <g key={i}>
            {series.map((s, si) => {
              const v = s.values[i] || 0;
              const x = m.l + gw * i + (gw - bw * series.length) / 2 + bw * si;
              const ci = series.length === 1 ? i % 8 : si;
              return (
                <g key={si}>
                  <g style={{ transform: `scaleY(${mounted ? 1 : 0})`, transformOrigin: `${x}px ${m.t + ih}px`, transition: `transform .8s cubic-bezier(.2,.9,.3,1.15) ${i * 70 + si * 40}ms` }}>
                    <rect x={x} y={y(v)} width={bw - 3} height={Math.max(0, ih * (v / max))} rx="6" fill={`url(#bgrad${ci})`}
                      className={'bar' + (hv && hv.i === i && hv.si === si ? ' active' : '')}
                      onMouseEnter={() => setHv({ i, si, x: x + (bw - 3) / 2 })} onMouseLeave={() => setHv(null)} />
                  </g>
                  {showValues && <text x={x + (bw - 3) / 2} y={y(v) - 6} textAnchor="middle" className="val"
                    style={{ opacity: mounted ? 1 : 0, transition: `opacity .5s ${900 + i * 60}ms` }}>{fmt(v, 1)}</text>}
                </g>
              );
            })}
            <text x={m.l + gw * i + gw / 2} y={H - m.b + 20} textAnchor="middle" className="ax">{lb}</text>
          </g>
        ))}
        {hv && (() => {
          const v = series[hv.si].values[hv.i] || 0;
          const txt = `${labels[hv.i]}: ${fmt(v)}${unit}`, w = txt.length * 7 + 18;
          return <g className="tip" transform={`translate(${Math.min(Math.max(hv.x - w / 2, 2), W - w - 2)},${Math.max(y(v) - 44, 2)})`}>
            <rect width={w} height="26" rx="8" /><text x={w / 2} y="17" textAnchor="middle">{txt}</text></g>;
        })()}
      </svg>
      {series.length > 1 && <Legend items={series.map((s, i) => ({ label: s.name, color: PALETTE[i] }))} />}
    </div>
  );
}

/* ---------- Pie / donut chart ---------- */
function PieChart({ labels, values, donut = false, unit = '' }) {
  const mounted = useMounted();
  const [hv, setHv] = useState(null);
  const total = sum(values) || 1, cx = 160, cy = 160, r = 130, ri = donut ? 70 : 0;
  let acc = -Math.PI / 2;
  const slices = values.map((v, i) => { const a0 = acc; acc += (v / total) * 2 * Math.PI; return { i, v, a0, a1: acc, mid: (a0 + acc) / 2 }; });
  return (
    <div className="pie-wrap">
      <svg viewBox="0 0 320 320" className="chart pie">
        {slices.map((s) => {
          const a1 = s.a1 - s.a0 >= 2 * Math.PI - 1e-4 ? s.a0 + 2 * Math.PI - 1e-4 : s.a1;
          const act = hv === s.i, dx = Math.cos(s.mid) * (act ? 10 : 0), dy = Math.sin(s.mid) * (act ? 10 : 0);
          const lr = donut ? (r + ri) / 2 : r * 0.66, [lx, ly] = polar(cx, cy, lr, s.mid);
          return (
            <g key={s.i} style={{ transform: `translate(${dx}px,${dy}px) scale(${mounted ? 1 : 0.1})`, transformOrigin: '160px 160px', opacity: mounted ? 1 : 0, transition: `transform .7s cubic-bezier(.2,.9,.3,1.2) ${s.i * 90}ms, opacity .5s ${s.i * 90}ms` }}>
              <path d={slicePath(cx, cy, r, s.a0, a1, ri)} fill={PALETTE[s.i % 8]} stroke="var(--bg2)" strokeWidth="2" className="slice"
                onMouseEnter={() => setHv(s.i)} onMouseLeave={() => setHv(null)} />
              {s.v / total > 0.04 && <text x={lx} y={ly + 4} textAnchor="middle" className="pl">{Math.round((s.v / total) * 100)}%</text>}
            </g>
          );
        })}
        {donut && <text x="160" y="166" textAnchor="middle" className="val" style={{ fontSize: 18 }}>Total {fmt(total, 1)}</text>}
      </svg>
      <div className="legend">{slices.map((s) => (
        <span key={s.i} className={hv === s.i ? 'on' : ''} onMouseEnter={() => setHv(s.i)} onMouseLeave={() => setHv(null)}>
          <i style={{ background: PALETTE[s.i % 8] }} />{labels[s.i]}: {fmt(s.v)}{unit} ({fmt((s.v / total) * 100, 1)}%)</span>))}</div>
    </div>
  );
}

/* ---------- Line chart (multi-series, optional predicted tail) ---------- */
function LineChart({ labels, series, unit = '', predFrom = null }) {
  const W = 640, H = 340, m = { l: 52, r: 24, t: 26, b: 44 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b, n = labels.length;
  const mounted = useMounted();
  const [hv, setHv] = useState(null);
  const all = series.flatMap((s) => s.values);
  const hi = niceMax(Math.max(...all, 1)), mn = Math.min(0, ...all), lo = mn < 0 ? -niceMax(-mn) : 0;
  const X = (i) => (n === 1 ? m.l + iw / 2 : m.l + (iw * i) / (n - 1));
  const Y = (v) => m.t + ih - ((v - lo) / (hi - lo)) * ih;
  const sp = n === 1 ? iw : iw / (n - 1);
  const path = (vals, from = 0, to = n) => vals.slice(from, to).map((v, i) => `${i ? 'L' : 'M'}${X(i + from)} ${Y(v)}`).join('');
  return (
    <div className="chart-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="chart"><Defs />
        {[0, 1, 2, 3, 4, 5].map((i) => { const v = lo + ((hi - lo) * i) / 5; return (
          <g key={i}><line x1={m.l} x2={W - m.r} y1={Y(v)} y2={Y(v)} className="grid" /><text x={m.l - 8} y={Y(v) + 4} textAnchor="end" className="ax">{fmt(v, 1)}</text></g>); })}
        {labels.map((lb, i) => <text key={i} x={X(i)} y={H - m.b + 20} textAnchor="middle" className="ax">{lb}</text>)}
        {series.length === 1 && n > 1 && <path d={`${path(series[0].values)}L${X(n - 1)} ${Y(0)}L${X(0)} ${Y(0)}Z`} fill="url(#areag)" style={{ opacity: mounted ? 1 : 0, transition: 'opacity 1.4s .5s' }} />}
        {hv !== null && <line x1={X(hv)} x2={X(hv)} y1={m.t} y2={m.t + ih} stroke="var(--p)" strokeDasharray="4 4" />}
        {series.map((s, si) => {
          const col = s.color || PALETTE[si], cut = predFrom !== null ? predFrom : n;
          return (
            <g key={si}>
              <path d={path(s.values, 0, cut)} pathLength="1" fill="none" stroke={col} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"
                strokeDasharray="1" strokeDashoffset={mounted ? 0 : 1} style={{ transition: 'stroke-dashoffset 1.5s ease' }} />
              {predFrom !== null && <path d={path(s.values, cut - 1, n)} fill="none" stroke="#E62A89" strokeWidth="3" strokeDasharray="7 7" style={{ opacity: mounted ? 1 : 0, transition: 'opacity 1s 1.4s' }} />}
              {s.values.map((v, i) => <circle key={i} cx={X(i)} cy={Y(v)} r={hv === i ? 8 : 5} fill={predFrom !== null && i >= cut ? '#E62A89' : col} stroke="var(--bg2)" strokeWidth="2" className="dot"
                style={{ opacity: mounted ? 1 : 0, transition: `opacity .4s ${1000 + i * 90}ms` }} />)}
            </g>
          );
        })}
        {labels.map((_, i) => <rect key={i} x={X(i) - sp / 2} y={m.t} width={sp} height={ih} fill="transparent" onMouseEnter={() => setHv(i)} onMouseLeave={() => setHv(null)} />)}
        {hv !== null && (() => {
          const w = 142, h = 24 + series.length * 16, tx = X(hv) + 12 + w > W ? X(hv) - w - 12 : X(hv) + 12;
          return <g className="tip" transform={`translate(${tx},${m.t})`}><rect width={w} height={h} rx="8" />
            <text x="10" y="17">{labels[hv]}</text>
            {series.map((s, si) => <text key={si} x="10" y={34 + si * 16} style={{ fill: s.color || PALETTE[si] }}>{s.name}: {fmt(s.values[hv])}{unit}</text>)}</g>;
        })()}
      </svg>
      {series.length > 1 && <Legend items={series.map((s, i) => ({ label: s.name, color: s.color || PALETTE[i] }))} />}
    </div>
  );
}

/* ---------- Scatter chart + optional regression line ---------- */
function ScatterChart({ points, line = null, xLabel = 'x', yLabel = 'y' }) {
  const W = 640, H = 340, m = { l: 52, r: 16, t: 22, b: 48 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const mounted = useMounted();
  const xs = points.map((p) => p.x), ys = points.map((p) => p.y);
  const px = (Math.max(...xs) - Math.min(...xs)) * 0.08 || 1, py = (Math.max(...ys) - Math.min(...ys)) * 0.1 || 1;
  const x0 = Math.min(...xs) - px, x1 = Math.max(...xs) + px, y0 = Math.min(...ys) - py, y1 = Math.max(...ys) + py;
  const X = (v) => m.l + ((v - x0) / (x1 - x0)) * iw, Y = (v) => m.t + ih - ((v - y0) / (y1 - y0)) * ih;
  const [hv, setHv] = useState(null);
  return (
    <div className="chart-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="chart">
        <clipPath id="plotclip"><rect x={m.l} y={m.t} width={iw} height={ih} /></clipPath>
        {[0, 1, 2, 3, 4, 5].map((i) => { const vy = y0 + ((y1 - y0) * i) / 5, vx = x0 + ((x1 - x0) * i) / 5; return (
          <g key={i}><line x1={m.l} x2={W - m.r} y1={Y(vy)} y2={Y(vy)} className="grid" /><text x={m.l - 8} y={Y(vy) + 4} textAnchor="end" className="ax">{fmt(vy, 1)}</text>
            <text x={X(vx)} y={H - m.b + 18} textAnchor="middle" className="ax">{fmt(vx, 1)}</text></g>); })}
        <text x={W / 2} y={H - 6} textAnchor="middle" className="ax">{xLabel}</text>
        <text x={m.l} y={14} className="ax">{yLabel}</text>
        {line && <path d={`M${X(x0)} ${Y(line.m * x0 + line.c)}L${X(x1)} ${Y(line.m * x1 + line.c)}`} clipPath="url(#plotclip)" pathLength="1" fill="none" stroke="#E62A89" strokeWidth="3"
          strokeDasharray="1" strokeDashoffset={mounted ? 0 : 1} style={{ transition: 'stroke-dashoffset 1.6s ease .6s' }} />}
        {points.map((p, i) => <circle key={i} cx={X(p.x)} cy={Y(p.y)} r={mounted ? (hv === i ? 9 : 6) : 0} fill="#029EFF" stroke="#fff" strokeWidth="1.5" className="dot"
          style={{ transition: `r .45s cubic-bezier(.2,1.4,.3,1) ${i * 40}ms` }} onMouseEnter={() => setHv(i)} onMouseLeave={() => setHv(null)} />)}
        {hv !== null && (() => { const p = points[hv], txt = `(${fmt(p.x)}, ${fmt(p.y)})`, w = txt.length * 7 + 16;
          return <g className="tip" transform={`translate(${Math.min(X(p.x) - w / 2, W - w - 2)},${Math.max(Y(p.y) - 40, 2)})`}><rect width={w} height="26" rx="8" /><text x={w / 2} y="17" textAnchor="middle">{txt}</text></g>; })()}
      </svg>
    </div>
  );
}

/* ---------- Histogram ---------- */
function Histogram({ bins }) {
  const W = 640, H = 340, m = { l: 52, r: 16, t: 26, b: 44 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const mounted = useMounted();
  const max = niceMax(Math.max(...bins.map((b) => b.count), 1)), bw = iw / bins.length;
  const y = (v) => m.t + ih - (v / max) * ih;
  return (
    <div className="chart-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="chart"><Defs />
        {[0, 1, 2, 3, 4, 5].map((i) => { const v = (max * i) / 5; return (
          <g key={i}><line x1={m.l} x2={W - m.r} y1={y(v)} y2={y(v)} className="grid" /><text x={m.l - 8} y={y(v) + 4} textAnchor="end" className="ax">{fmt(v, 1)}</text></g>); })}
        {bins.map((b, i) => (
          <g key={i}>
            <g style={{ transform: `scaleY(${mounted ? 1 : 0})`, transformOrigin: `0px ${m.t + ih}px`, transition: `transform .7s cubic-bezier(.2,.9,.3,1.1) ${i * 60}ms` }}>
              <rect x={m.l + i * bw + 1} y={y(b.count)} width={bw - 2} height={ih * (b.count / max)} fill={`url(#bgrad${i % 8})`} className="bar" rx="3" />
            </g>
            <text x={m.l + i * bw + bw / 2} y={y(b.count) - 6} textAnchor="middle" className="val" style={{ opacity: mounted ? 1 : 0, transition: `opacity .5s ${700 + i * 60}ms` }}>{b.count}</text>
            <text x={m.l + i * bw} y={H - m.b + 18} textAnchor="middle" className="ax">{fmt(b.lo, 1)}</text>
          </g>
        ))}
        <text x={m.l + bins.length * bw} y={H - m.b + 18} textAnchor="middle" className="ax">{fmt(bins[bins.length - 1].hi, 1)}</text>
      </svg>
    </div>
  );
}

/* ---------- Radar / web chart ---------- */
function RadarChart({ axes, series, max = 100 }) {
  const S = 380, c = S / 2, R = 125, n = axes.length;
  const mounted = useMounted();
  const pt = (i, v) => { const a = -Math.PI / 2 + (2 * Math.PI * i) / n, r = (R * v) / max; return [c + r * Math.cos(a), c + r * Math.sin(a)]; };
  return (
    <div className="chart-wrap">
      <svg viewBox={`0 0 ${S} ${S}`} className="chart" style={{ maxWidth: 420, margin: '0 auto' }}>
        {[1, 2, 3, 4, 5].map((k) => <polygon key={k} points={axes.map((_, i) => pt(i, (max * k) / 5).join(',')).join(' ')} fill="none" className="grid" style={{ stroke: 'var(--grid)' }} />)}
        {axes.map((a, i) => { const [x, y] = pt(i, max), [lx, ly] = pt(i, max * 1.2);
          return <g key={i}><line x1={c} y1={c} x2={x} y2={y} style={{ stroke: 'var(--grid)' }} /><text x={lx} y={ly + 4} textAnchor="middle" className="ax" style={{ fontWeight: 600 }}>{a}</text></g>; })}
        {series.map((s, si) => (
          <g key={si} style={{ transform: `scale(${mounted ? 1 : 0})`, transformOrigin: `${c}px ${c}px`, transition: `transform 1s cubic-bezier(.2,.9,.3,1.1) ${si * 250}ms` }}>
            <polygon points={axes.map((_, i) => pt(i, s.values[i]).join(',')).join(' ')} fill={PALETTE[si]} fillOpacity=".25" stroke={PALETTE[si]} strokeWidth="2.5" />
            {axes.map((_, i) => { const [x, y] = pt(i, s.values[i]); return <circle key={i} cx={x} cy={y} r="4.5" fill={PALETTE[si]} stroke="#fff" strokeWidth="1.5"><title>{s.name} – {axes[i]}: {s.values[i]}</title></circle>; })}
          </g>
        ))}
      </svg>
      <Legend items={series.map((s, i) => ({ label: s.name, color: PALETTE[i] }))} />
    </div>
  );
}

/* ---------- Analog clock ---------- */
function AnalogClock({ h, m, s = null, showAngle = false }) {
  const hd = (h % 12) * 30 + m * 0.5 + (s !== null ? s / 120 : 0), md = m * 6 + (s !== null ? s / 10 : 0);
  const tr = (d) => ({ transform: `rotate(${d}deg)`, transformOrigin: '100px 100px', transition: s !== null ? 'none' : 'transform .9s cubic-bezier(.34,1.56,.64,1)' });
  const p = (r, a) => [100 + r * Math.sin((a * Math.PI) / 180), 100 - r * Math.cos((a * Math.PI) / 180)];
  let arc = null;
  if (showAngle) {
    const a1 = hd % 360, a2 = md % 360, diff = (((a2 - a1) % 360) + 360) % 360;
    const [from, sweep] = diff <= 180 ? [a1, diff] : [a2, 360 - diff];
    const [x1, y1] = p(42, from), [x2, y2] = p(42, from + sweep);
    arc = <path d={`M100 100L${x1} ${y1}A42 42 0 0 1 ${x2} ${y2}Z`} fill="#029EFF" fillOpacity=".3" stroke="#029EFF" strokeDasharray="3 3" />;
  }
  return (
    <svg viewBox="0 0 200 200" className="clock-svg">
      <circle cx="100" cy="100" r="94" className="clock-face" />
      {[...Array(60)].map((_, i) => { const [x1, y1] = p(i % 5 ? 88 : 83, i * 6), [x2, y2] = p(92, i * 6); return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} className="tick" strokeWidth={i % 5 ? 1 : 2.5} />; })}
      {[...Array(12)].map((_, i) => { const [x, y] = p(70, (i + 1) * 30); return <text key={i} x={x} y={y + 4.5} className="clock-num">{i + 1}</text>; })}
      {arc}
      <g style={tr(hd)}><line x1="100" y1="106" x2="100" y2="56" className="hand-h" /></g>
      <g style={tr(md)}><line x1="100" y1="108" x2="100" y2="32" className="hand-m" /></g>
      {s !== null && <g style={tr(s * 6)}><line x1="100" y1="112" x2="100" y2="24" className="hand-s" /></g>}
      <circle cx="100" cy="100" r="5" fill="#E62A89" />
    </svg>
  );
}