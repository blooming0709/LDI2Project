/* ============ modules3.jsx : Histogram · Caselet · Web (Radar) · Missing Data ============ */

/* ---------------- HISTOGRAM ---------------- */
function buildBins(data, w) {
  const mn = Math.min(...data), mx = Math.max(...data), start = Math.floor(mn / w) * w, nb = Math.floor((mx - start) / w) + 1;
  const bins = Array.from({ length: nb }, (_, i) => ({ lo: start + i * w, hi: start + (i + 1) * w, count: 0 }));
  data.forEach((v) => { bins[Math.min(nb - 1, Math.floor((v - start) / w))].count++; });
  return bins;
}
function HistogramSolver() {
  const mk = () => Array.from({ length: 40 }, () => Math.round((rand(0, 30) + rand(0, 30) + rand(0, 30)) * 1.1)).join(', ');
  const [txt, setTxt] = useState(mk), [w, setW] = useState('10');
  const parts = txt.split(/[\s,;]+/).filter(Boolean), data = parts.map(Number), wn = Number(w);
  let error = '';
  if (parts.length < 5) error = 'Enter at least 5 values.';
  else if (parts.length > 500) error = 'Maximum 500 values.';
  else if (data.some((x) => !isFinite(x))) error = 'Only numbers allowed (separate with commas, spaces or new lines).';
  else if (!isFinite(wn) || wn <= 0 || w.trim() === '') error = 'Class width must be a positive number.';
  else if (Math.floor((Math.max(...data) - Math.floor(Math.min(...data) / wn) * wn) / wn) + 1 > 30) error = 'Too many classes (>30). Increase the class width.';
  const bins = !error ? buildBins(data, wn) : [], N = data.length;
  let cum = 0, medIdx = -1; bins.forEach((b, i) => { cum += b.count; if (medIdx < 0 && cum >= N / 2) medIdx = i; });
  const gm = bins.length ? sum(bins.map((b) => b.count * (b.lo + b.hi) / 2)) / N : 0, mc = bins.length ? bins.reduce((a, b, i) => (b.count > bins[a].count ? i : a), 0) : 0;
  cum = 0;
  return (
    <div className="split">
      <div className="card">
        <h3>✏️ Raw data</h3>
        <Field label="Values"><textarea value={txt} onChange={(e) => setTxt(e.target.value)} /></Field>
        <Field label="Class width"><input value={w} onChange={(e) => setW(e.target.value)} maxLength={6} /></Field>
        {error && <div className="err shake" key={error}>⚠ {error}</div>}
        <div className="btn-row"><button className="btn sm" onClick={() => setTxt(mk())}>🎲 New sample data</button></div>
        {!error && <div className="tbl-wrap" style={{ marginTop: 12 }}><table className="tbl"><thead><tr><th>Class</th><th>f</th><th>Mid x</th><th>Cum f</th></tr></thead>
          <tbody>{bins.map((b, i) => { cum += b.count; return <tr key={i}><td>{fmt(b.lo)} – {fmt(b.hi)}</td><td>{b.count}</td><td>{fmt((b.lo + b.hi) / 2)}</td><td>{cum}</td></tr>; })}
            <tr><td className="tot">Total</td><td className="tot">{N}</td><td className="tot">–</td><td className="tot">–</td></tr></tbody></table></div>}
      </div>
      <div className="card">
        {!error && <>
          <Histogram key={txt.length + '_' + w} bins={bins} />
          <div className="stats-grid">
            <Stat v={N} l="Observations" /><Stat v={fmt(gm)} l="Grouped mean" i={1} /><Stat v={`${fmt(bins[mc].lo)}–${fmt(bins[mc].hi)}`} l="Modal class" i={2} />
            <Stat v={`${fmt(bins[medIdx].lo)}–${fmt(bins[medIdx].hi)}`} l="Median class" i={3} /><Stat v={fmt(sum(data) / N)} l="Raw mean" i={4} /><Stat v={fmt(Math.max(...data) - Math.min(...data))} l="Range" i={5} />
          </div></>}
      </div>
    </div>
  );
}
function genHistogram() {
  const w = pick([5, 10]), nb = 5, f = uniqueVals(nb, 3, 24), bins = f.map((c, i) => ({ lo: i * w, hi: (i + 1) * w, count: c })), N = sum(f);
  const vis = <><Histogram bins={bins} /><div className="legend">{bins.map((b, i) => <span key={i}>{b.lo}–{b.hi}: <b>{b.count}</b></span>)}</div></>;
  const k = rand(1, 4);
  if (k === 1) { const mi = f.indexOf(Math.max(...f)), labels = bins.map((b) => `${b.lo} – ${b.hi}`), { options, answer } = optionsFrom(labels[mi], labels); return { text: 'Which class interval is the modal class?', visual: vis, options, answer, explain: `Highest frequency is ${f[mi]} → class ${labels[mi]}.` }; }
  if (k === 2) return { text: 'What is the total number of observations?', visual: vis, answer: N, tol: 0, explain: `${f.join(' + ')} = ${N}` };
  if (k === 3) { const t = rand(1, 4); return { text: `How many observations are below ${t * w}?`, visual: vis, answer: sum(f.slice(0, t)), tol: 0, explain: `Add frequencies of the first ${t} classes: ${f.slice(0, t).join(' + ')} = ${sum(f.slice(0, t))}` }; }
  const gm = sum(bins.map((b) => b.count * (b.lo + b.hi) / 2)) / N;
  return { text: 'Estimate the mean of the grouped data. (2 decimals)', visual: vis, answer: gm, tol: 0.011, explain: `Mean = Σ f·x / Σ f with class midpoints = ${fmt(sum(bins.map((b) => b.count * (b.lo + b.hi) / 2)))} / ${N} = ${fmt(gm, 3)}` };
}

/* ---------------- CASELET ---------------- */
function Venn({ total, a, b, both, nameA = 'A', nameB = 'B' }) {
  const m = useMounted(), oa = a - both, ob = b - both, ne = total - (a + b - both);
  const sc = (d) => ({ transform: `scale(${m ? 1 : 0})`, transformOrigin: '210px 130px', transition: `transform .8s cubic-bezier(.2,1.2,.3,1) ${d}ms` });
  return (
    <svg viewBox="0 0 420 260" className="chart venn">
      <rect x="4" y="4" width="412" height="252" rx="16" fill="none" stroke="var(--card-b)" strokeWidth="2" />
      <g style={sc(0)}><circle cx="160" cy="130" r="95" fill="#029EFF" fillOpacity=".4" stroke="#029EFF" strokeWidth="2" /></g>
      <g style={sc(200)}><circle cx="260" cy="130" r="95" fill="#E62A89" fillOpacity=".4" stroke="#E62A89" strokeWidth="2" /></g>
      <text x="110" y="30" className="ax" fontWeight="700">{nameA}</text><text x="285" y="30" className="ax" fontWeight="700">{nameB}</text>
      <text x="105" y="136" textAnchor="middle" className="val" style={{ fontSize: 18 }}>{fmt(oa)}</text>
      <text x="210" y="136" textAnchor="middle" className="val" style={{ fontSize: 18 }}>{fmt(both)}</text>
      <text x="315" y="136" textAnchor="middle" className="val" style={{ fontSize: 18 }}>{fmt(ob)}</text>
      <text x="16" y="244" className="ax">Neither: {fmt(ne)}</text>
    </svg>
  );
}
function CaseletSolver() {
  const [v, setV] = useState({ t: '500', a: '300', b: '250', c: '120' });
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value });
  const n = { t: parseNum(v.t), a: parseNum(v.a), b: parseNum(v.b), c: parseNum(v.c) };
  let error = '';
  if (Object.values(n).some((x) => isNaN(x))) error = 'All four fields must be non-negative numbers.';
  else if (n.t <= 0) error = 'Total must be greater than zero.';
  else if (n.c > Math.min(n.a, n.b)) error = '"Both" cannot be larger than either set.';
  else if (n.a + n.b - n.c > n.t) error = 'Union (A + B − Both) cannot exceed the total.';
  return (
    <div className="split">
      <div className="card">
        <h3>🔵 Two-set caselet calculator</h3>
        <p style={{ color: 'var(--muted)', fontSize: '.88rem', marginBottom: 10 }}>E.g. "In a group of 500 people, 300 like tea, 250 like coffee and 120 like both…"</p>
        <div className="form-row">
          <Field label="Total"><input value={v.t} onChange={set('t')} /></Field><Field label="Set A (tea)"><input value={v.a} onChange={set('a')} /></Field>
          <Field label="Set B (coffee)"><input value={v.b} onChange={set('b')} /></Field><Field label="Both"><input value={v.c} onChange={set('c')} /></Field>
        </div>
        {error && <div className="err shake" key={error}>⚠ {error}</div>}
        {!error && <div className="stats-grid">
          <Stat v={n.a - n.c} l="Only A" /><Stat v={n.b - n.c} l="Only B" i={1} /><Stat v={n.a + n.b - n.c} l="At least one" i={2} /><Stat v={n.t - (n.a + n.b - n.c)} l="Neither" i={3} />
          <Stat v={fmt(((n.a - n.c) / n.t) * 100) + '%'} l="Only A (%)" i={4} /><Stat v={fmt(((n.t - (n.a + n.b - n.c)) / n.t) * 100) + '%'} l="Neither (%)" i={5} />
        </div>}
        {!error && <div className="steps">{`n(A ∪ B) = n(A) + n(B) − n(A ∩ B) = ${n.a} + ${n.b} − ${n.c} = ${n.a + n.b - n.c}\nNeither = Total − n(A ∪ B) = ${n.t - (n.a + n.b - n.c)}`}</div>}
      </div>
      <div className="card">{!error ? <Venn total={n.t} a={n.a} b={n.b} both={n.c} nameA="Tea" nameB="Coffee" /> : <p>Fix the inputs to draw the Venn diagram.</p>}</div>
    </div>
  );
}
function genCaselet() {
  const t = rand(1, 3);
  if (t === 1) {
    const N = rand(2, 10) * 100; let A, B, C; do { A = rand(3, 8) * 10; B = rand(3, 8) * 10; C = rand(1, 3) * 10; } while (C > Math.min(A, B) || A + B - C > 95);
    const cap = <div className="caselet">A survey of <b>{N}</b> people found that <b>{A}%</b> like tea, <b>{B}%</b> like coffee and <b>{C}%</b> like both.</div>, k = rand(1, 3);
    if (k === 1) return { text: 'How many people like only tea?', visual: cap, answer: (N * (A - C)) / 100, tol: 0.01, explain: `Only tea = (${A}% − ${C}%) of ${N} = ${(N * (A - C)) / 100}` };
    if (k === 2) return { text: 'How many people like neither tea nor coffee?', visual: cap, answer: (N * (100 - (A + B - C))) / 100, tol: 0.01, explain: `Union = ${A} + ${B} − ${C} = ${A + B - C}%. Neither = ${100 - (A + B - C)}% of ${N} = ${(N * (100 - (A + B - C))) / 100}` };
    return { text: 'How many people like at least one of the two drinks?', visual: cap, answer: (N * (A + B - C)) / 100, tol: 0.01, explain: `${A}% + ${B}% − ${C}% = ${A + B - C}% of ${N} = ${(N * (A + B - C)) / 100}` };
  }
  if (t === 2) {
    const a = rand(2, 5), b = rand(2, 5), k = rand(1, 4), N = (a + b) * k * 100, men = a * k * 100, women = b * k * 100, x = pick([20, 40, 50, 60]), y = pick([10, 30, 50, 80]);
    const cap = <div className="caselet">A company has <b>{N}</b> employees. The ratio of men to women is <b>{a}:{b}</b>. <b>{x}%</b> of the men and <b>{y}%</b> of the women are graduates.</div>;
    return { text: 'How many graduate employees are there in total?', visual: cap, answer: (men * x) / 100 + (women * y) / 100, tol: 0.01, explain: `Men = ${men}, women = ${women}.\nGraduates = ${x}% × ${men} + ${y}% × ${women} = ${(men * x) / 100} + ${(women * y) / 100} = ${(men * x) / 100 + (women * y) / 100}` };
  }
  const jan = rand(2, 10) * 100, p = pick([10, 20, 25]), q = pick([10, 20, 25]), feb = jan * (1 + p / 100), mar = feb * (1 - q / 100);
  const cap = <div className="caselet">A shop sold <b>{jan}</b> items in January. Sales in February were <b>{p}% higher</b> than January, and sales in March were <b>{q}% lower</b> than February.</div>;
  return { text: 'How many items were sold in the three months combined?', visual: cap, answer: jan + feb + mar, tol: 0.011, explain: `Feb = ${jan} × ${1 + p / 100} = ${fmt(feb)}\nMar = ${fmt(feb)} × ${1 - q / 100} = ${fmt(mar)}\nTotal = ${jan} + ${fmt(feb)} + ${fmt(mar)} = ${fmt(jan + feb + mar, 3)}` };
}

/* ---------------- WEB (RADAR) ---------------- */
const SUBJECTS = ['Maths', 'Physics', 'Chemistry', 'Biology', 'English', 'CS'];
function WebSolver() {
  const [rows, setRows] = useState(() => SUBJECTS.map((s) => ({ l: s, a: String(rand(45, 95)), b: String(rand(45, 95)) })));
  const [names, setNames] = useState({ a: 'Aarav', b: 'Diya' });
  const bad = rows.some((r) => ['a', 'b'].some((k) => isNaN(parseNum(r[k])) || parseNum(r[k]) > 100));
  const A = rows.map((r) => Math.min(100, parseNum(r.a) || 0)), B = rows.map((r) => Math.min(100, parseNum(r.b) || 0)), L = rows.map((r) => r.l || '?');
  const sa = describe(A, L), sb = describe(B, L);
  return (
    <div className="split">
      <div className="card">
        <h3>✏️ Scores (0 – 100)</h3>
        <div className="form-row"><Field label="Name 1"><input value={names.a} maxLength={12} onChange={(e) => setNames({ ...names, a: e.target.value })} /></Field><Field label="Name 2"><input value={names.b} maxLength={12} onChange={(e) => setNames({ ...names, b: e.target.value })} /></Field></div>
        <RowsEditor rows={rows} setRows={setRows} minRows={3} maxRows={8} mk={(i) => ({ l: 'Skill' + (i + 1), a: '60', b: '60' })} cols={[{ key: 'l', label: 'Axis', type: 'text' }, { key: 'a', label: names.a || 'A', type: 'num' }, { key: 'b', label: names.b || 'B', type: 'num' }]} />
        {bad && <div className="err shake" key="wb">⚠ Scores must be numbers from 0 to 100 (values above 100 are capped).</div>}
        <div className="btn-row"><button className="btn sm" onClick={() => setRows(rows.map((r) => ({ ...r, a: String(rand(40, 98)), b: String(rand(40, 98)) })))}>🎲 Random</button></div>
      </div>
      <div className="card">
        <RadarChart axes={L} series={[{ name: names.a || 'A', values: A }, { name: names.b || 'B', values: B }]} />
        <div className="stats-grid">
          <Stat v={fmt(sa.mean)} l={`${names.a} average`} /><Stat v={fmt(sb.mean)} l={`${names.b} average`} i={1} /><Stat v={`${sa.maxL} (${sa.max})`} l={`${names.a} strongest`} i={2} />
          <Stat v={`${sb.maxL} (${sb.max})`} l={`${names.b} strongest`} i={3} /><Stat v={sa.mean === sb.mean ? 'Tie' : sa.mean > sb.mean ? names.a : names.b} l="Higher average" i={4} />
        </div>
      </div>
    </div>
  );
}
function genWeb() {
  const nm = shuffle(['Aarav', 'Diya', 'Kabir', 'Meera', 'Rohan', 'Isha']).slice(0, 2), A = SUBJECTS.map(() => rand(40, 98)); let B; do { B = SUBJECTS.map(() => rand(40, 98)); } while (sum(A) === sum(B));
  const vis = <RadarChart axes={SUBJECTS} series={[{ name: nm[0], values: A }, { name: nm[1], values: B }]} />, k = rand(1, 4), i = rand(0, 5);
  if (k === 1) { const ans = sum(A) > sum(B) ? nm[0] : nm[1], { options, answer } = optionsFrom(ans, [nm[0], nm[1], 'Both equal'], 3); return { text: 'Who has the higher total score?', visual: vis, options, answer, explain: `${nm[0]} = ${sum(A)}, ${nm[1]} = ${sum(B)}.` }; }
  if (k === 2) return { text: `What is the difference between the two students' scores in ${SUBJECTS[i]}?`, visual: vis, answer: Math.abs(A[i] - B[i]), tol: 0, explain: `|${A[i]} − ${B[i]}| = ${Math.abs(A[i] - B[i])}` };
  if (k === 3) { const mx = Math.max(...A), { options, answer } = optionsFrom(SUBJECTS[A.indexOf(mx)], SUBJECTS); return { text: `In which subject did ${nm[0]} score the highest?`, visual: vis, options, answer, explain: `${nm[0]}'s peak on the web is ${SUBJECTS[A.indexOf(mx)]} (${mx}).` }; }
  return { text: `What is ${nm[1]}'s average score across all six subjects? (2 decimals)`, visual: vis, answer: sum(B) / 6, tol: 0.011, explain: `${B.join(' + ')} = ${sum(B)}; ÷ 6 = ${fmt(sum(B) / 6, 3)}` };
}

/* ---------------- MISSING DATA ---------------- */
function solveGrid(cells, rowT, colT, gt) {
  const val = {}, name = {};
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) { val['c' + i + j] = cells[i][j]; name['c' + i + j] = `cell R${i + 1}C${j + 1}`; }
    val['r' + i] = rowT[i]; name['r' + i] = `Row ${i + 1} total`; val['k' + i] = colT[i]; name['k' + i] = `Column ${i + 1} total`;
  }
  val.g = gt; name.g = 'Grand total';
  const cons = [];
  for (let i = 0; i < 3; i++) {
    cons.push({ label: `Row ${i + 1}`, terms: [['c' + i + '0', 1], ['c' + i + '1', 1], ['c' + i + '2', 1], ['r' + i, -1]] });
    cons.push({ label: `Column ${i + 1}`, terms: [['c0' + i, 1], ['c1' + i, 1], ['c2' + i, 1], ['k' + i, -1]] });
  }
  cons.push({ label: 'Row totals', terms: [['r0', 1], ['r1', 1], ['r2', 1], ['g', -1]] });
  cons.push({ label: 'Column totals', terms: [['k0', 1], ['k1', 1], ['k2', 1], ['g', -1]] });
  const steps = []; let changed = true;
  while (changed) {
    changed = false;
    for (const c of cons) {
      const unk = c.terms.filter(([id]) => val[id] === null);
      if (unk.length === 1) {
        const [uid, coef] = unk[0], s = c.terms.reduce((a, [id, cf]) => (val[id] === null ? a : a + cf * val[id]), 0), v = -s / coef;
        val[uid] = v; steps.push(`${c.label} equation → ${name[uid]} = ${fmt(v)}`); changed = true;
      }
    }
  }
  const unresolved = Object.keys(val).filter((k) => val[k] === null).map((k) => name[k]);
  const conflict = cons.some((c) => c.terms.every(([id]) => val[id] !== null) && Math.abs(c.terms.reduce((a, [id, cf]) => a + cf * val[id], 0)) > 1e-6);
  return { val, steps, unresolved, conflict };
}
function MissingSolver() {
  const [g, setG] = useState({ c00: '12', c01: '', c02: '20', c10: '', c11: '15', c12: '9', c20: '8', c21: '14', c22: '', r0: '50', r1: '', r2: '40', k0: '', k1: '48', k2: '', g: '130' });
  const ids = Object.keys(g);
  const parsed = {}; let error = '';
  ids.forEach((k) => { const s = g[k].trim(); if (s === '') parsed[k] = null; else { const n = parseNum(s); if (isNaN(n)) error = 'Every filled box must contain a non-negative number. Leave a box empty if it is unknown.'; parsed[k] = n; } });
  const res = !error ? solveGrid([0, 1, 2].map((i) => [0, 1, 2].map((j) => parsed['c' + i + j])), [0, 1, 2].map((i) => parsed['r' + i]), [0, 1, 2].map((i) => parsed['k' + i]), parsed.g) : null;
  const cell = (k) => <td key={k} className={res && parsed[k] === null && res.val[k] !== null ? 'filled' : ''}>
    {res && parsed[k] === null && res.val[k] !== null ? fmt(res.val[k]) : <input className="cell-in" style={{ width: 62, textAlign: 'center' }} value={g[k]} onChange={(e) => setG({ ...g, [k]: e.target.value })} placeholder="?" maxLength={6} />}</td>;
  return (
    <div className="split">
      <div className="card">
        <h3>🧩 Fill what you know – leave unknowns blank</h3>
        <div className="tbl-wrap"><table className="tbl"><thead><tr><th></th><th>Col 1</th><th>Col 2</th><th>Col 3</th><th>Total</th></tr></thead>
          <tbody>{[0, 1, 2].map((i) => <tr key={i}><td>Row {i + 1}</td>{[0, 1, 2].map((j) => cell('c' + i + j))}{cell('r' + i)}</tr>)}
            <tr><td>Total</td>{[0, 1, 2].map((j) => cell('k' + j))}{cell('g')}</tr></tbody></table></div>
        {error && <div className="err shake" key={error}>⚠ {error}</div>}
        {res && res.conflict && <div className="err shake" key="cf">⚠ The numbers you entered contradict each other.</div>}
        {res && !res.conflict && res.unresolved.length > 0 && <div className="err">Not enough information to find: {res.unresolved.join(', ')}.</div>}
        {res && !res.conflict && res.unresolved.length === 0 && res.steps.length > 0 && <div className="ok-msg">✔ All missing values found!</div>}
        <div className="btn-row"><button className="btn ghost sm" onClick={() => setG(Object.fromEntries(ids.map((k) => [k, ''])))}>Clear all</button></div>
      </div>
      <div className="card">
        <h3>🪜 Solution steps</h3>
        {res && res.steps.length ? <div className="steps stagger" style={{ whiteSpace: 'normal' }}>{res.steps.map((s, i) => <div key={i} style={{ '--i': i, padding: '6px 0', borderBottom: '1px solid var(--card-b)' }}>{i + 1}. {s}</div>)}</div> : <p style={{ color: 'var(--muted)' }}>Steps appear here as the solver fills the blanks using row and column totals.</p>}
      </div>
    </div>
  );
}
function genMissing() {
  const cells = [0, 1, 2].map(() => [0, 1, 2].map(() => rand(8, 60))), rt = cells.map(sum), ct = [0, 1, 2].map((j) => sum(cells.map((r) => r[j]))), gt = sum(rt);
  const perm = shuffle([0, 1, 2]), hide = shuffle([0, 1, 2]).slice(0, rand(2, 3)).map((i) => [i, perm[i]]);
  const isH = (i, j) => hide.some(([a, b]) => a === i && b === j), [ti, tj] = pick(hide);
  const vis = (
    <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Region</th><th>Q1</th><th>Q2</th><th>Q3</th><th>Total</th></tr></thead>
      <tbody>{cells.map((r, i) => <tr key={i}><td>Region {i + 1}</td>{r.map((v, j) => <td key={j} className={isH(i, j) ? 'unk' : ''}>{isH(i, j) ? '?' : v}</td>)}<td className="tot">{rt[i]}</td></tr>)}
        <tr><td>Total</td>{ct.map((v, j) => <td key={j} className="tot">{v}</td>)}<td className="tot">{gt}</td></tr></tbody></table></div>
  );
  const others = cells[ti].filter((_, j) => j !== tj && !isH(ti, j));
  return { text: `Some cells are hidden ("?"). Find the value of Region ${ti + 1}, Q${tj + 1}.`, visual: vis, answer: cells[ti][tj], tol: 0,
    explain: `Row ${ti + 1} total = ${rt[ti]}. ${others.length === 2 ? `Subtract the known cells: ${rt[ti]} − ${others.join(' − ')} = ${cells[ti][tj]}.` : `Use the Q${tj + 1} column total (${ct[tj]}) minus the known cells in that column.`}` };
}