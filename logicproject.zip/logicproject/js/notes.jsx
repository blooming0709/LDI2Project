/* ============ notes.jsx : detailed study notes for every module (10 sections each) ============ */
const NOTES = {
/* ================================================================ CLOCK */
clock: {
  intro: "Clock problems test angular motion and relative speed. Every question - angles, overlaps, mirror images, faulty clocks - is solved with just three numbers: 6 degrees, 0.5 degrees and 5.5 degrees. Learn them once and the whole chapter becomes mechanical.",
  sections: [
    { ic: "🕒", t: "Dial basics and hand speeds",
      p: ["The dial is a full circle of 360 degrees. It has 12 hour marks and 60 minute marks, so neighbouring hour marks are 30 degrees apart and neighbouring minute marks are 6 degrees apart."],
      b: ["The minute hand moves **6 degrees per minute** (360 degrees in 60 minutes).", "The hour hand moves **0.5 degrees per minute** (30 degrees in 60 minutes).", "So the minute hand gains **5.5 degrees per minute** on the hour hand.", "In one hour the minute hand covers 60 minute-spaces while the hour hand covers only 5 minute-spaces.", "The minute hand is 12 times as fast as the hour hand."],
      f: ["Minute-hand angle (from 12) = 6 x M", "Hour-hand angle (from 12) = 30 x H + M / 2"],
      tr: "Think in minute-spaces: the dial is 60 spaces and each space is 6 degrees. At 4:20 the hour hand is 20 spaces from 12 plus 20/12 of a space." },
    { ic: "📐", t: "Angle between the hands",
      p: ["Compute where each hand points (measured from 12) and subtract. If the result is more than 180 degrees, the smaller angle is 360 minus the result."],
      f: ["Angle = | 30H - 5.5M |", "If angle > 180 degrees, use 360 - angle"],
      ex: [{ q: "Find the angle between the hands at 4:20.", s: ["Angle = |30 x 4 - 5.5 x 20|", "= |120 - 110| = 10 degrees"], a: "10 degrees" },
           { q: "Find the angle between the hands at 7:45.", s: ["|30 x 7 - 5.5 x 45| = |210 - 247.5| = 37.5 degrees"], a: "37.5 degrees" }],
      b: ["Always use H on a 12-hour scale (12 counts as 0).", "At 12:30 the angle is |0 - 165| = 165 degrees.", "Angle at exact hours: 3 o'clock = 90, 6 o'clock = 180, 9 o'clock = 90."],
      mi: "Forgetting that the hour hand also creeps forward with the minutes (0.5 degrees per minute) gives wrong answers." },
    { ic: "🔁", t: "Overlaps, opposites and right angles",
      p: ["How many times do special positions occur? These counts are asked directly in many exams, so memorise them."],
      b: ["Hands **overlap 11 times** in 12 hours (22 times in 24 hours).", "Hands are **opposite (180 degrees) 11 times** in 12 hours.", "Hands are in a **straight line** (overlap or opposite) 22 times in 12 hours.", "Hands are at **right angles 22 times** in 12 hours (44 times in a day).", "Between 11 o'clock and 1 o'clock the hands overlap only once, at 12:00."],
      f: ["Overlap after H o'clock: M = 60H / 11 minutes", "Angle T at M minutes past H: M = (60H +/- 2T) / 11", "Time between two overlaps = 720 / 11 = 65 5/11 minutes"],
      ex: [{ q: "At what time between 4 and 5 do the hands coincide?", s: ["Use M = 60H / 11 with H = 4", "M = 240 / 11 = 21 9/11 minutes"], a: "4:21 9/11 (about 4:21:49)" },
           { q: "At what times between 5 and 6 are the hands at right angles?", s: ["M = (60 x 5 +/- 2 x 90) / 11", "M = (300 - 180)/11 = 10 10/11  or  M = (300 + 180)/11 = 43 7/11"], a: "5:10 10/11 and 5:43 7/11" }] },
    { ic: "🪞", t: "Mirror image and water image",
      p: ["A mirror reflects left to right (about the 12-6 line). A water image reflects top to bottom (about the 3-9 line). Both follow simple subtraction rules."],
      f: ["Mirror image time = 11:60 - given time", "Water image time = 5:60 - given time"],
      ex: [{ q: "Find the mirror image of 3:40.", s: ["11:60 - 3:40 = 8:20"], a: "8:20" },
           { q: "Find the water image of 3:40.", s: ["5:60 - 3:40 = 2:20"], a: "2:20" },
           { q: "Mirror image of 12:20?", s: ["11:60 - 12:20 is negative, so add 12 hours: 11:40"], a: "11:40" }],
      tr: "For a mirror image of an exact hour: 3:00 becomes 9:00, 4:00 becomes 8:00, 12:00 and 6:00 stay the same." },
    { ic: "⏩", t: "Fast and slow clocks",
      p: ["A faulty clock gains or loses a fixed number of minutes per hour (or per day). Work with the ratio of shown time to true time."],
      f: ["Gains g min/hour: shown time = true time x (60 + g) / 60", "Loses l min/hour: shown time = true time x (60 - l) / 60", "True time = shown time x 60 / (60 +/- g)"],
      ex: [{ q: "A clock is right at 12 noon and gains 5 minutes every hour. What does it show when the true time is 6 PM?", s: ["True elapsed time = 6 hours", "Total gain = 6 x 5 = 30 minutes"], a: "6:30 PM" },
           { q: "A clock is set right at 6 AM and loses 4 minutes per hour. What does it show at true time 6 PM?", s: ["Loss in 12 hours = 12 x 4 = 48 minutes", "6 PM - 48 min"], a: "5:12 PM" }],
      mi: "When a clock is wrong, the correct time is NOT the one the faulty clock shows - always convert using the ratio." },
    { ic: "🚀", t: "Speed strategies and exam tips",
      b: ["Write H and M clearly, then plug into |30H - 5.5M|. Never estimate angles from a drawing.", "For 'what time' questions, set up M = (60H +/- 2T)/11 and check the answer lies between 0 and 60.", "Use symmetry: the angle at H:M equals the angle at (12 - H):(60 - M).", "Check your answer: the minute hand at 6M degrees and hour hand at 30H + M/2 should differ by the angle you found.", "Practise 20 mirror images quickly - they take 5 seconds each once the 11:60 rule is automatic."],
      mi: "Mixing 24-hour times with the 12-hour formula. Convert 15:20 to 3:20 first." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "A watch gains 2 minutes every hour and is set right at 8 AM. What is the true time when the watch shows 8 PM?", s: ["Watch time elapsed = 12 h = 720 min", "The watch shows 62 min for every 60 true min", "True time elapsed = 720 x 60 / 62 = 696.77 min = 11 h 36 min 46 s"], a: "About 7:36:46 PM" },
           { q: "How many times in a day are the hands opposite to each other?", s: ["11 times in 12 hours", "2 x 11 = 22"], a: "22 times" },
           { q: "At what times between 7 and 8 are the hands 4 minute-spaces apart?", s: ["Hour hand at 35 + M/12 spaces, minute hand at M spaces", "M - (35 + M/12) = +4 gives M = 468/11 = 42 6/11", "M - (35 + M/12) = -4 gives M = 372/11 = 33 9/11"], a: "7:33 9/11 and 7:42 6/11" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["Find the angle between the hands at 3:30.", "|30 x 3 - 5.5 x 30| = |90 - 165| = 75 degrees"],
           ["Find the angle between the hands at 9:15.", "|270 - 82.5| = 187.5, so the smaller angle is 360 - 187.5 = 172.5 degrees"],
           ["What is the mirror image of 7:25?", "11:60 - 7:25 = 4:35"],
           ["When do the hands first coincide after 2 o'clock?", "M = 60 x 2 / 11 = 10 10/11 minutes, i.e. 2:10 10/11"],
           ["A clock loses 3 minutes per hour and is right at noon. What is the true time when it shows 6 PM?", "Shown 360 min = 57/60 of true time, so true = 360 x 60/57 = 378.95 min, about 6:19 PM"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Why is the relative speed 5.5 degrees per minute?", "The minute hand moves 6 degrees per minute and the hour hand 0.5, so the minute hand gains 6 - 0.5 = 5.5 degrees every minute."],
           ["Do I always use 360 minus the angle?", "Only when the computed angle is more than 180 degrees and the question asks for the smaller angle."],
           ["How many times do the hands overlap between 12 noon and 12 midnight?", "11 times, not 12, because the 11th overlap happens exactly at 12:00 midnight."],
           ["Is the 11:60 mirror rule valid for times like 12:xx and 6:xx?", "Yes. Treat 12 as 0 when subtracting, and add 12 hours if the result is negative."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Minute space", "One of the 60 equal divisions of the dial, worth 6 degrees."], ["Coincide / overlap", "Both hands pointing at exactly the same position."], ["Relative speed", "How fast one hand gains on the other (5.5 degrees per minute)."], ["Reflex angle", "An angle larger than 180 degrees (360 minus the smaller angle)."], ["Mirror image", "The time seen when a clock is reflected left to right."], ["Water image", "The time seen when a clock is reflected top to bottom."]] }
  ],
  revise: ["Angle = |30H - 5.5M|", "Hour hand = 0.5 deg/min", "Minute hand = 6 deg/min", "Overlap M = 60H/11", "Mirror = 11:60 - T", "Water = 5:60 - T", "22 overlaps+opposites per 12 h", "44 right angles per day"]
},
/* ================================================================ CALENDAR */
calendar: {
  intro: "Calendar problems are 'count the days, take the remainder when divided by 7' problems. The remainder is called the number of odd days, and it tells you how far the weekday shifts. Master odd days and any date puzzle becomes a short calculation.",
  sections: [
    { ic: "📆", t: "Years, months and leap years",
      b: ["An ordinary year has 365 days = 52 weeks + **1 odd day**.", "A leap year has 366 days = 52 weeks + **2 odd days**.", "Months with 31 days: Jan, Mar, May, Jul, Aug, Oct, Dec.", "Months with 30 days: Apr, Jun, Sep, Nov. February has 28 (29 in a leap year).", "Knuckle trick: the knuckles of your fist are 31-day months, the valleys are 30-day months (February is the exception)."],
      f: ["Leap year: divisible by 4, but a century year must be divisible by 400"],
      ex: [{ q: "Are 1900, 2000 and 2100 leap years?", s: ["1900 / 400 is not whole - not leap", "2000 / 400 = 5 - leap", "2100 / 400 is not whole - not leap"], a: "Only 2000 is a leap year" }] },
    { ic: "🧮", t: "Odd days - the core idea",
      p: ["Odd days = total number of days mod 7. Because there are 7 weekdays, only the remainder shifts the day of the week."],
      b: ["Ordinary year -> 1 odd day, leap year -> 2 odd days.", "100 years -> 5 odd days, 200 years -> 3, 300 years -> 1, 400 years -> 0.", "Month odd days: 31 days -> 3, 30 days -> 2, February 28 -> 0, February 29 -> 1.", "Weekday codes: 0 = Sunday, 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday."],
      f: ["Odd days = (number of days) mod 7", "Weekday = (odd days of centuries + years + months + date) mod 7"],
      tr: "Every 400 years the calendar repeats exactly, so only the last 400 years matter. 1600, 2000 and 2400 all start with 0 odd days." },
    { ic: "🎯", t: "Finding the day for any date",
      p: ["Follow four steps: (1) odd days of completed centuries, (2) odd days of completed years in the current century (years + leap years), (3) odd days of completed months of that year, (4) the date itself. Add and take mod 7."],
      ex: [{ q: "On which day of the week was 15 August 1947?", s: ["Completed centuries: 1900 years = 1600 (0) + 300 (1) = 1 odd day", "Years 1901-1946 = 46 years with 11 leap years: 46 + 11 = 57 -> 57 mod 7 = 1", "Jan to Jul 1947: 3+0+3+2+3+2+3 = 16 -> 2 odd days", "Date: 15 mod 7 = 1", "Total = 1 + 1 + 2 + 1 = 5 -> Friday"], a: "Friday" }],
      mi: "Do not count the current year as complete. Only months BEFORE the given month are added." },
    { ic: "🔢", t: "Counting leap years",
      p: ["To count leap years up to a year Y, count multiples of 4, remove multiples of 100, and add back multiples of 400."],
      f: ["Leap years up to Y = floor(Y/4) - floor(Y/100) + floor(Y/400)", "Leap years from A to B (inclusive) = f(B) - f(A - 1)"],
      ex: [{ q: "How many leap years are there from 1901 to 2000 inclusive?", s: ["f(2000) = 500 - 20 + 5 = 485", "f(1900) = 475 - 19 + 4 = 460", "485 - 460 = 25"], a: "25 leap years" }],
      b: ["In any 100 consecutive years (not crossing a non-leap century) there are 24 or 25 leap years.", "In 400 years there are exactly 97 leap years."] },
    { ic: "🔁", t: "Repeating calendars and same-day months",
      p: ["A calendar repeats when the total odd days shifted equals 0 mod 7 AND both years are of the same type (both leap or both ordinary)."],
      b: ["2021 (ordinary) repeats in 2027: odd days 1+1+1+2+1+1 = 7 -> 0 mod 7.", "Ordinary year: January and October start on the same day; February, March and November; April and July; September and December.", "Leap year: January, April and July; February and August; March and November; September and December.", "A month with 31 days has three days that occur five times (the first three weekdays of that month)."],
      tr: "To find when a calendar repeats, keep adding 1 (ordinary) or 2 (leap) to a running total until it hits 7, 14, 21... and the new year has the same leap-status." },
    { ic: "⏭", t: "Day after N days and date differences",
      p: ["Divide N by 7 and use only the remainder. Move that many weekdays forward (or backward for 'before')."],
      ex: [{ q: "Today is Tuesday. What day will it be after 100 days?", s: ["100 mod 7 = 2", "Tuesday + 2 days"], a: "Thursday" },
           { q: "26 January 2024 was a Friday. What day is 26 January 2026?", s: ["2024 -> 2025 crosses 29 Feb 2024: 366 days -> 2 odd days", "2025 -> 2026: 365 days -> 1 odd day", "Total 3 -> Friday + 3"], a: "Monday" }],
      mi: "Forgetting 29 February when the interval crosses a leap day, or counting both the start and the end date." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "On which day of the week was 1 January 2000?", s: ["Completed centuries 1900 years = 1600 (0) + 300 (1) = 1 odd day", "Years 1901-1999 = 99 years with 24 leap years: 99 + 24 = 123 -> 123 mod 7 = 4", "Date: 1 -> 1 odd day", "Total = 1 + 4 + 1 = 6 -> Saturday"], a: "Saturday" },
           { q: "5 March 2021 was a Friday. What day was 5 March 2024?", s: ["Mar 2021 -> Mar 2022: 365 days = 1 odd day", "-> Mar 2023: 1 odd day", "-> Mar 2024 crosses 29 Feb 2024: 366 days = 2 odd days", "Total 4 odd days: Friday + 4"], a: "Tuesday" },
           { q: "A leap year has 53 Sundays. On which days can 1 January fall?", s: ["A leap year has 52 weeks + 2 extra consecutive days", "To get a 53rd Sunday, Sunday must be one of these two extra days", "Extra days are (Sat, Sun) or (Sun, Mon)"], a: "1 January is a Saturday or a Sunday" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["What day of the week was 26 January 1950?", "Thursday"],
           ["How many leap years are there from 2000 to 2100 inclusive?", "f(2100) - f(1999) = 509 - 484 = 25"],
           ["How many odd days are there in 200 years?", "3 odd days"],
           ["In a non-leap year, which month begins on the same weekday as January?", "October"],
           ["Today is Wednesday. What day was it 75 days ago?", "75 mod 7 = 5; Wednesday minus 5 days = Friday"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Why are century years special?", "In the Gregorian calendar a century year is a leap year only if divisible by 400, so 1900 was not a leap year but 2000 was."],
           ["Why does the calendar repeat every 400 years?", "400 years contain 146097 days, which is exactly 20871 weeks, so the weekday pattern restarts."],
           ["Should 29 February be counted in odd days?", "Yes, if 29 February lies inside the period you are counting."],
           ["Do I include the start date when counting days between two dates?", "Normally not: subtract the dates directly. Include it only if the question says 'both days inclusive'."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Odd days", "The remainder when a number of days is divided by 7."], ["Ordinary (common) year", "A year with 365 days."], ["Leap year", "A year with 366 days (extra day on 29 February)."], ["Century year", "A year ending in 00, such as 1900 or 2000."], ["Weekday code", "Numbers 0 to 6 assigned to Sunday to Saturday."], ["Day of the year", "The position of a date counted from 1 January (1 to 365/366)."]] }
  ],
  revise: ["Ordinary = 1 odd day", "Leap = 2 odd days", "100y=5, 200y=3, 300y=1, 400y=0", "0 = Sunday ... 6 = Saturday", "Leap: /4 but centuries /400", "f(Y)=Y/4 - Y/100 + Y/400", "Month odd days 31->3, 30->2"]
},
/* ================================================================ PATTERN */
pattern: {
  intro: "Pattern recognition checks how quickly you spot a rule. Most number series fall into a handful of families. Learn the families, learn the difference-table method, and practise the figure rules - rotation, reflection, addition and counting.",
  sections: [
    { ic: "🔢", t: "Families of number series",
      b: ["**AP**: constant difference (3, 7, 11, 15).", "**GP**: constant ratio (2, 6, 18, 54).", "**Squares**: 1, 4, 9, 16, 25, 36, 49 ... and **cubes**: 1, 8, 27, 64, 125, 216.", "**Primes**: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47.", "**Fibonacci**: each term is the sum of the previous two (1, 1, 2, 3, 5, 8, 13).", "**Triangular numbers**: 1, 3, 6, 10, 15, 21, 28, 36."],
      f: ["AP: Tn = a + (n - 1)d", "GP: Tn = a x r^(n-1)", "Triangular: n(n + 1) / 2", "Sum of first n numbers = n(n + 1) / 2", "Sum of squares = n(n + 1)(2n + 1) / 6"],
      tr: "Memorise squares to 25 and cubes to 12. About half of all series questions use them, sometimes with +1 or -1 attached." },
    { ic: "➖", t: "The difference-table method",
      p: ["When the rule is not obvious, write the differences between neighbours. Repeat on the differences. A constant row reveals the rule."],
      ex: [{ q: "Find the next term: 2, 6, 12, 20, 30, ?", s: ["1st differences: 4, 6, 8, 10", "2nd differences: 2, 2, 2 (constant)", "Next 1st difference = 12 -> 30 + 12"], a: "42" }],
      b: ["Constant 1st difference -> AP.", "Constant 2nd difference -> quadratic (n squared type).", "Constant 3rd difference -> cubic.", "Differences themselves forming a GP (1, 2, 4, 8) -> 'doubling jumps'."] },
    { ic: "✖️", t: "Mixed operation series",
      p: ["Look for 'multiply then add' or 'multiply by a growing number' patterns."],
      ex: [{ q: "Find the next term: 3, 7, 15, 31, ?", s: ["3 x 2 + 1 = 7, 7 x 2 + 1 = 15, 15 x 2 + 1 = 31", "31 x 2 + 1"], a: "63" },
           { q: "Find the next term: 2, 5, 10, 17, 26, ?", s: ["Terms are n squared + 1: 1+1, 4+1, 9+1, 16+1, 25+1", "Next is 6 squared + 1"], a: "37" }],
      b: ["Patterns like x1+1, x2+2, x3+3 are common.", "Alternating series: odd and even positions follow two different rules.", "If the series grows slowly, think addition; if it explodes, think multiplication or powers."] },
    { ic: "🔤", t: "Alphabet series and coding",
      b: ["Positions: A=1, B=2 ... Z=26. Opposite letter = 27 - position (A<->Z, B<->Y).", "Memory word **EJOTY** marks positions 5, 10, 15, 20, 25.", "Look for constant jumps (+2, +3), alternating jumps, or increasing jumps (+1, +2, +3).", "In coding-decoding, find the shift or substitution rule from the given pair, then apply it."],
      ex: [{ q: "Find the next letter: B, E, H, K, ?", s: ["Positions 2, 5, 8, 11 -> jump +3", "11 + 3 = 14"], a: "N" }],
      mi: "Wrapping around: after Z comes A again, so use mod 26." },
    { ic: "🔄", t: "Figure patterns: rotation, reflection and counting",
      b: ["**Rotation**: a shape turns by a fixed angle (45, 90, 135, 180 degrees) every step.", "**Reflection**: shapes flip about a vertical or horizontal axis.", "**Addition / removal**: one line, dot or shading is added or removed each step.", "**Shifting**: a shaded part or a dot moves one position clockwise/anticlockwise.", "Count sides, curves, dots and symmetry - these usually follow arithmetic rules."],
      f: ["Square dot pattern: n x n", "Triangular dot pattern: n(n + 1) / 2", "Centred hexagonal: 3n(n - 1) + 1"],
      ex: [{ q: "Triangular dots: 1, 3, 6, 10 ... how many dots in figure 8?", s: ["n(n + 1)/2 with n = 8", "8 x 9 / 2"], a: "36" }],
      tr: "When two rules seem to work, apply them to every figure in the row - only one will fit all of them." },
    { ic: "🧩", t: "Matrices, odd-one-out and strategy",
      p: ["In a 3 x 3 number matrix the rule normally works across rows or down columns: sum, product, difference or square."],
      ex: [{ q: "2 3 6 / 4 5 20 / 3 4 ?  Find ?", s: ["Row 1: 2 x 3 = 6, Row 2: 4 x 5 = 20", "Row 3: 3 x 4"], a: "12" }],
      b: ["Odd-one-out: check parity, prime/composite, divisibility, perfect squares, digit sums.", "Verify your rule on EVERY given term before answering.", "If stuck for more than 30 seconds, skip and return later."],
      mi: "Finding a rule that fits only the first three terms. A real rule fits all of them." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "Find the missing term: 4, 9, 19, 39, ?", s: ["4 x 2 + 1 = 9, 9 x 2 + 1 = 19, 19 x 2 + 1 = 39", "39 x 2 + 1"], a: "79" },
           { q: "Find the next term: 1, 2, 6, 24, 120, ?", s: ["Multipliers are 2, 3, 4, 5 (factorials)", "120 x 6"], a: "720" },
           { q: "Find the odd one out: 8, 27, 64, 100, 125", s: ["8 = 2 cubed, 27 = 3 cubed, 64 = 4 cubed, 125 = 5 cubed", "100 is not a perfect cube"], a: "100" },
           { q: "Find the 10th term of the AP 5, 9, 13, ...", s: ["a = 5, d = 4", "T10 = 5 + 9 x 4"], a: "41" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["3, 6, 11, 18, 27, ?", "Differences 3, 5, 7, 9 -> next difference 11 -> 38"],
           ["2, 4, 8, 14, 22, ?", "Differences 2, 4, 6, 8 -> next 10 -> 32"],
           ["AZ, BY, CX, ?", "First letters go forward, second letters go backward -> DW"],
           ["1, 4, 27, 16, 125, 36, ?", "Odd positions are cubes of odd numbers (1, 27, 125), even positions squares of even numbers -> 7 cubed = 343"],
           ["What is the sum of the first 20 natural numbers?", "20 x 21 / 2 = 210"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["How do I decide between a difference rule and a ratio rule?", "If terms grow slowly, test differences first; if they grow very fast (doubling, tripling), test ratios."],
           ["What if two different rules fit the given terms?", "Choose the simpler rule and confirm it on every term; if still tied, the question normally has additional terms."],
           ["How many terms do I need to be sure of a pattern?", "At least 4 or 5. Three terms can fit several rules."],
           ["Can a series use two rules alternately?", "Yes. Split odd and even positions and check each sub-series separately."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Term", "One number in a series."], ["Common difference (d)", "The constant gap between terms of an AP."], ["Common ratio (r)", "The constant multiplier between terms of a GP."], ["Prime number", "A number greater than 1 with only two factors, 1 and itself."], ["Factorial (n!)", "The product 1 x 2 x 3 x ... x n."], ["Fibonacci series", "A series where each term is the sum of the previous two."]] }
  ],
  revise: ["Differences -> AP / quad / cubic", "Constant ratio -> GP", "n(n+1)/2 triangular", "Squares to 25, cubes to 12", "Opposite letter = 27 - p", "EJOTY = 5,10,15,20,25", "x2+1 style rules"]
},
/* ================================================================ TABULAR */
tabular: {
  intro: "Tabular data interpretation is about reading numbers quickly and calculating smartly. Most marks are lost not by difficulty but by calculation time - so learn the standard formulas, approximation and fraction shortcuts.",
  sections: [
    { ic: "👀", t: "Reading a table correctly",
      b: ["Read the title, row headings, column headings and the **units** before touching a number (thousand, lakh, crore, percent).", "Check for footnotes such as 'figures in brackets are percentages'.", "Note missing or 'NA' entries - they may be derivable from totals.", "Decide the row and column you need, run a finger along both, and read the intersection."],
      mi: "Mixing units, for example comparing a value in lakh with a value in crore (1 crore = 100 lakh)." },
    { ic: "🧮", t: "Core formulas",
      f: ["Percentage = (part / whole) x 100", "Percentage change = (new - old) / old x 100", "Percentage points difference = % new - % old", "Average = total / number of items", "Ratio A:B = A / B (simplify)", "Weighted average = Sum(weight x value) / Sum(weight)", "CAGR = (End / Start)^(1/n) - 1"],
      ex: [{ q: "Sales rose from 80 to 120. What is the percentage increase?", s: ["(120 - 80) / 80 x 100", "= 40 / 80 x 100"], a: "50%" }] },
    { ic: "🔗", t: "Successive and compound changes",
      f: ["Successive changes a% then b% = a + b + ab/100 (%)"],
      ex: [{ q: "Price rises 20% then falls 10%. Net change?", s: ["20 + (-10) + (20 x -10)/100", "= 10 - 2"], a: "+8%" }],
      b: ["Percentage points and percent are different: 20% to 25% is +5 percentage points but +25% in relative terms.", "Increase then equal decrease is always a net loss."] },
    { ic: "⚡", t: "Fraction and approximation shortcuts",
      b: ["1/2 = 50%, 1/3 = 33.33%, 1/4 = 25%, 1/5 = 20%, 1/6 = 16.67%", "1/7 = 14.28%, 1/8 = 12.5%, 1/9 = 11.11%, 1/11 = 9.09%, 1/12 = 8.33%, 1/16 = 6.25%", "Round to the nearest 5 or 10 when options are far apart.", "Compare fractions by cross-multiplication instead of converting to decimals.", "To find 15% of a number: 10% + half of 10%."],
      tr: "If options differ by more than 5%, an estimate is enough - never calculate to the last decimal." },
    { ic: "🎯", t: "Typical question types and approach",
      b: ["**Max / min**: scan the column; do not calculate.", "**Total / average**: add row or column, divide.", "**Growth**: compare (new - old)/old, not just the difference.", "**Rank**: calculate the ratio or percentage for each and sort.", "**Which is higher**: cross-multiply two ratios.", "**Missing value**: use totals to back-calculate."],
      ex: [{ q: "Company A: 90 of 150 units sold. Company B: 80 of 120. Who has the higher sale ratio?", s: ["A: 90/150 = 0.60", "B: 80/120 = 0.667"], a: "Company B" }] },
    { ic: "⚠️", t: "Common mistakes and time management",
      b: ["Reading the wrong row/column - underline them lightly.", "Using the wrong base in percentages (new instead of old).", "Mixing years or units across questions of the same set.", "Spending 3 minutes on one question; skip and return."],
      tr: "Spend 60-90 seconds scanning the table and its units BEFORE answering the first question." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "Sales (Rs lakh): 2021 = 240, 2022 = 300, 2023 = 360. Find the growth each year and the CAGR.", s: ["2021 to 2022: 60/240 = 25%", "2022 to 2023: 60/300 = 20%", "CAGR = sqrt(360/240) - 1 = sqrt(1.5) - 1"], a: "25%, 20%; CAGR about 22.47% (simple average 22.5%)" },
           { q: "A is 40% of 500 and B is 35% of 400. Which is larger and by how much?", s: ["A = 0.40 x 500 = 200", "B = 0.35 x 400 = 140"], a: "A is larger by 60" },
           { q: "Class A: 30 students with average 60. Class B: 20 students with average 70. Combined average?", s: ["Total marks = 30 x 60 + 20 x 70 = 1800 + 1400 = 3200", "3200 / 50"], a: "64" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["Profit is 45 on revenue of 360. What is the profit margin?", "45/360 x 100 = 12.5%"],
           ["Cost rises from 250 to 300. Percentage rise?", "50/250 x 100 = 20%"],
           ["Simplify the ratio 120 : 180.", "Divide by 60 -> 2 : 3"],
           ["A price falls 20% then rises 25%. Net change?", "-20 + 25 + (-20 x 25)/100 = 0%"],
           ["The average of 5 numbers is 18 and the sum of four of them is 70. Find the fifth.", "Total = 90, fifth = 90 - 70 = 20"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["What is the difference between percent and percentage points?", "Going from 20% to 25% is +5 percentage points but a 25% relative increase (5/20)."],
           ["Which base do I use for 'A is more than B by what percent'?", "The base is B, the quantity being compared to: (A - B)/B x 100."],
           ["Should I convert fractions to decimals?", "Usually no. Keep fractions or common percent equivalents (1/8 = 12.5%) - faster and more accurate."],
           ["What do I do if units differ between two tables?", "Convert everything to one unit first, for example lakh to crore, before comparing."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Row / column / cell", "Horizontal line, vertical line and single box of a table."], ["Base value", "The reference quantity on which a percentage is calculated."], ["Percentage point", "The arithmetic difference between two percentages."], ["CAGR", "Compound annual growth rate over several years."], ["Weighted average", "An average where some items count more than others."], ["Ratio", "A comparison of two quantities by division."]] }
  ],
  revise: ["% change = (new-old)/old x 100", "Percentage points != percent", "a + b + ab/100", "1/8 = 12.5%", "1/7 = 14.28%", "Check units first", "Estimate when options are far apart"]
},
/* ================================================================ BAR */
bar: {
  intro: "Bar graphs compare quantities using bar lengths. Questions ask you to read values, compute differences, ratios and percentages, and compare growth. Careful reading of scale and legend gives almost every mark.",
  sections: [
    { ic: "🧱", t: "Anatomy and types of bar graphs",
      b: ["Parts: title, x-axis (categories), y-axis (values with a scale), legend, gridlines, data labels.", "**Simple bar**: one value per category.", "**Grouped (clustered) bar**: several series side by side per category.", "**Stacked bar**: parts piled on top of each other; the total is the full height.", "**Horizontal bar**: same idea, rotated."] },
    { ic: "📏", t: "Reading values accurately",
      b: ["Find the scale step first (e.g. each gridline = 10 units).", "If a bar ends between gridlines, **interpolate**: a bar halfway between 40 and 50 is 45.", "Check whether the y-axis starts at zero - a truncated axis exaggerates differences.", "Match the colour with the legend before reading a grouped bar."],
      tr: "Use the edge of your answer sheet as a ruler to carry a bar top across to the axis." },
    { ic: "🧮", t: "Standard calculations",
      f: ["Difference = |A - B|", "A as % of B = A / B x 100", "A is more than B by = (A - B) / B x 100 %", "B is less than A by = (A - B) / A x 100 %", "Average = Sum / n", "Ratio A:B = A / B"],
      ex: [{ q: "Bar A = 60, Bar B = 80. A is what % of B? B is more than A by what %?", s: ["A/B x 100 = 60/80 x 100 = 75%", "(80 - 60)/60 x 100 = 33.33%"], a: "75% and 33.33%" }],
      mi: "Using the wrong base: 'more than' uses the smaller (compared-to) quantity as the base." },
    { ic: "🧊", t: "Stacked and grouped bars",
      p: ["In a stacked bar, the value of a lower segment is read directly, but the value of an upper segment is (top reading) - (bottom reading)."],
      ex: [{ q: "A stacked bar for 2023 ends at 90; the bottom segment ends at 55. What is the top segment?", s: ["90 - 55"], a: "35" }],
      b: ["In grouped bars, compare same-coloured bars across categories to see a trend.", "Total of a category in a stacked bar = full height."] },
    { ic: "⚖️", t: "Absolute change vs relative change",
      p: ["A bar that rose by 20 units might be a smaller growth than one that rose by 10 units from a lower base. Always compute percentages for 'growth' questions."],
      ex: [{ q: "X went from 50 to 70. Y went from 20 to 35. Which grew faster?", s: ["X: 20/50 = 40%", "Y: 15/20 = 75%"], a: "Y grew faster though X's absolute rise was larger" }] },
    { ic: "📊", t: "Statistics from a bar chart",
      b: ["Mean = sum of all bar values / number of bars.", "Median: sort values; the middle one (or average of the middle two).", "Mode: the value that repeats; range = max - min.", "Total of two series for each category = sum of their bars."],
      tr: "For averages, estimate with a 'working mean': subtract a convenient number (like 50) from each bar, average the differences, and add 50 back." },
    { ic: "⚠️", t: "Traps and exam tips",
      b: ["Different units on twin axes (left axis revenue, right axis profit).", "A bar may show percentages, not absolute numbers.", "Skim all questions of the set first to know which bars you need.", "Skip calculation-heavy questions first and attempt direct-reading ones."] },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "A stacked bar of total 120 has three segments in the ratio 2 : 3 : 7. Find the largest segment.", s: ["Total parts = 12", "Largest = 7/12 x 120"], a: "70" },
           { q: "Bars: A = 45, B = 60, C = 75. By what percent is C above the average?", s: ["Average = (45 + 60 + 75)/3 = 60", "(75 - 60)/60 x 100"], a: "25%" },
           { q: "Bars for 2022, 2023, 2024 are 80, 100, 90. Find the growth in 2023 and the fall in 2024.", s: ["Growth = 20/80 = 25%", "Fall = 10/100 = 10%"], a: "+25% then -10%" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["Bars are 30, 45 and 60. What is the ratio of the smallest to the largest?", "30 : 60 = 1 : 2"],
           ["By what percent does a bar rise from 40 to 50?", "10/40 x 100 = 25%"],
           ["A = 80 and B = 64. A is what percent more than B?", "16/64 x 100 = 25%"],
           ["Find the median of the bars 20, 30, 40, 50.", "(30 + 40)/2 = 35"],
           ["The total of 6 bars is 300. What is the average?", "300 / 6 = 50"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Can a bar graph show negative values?", "Yes. Such bars extend below the zero line; read them as negative numbers."],
           ["Does the width of a bar matter?", "No. In a bar graph only the height (or length) carries information, unlike a histogram."],
           ["How is a stacked bar different from a grouped bar?", "Stacked bars pile the series on top of each other; grouped bars place them side by side."],
           ["What if the bar top is between two gridlines?", "Estimate by interpolation, and choose the option closest to your estimate."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Axis", "A reference line (horizontal or vertical) carrying labels or scale."], ["Scale", "The value represented by each gridline step."], ["Legend", "The key matching colours or patterns to data series."], ["Grouped bar", "Bars of different series placed side by side."], ["Stacked bar", "Segments of different series stacked in one bar."], ["Interpolation", "Estimating a value between two known gridline values."]] }
  ],
  revise: ["Check scale and legend", "Interpolate between gridlines", "A is x% of B = A/B x 100", "More than: base = smaller", "Stacked top = total - bottom", "Growth = percent, not difference"]
},
/* ================================================================ PIE */
pie: {
  intro: "A pie chart shows how a whole is divided into parts. The whole is 100 percent or 360 degrees. Every pie question reduces to converting between percentage, angle and actual value.",
  sections: [
    { ic: "🥧", t: "Anatomy of a pie chart",
      b: ["The full circle = 360 degrees = 100%.", "Each sector's size is proportional to its share.", "**1% = 3.6 degrees** and 1 degree = 0.2777 %.", "Data may be given as percentages, degrees or actual values - convert to the form you need.", "A doughnut chart works the same way."] },
    { ic: "🔁", t: "Conversion formulas",
      f: ["Angle = (value / total) x 360", "Value = (angle / 360) x total", "Percentage = (angle / 360) x 100", "Value = (percentage / 100) x total", "Missing sector angle = 360 - sum of the other angles"],
      ex: [{ q: "Total budget is 1200. A sector shows 25%. Find its value and its angle.", s: ["Value = 25/100 x 1200 = 300", "Angle = 25 x 3.6"], a: "300 and 90 degrees" }] },
    { ic: "⚡", t: "Angle - percentage shortcuts",
      b: ["36 degrees = 10%, 72 degrees = 20%, 90 degrees = 25%, 108 degrees = 30%", "120 degrees = 33.33%, 144 degrees = 40%, 180 degrees = 50%, 270 degrees = 75%", "To convert an angle to percent quickly: angle / 3.6.", "To convert percent to angle: percent x 3.6."] },
    { ic: "⚖️", t: "Ratios and comparisons in one pie",
      p: ["Inside a single pie, the ratio of two sectors equals the ratio of their angles, their percentages and their values."],
      ex: [{ q: "In a pie, Food has 72 degrees and Rent has 108 degrees. What is Food : Rent?", s: ["72 : 108 = 2 : 3"], a: "2 : 3" }] },
    { ic: "👯", t: "Two-pie and combined problems",
      p: ["Percentages from two different pies cannot be compared directly - first convert each to actual values using each pie's own total."],
      ex: [{ q: "Pie A (total 2000): men are 40%. Pie B (total 3000): men are 30%. In which pie are there more men?", s: ["A: 40% of 2000 = 800", "B: 30% of 3000 = 900"], a: "Pie B (900 vs 800)" }],
      mi: "Concluding that 40% > 30% means more men - without checking the totals." },
    { ic: "⚠️", t: "Common mistakes and tips",
      b: ["Sector percentages must sum to 100 - use this to find a missing one.", "Do not measure angles by eye; use the given labels.", "When the total changes (e.g. 'if the total rises by 10%'), recompute each sector value.", "Round only at the final step."],
      tr: "Convert everything to percentages first if the question compares only sectors of the same pie." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "A pie shows 1500 students. The Arts sector has an angle of 54 degrees. How many students study Arts?", s: ["54/360 x 1500", "= 0.15 x 1500"], a: "225 students" },
           { q: "Two sectors have angles 72 and 108 degrees and the total is 600. Find the difference in their values.", s: ["Difference in angle = 36 degrees", "36/360 x 600"], a: "60" },
           { q: "Savings are 15% of an income of Rs 48,000. Later savings are 20% of Rs 60,000. By how much did savings change?", s: ["Before = 0.15 x 48000 = 7200", "After = 0.20 x 60000 = 12000"], a: "Rs 4800 increase" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["What is the angle for 12.5%?", "12.5 x 3.6 = 45 degrees"],
           ["A sector of 90 degrees in a pie of total 840 has what value?", "90/360 x 840 = 210"],
           ["Three sectors have angles 100, 80 and 60 degrees; the fourth sector is the rest. Find it.", "360 - 240 = 120 degrees"],
           ["Find the value and angle of a sector of 20% in a total of 450.", "Value = 90, angle = 72 degrees"],
           ["Two sectors are 30% and 45%. What is their ratio?", "30 : 45 = 2 : 3"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Why do all sector angles add up to 360 degrees?", "Because the sectors together make the whole circle, which is 360 degrees."],
           ["Can a sector percentage exceed 100?", "No. Each share is part of a whole, so it lies between 0 and 100 and all shares add up to 100."],
           ["How do I compare sectors from two pies?", "Convert each sector to an actual value using its own pie's total before comparing."],
           ["Do I need a protractor?", "No. Charts give percentages, degrees or values, so calculation is enough."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Sector", "One slice of the pie."], ["Central angle", "The angle of a sector at the centre of the circle."], ["Share / proportion", "The fraction of the total that a sector represents."], ["Doughnut chart", "A pie chart with a hollow centre."], ["Total", "The value of the whole pie (100% or 360 degrees)."], ["Complement", "The remaining part of the whole after some sectors are removed."]] }
  ],
  revise: ["1% = 3.6 degrees", "Angle = value/total x 360", "Value = % x total / 100", "Missing sector = 360 - sum", "Two pies: use actual values", "Ratio of sectors = ratio of angles"]
},
/* ================================================================ LINE */
line: {
  intro: "Line graphs show change over time. Read the values at each point, compute the change and growth rate, and use the slope to judge how fast things are changing.",
  sections: [
    { ic: "📈", t: "Reading a line graph",
      b: ["The x-axis is usually time; the y-axis is the measured quantity.", "Peaks are local maxima, troughs are local minima.", "A rising line means increase, falling means decrease, flat means no change.", "Where two lines cross, the two quantities are equal at that time.", "Read the exact value by tracing from the point to the axis."] },
    { ic: "🧮", t: "Change and growth rate",
      f: ["Absolute change = new - old", "Percentage growth = (new - old) / old x 100", "Average growth per period = (last - first) / number of periods", "CAGR = (End / Start)^(1/n) - 1"],
      ex: [{ q: "Revenue grows from 100 to 144 over 2 years. Find the CAGR.", s: ["End/Start = 1.44", "1.44^(1/2) = 1.2"], a: "20% per year" }] },
    { ic: "📐", t: "Slope versus percentage growth",
      p: ["A steeper segment means a larger absolute change, not always a larger percentage change. A rise of 20 from 40 is 50%, but a rise of 20 from 100 is only 20%."],
      ex: [{ q: "A rises 40 to 60. B rises 100 to 130. Larger percentage growth?", s: ["A: 20/40 = 50%", "B: 30/100 = 30%"], a: "A, even though B's line is steeper" }] },
    { ic: "↔️", t: "Two-line comparison problems",
      b: ["Revenue and cost lines: Profit = Revenue - Cost.", "Profit percentage = Profit / Cost x 100.", "The gap between lines = difference at that time.", "Ratio of the two lines at a point = value1 / value2."],
      ex: [{ q: "Revenue 150 and cost 120 in a year. Profit and profit %?", s: ["Profit = 150 - 120 = 30", "Profit % = 30/120 x 100"], a: "30 and 25%" }] },
    { ic: "🌊", t: "Averages, moving averages and index numbers",
      f: ["3-year moving average at year t = (v(t-1) + v(t) + v(t+1)) / 3", "Index = value / base value x 100"],
      ex: [{ q: "Values 10, 14, 18, 16. Find the 3-point moving averages.", s: ["(10+14+18)/3 = 14", "(14+18+16)/3 = 16"], a: "14 and 16" }],
      b: ["Moving averages smooth out ups and downs and show the trend.", "A base-year index of 100 makes growth easy to see (index 125 = 25% above base)."] },
    { ic: "⚠️", t: "Traps and tips",
      b: ["Check the y-axis scale - broken or non-zero axes can mislead.", "Years may be unevenly spaced.", "Use 'previous year' as the base for year-on-year growth.", "In multi-line graphs, match line style/colour with the legend."],
      tr: "To find the year with maximum percentage growth, compute (change / previous value) for each year - do not trust the steepest line." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "Sales: 2019 = 50, 2020 = 60, 2021 = 90, 2022 = 72. Which year had the highest percentage growth and what was the fall in 2022?", s: ["2020: 10/50 = 20%", "2021: 30/60 = 50%", "2022: -18/90 = -20%"], a: "2021 (50%); 2022 fell by 20%" },
           { q: "With base year 2020 = 100, the 2020 value is 250 and the 2023 value is 325. Find the 2023 index.", s: ["Index = 325 / 250 x 100"], a: "130" },
           { q: "Find the 3-point moving averages of 8, 12, 16, 20.", s: ["(8 + 12 + 16)/3 = 12", "(12 + 16 + 20)/3 = 16"], a: "12 and 16" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["What is the percentage rise from 80 to 100?", "20/80 x 100 = 25%"],
           ["Find the average of 12, 18, 24 and 30.", "84/4 = 21"],
           ["A value of 200 falls by 10% and then rises by 10%. What is the final value?", "200 x 0.9 x 1.1 = 198"],
           ["Find the CAGR when 100 grows to 121 in 2 years.", "sqrt(1.21) - 1 = 10%"],
           ["Revenue is 340 and cost 290. Find the profit and profit %.", "Profit = 50; 50/290 x 100 = 17.24%"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Does a steeper line always mean better growth?", "No. A steeper line means a bigger absolute change; percentage growth depends on the starting value."],
           ["Why are the points joined with lines?", "To show the trend between observations over time."],
           ["What if some years are missing on the x-axis?", "Check whether spacing is uneven; compute growth only between the given points."],
           ["Which base is used for year-on-year growth?", "The previous year's value."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Trend", "The general direction of the data over time."], ["Peak / trough", "The highest and lowest points of a line graph."], ["Growth rate", "The percentage change from one period to the next."], ["CAGR", "The constant yearly rate that gives the same overall growth."], ["Moving average", "The average of a sliding window of consecutive values."], ["Index number", "A value expressed as a percentage of a base-year value."]] }
  ],
  revise: ["Growth % = (new-old)/old x 100", "CAGR = (E/S)^(1/n) - 1", "Slope != percent growth", "Profit = revenue - cost", "Index = value/base x 100", "Check axis scale"]
},
/* ================================================================ SCATTER */
scatter: {
  intro: "A scatter diagram plots pairs of values (x, y) to reveal whether two variables are related. You learn to describe correlation, draw or use a line of best fit, and predict values.",
  sections: [
    { ic: "✨", t: "Variables and correlation",
      b: ["x is the independent variable, y is the dependent variable.", "**Positive correlation**: y rises as x rises.", "**Negative correlation**: y falls as x rises.", "**No correlation**: no visible trend.", "Correlation does **not** prove causation - ice cream sales and sunburn both rise in summer."] },
    { ic: "📉", t: "Correlation coefficient r",
      f: ["r = Sum[(x - x_mean)(y - y_mean)] / sqrt( Sum(x - x_mean)^2 x Sum(y - y_mean)^2 )", "R squared = r x r (share of variation explained)"],
      b: ["r lies between -1 and +1.", "|r| > 0.8: strong; 0.5-0.8: moderate; 0.3-0.5: weak; below 0.3: negligible.", "r = +1 or -1 means all points lie exactly on a straight line."] },
    { ic: "📏", t: "Line of best fit (regression)",
      f: ["Slope m = Sum[(x - x_mean)(y - y_mean)] / Sum(x - x_mean)^2", "Intercept c = y_mean - m x x_mean", "Prediction: y = m x + c"],
      ex: [{ q: "Points (1,2), (2,4), (3,5), (4,4), (5,5). Find the line of best fit and predict y at x = 6.", s: ["x_mean = 3, y_mean = 4", "Sxy = (-2)(-2)+(-1)(0)+0+0+(2)(1) = 6, Sxx = 10", "m = 6/10 = 0.6, c = 4 - 0.6 x 3 = 2.2", "y(6) = 0.6 x 6 + 2.2"], a: "y = 0.6x + 2.2, predicted y = 5.8" }] },
    { ic: "🎯", t: "Interpolation, extrapolation and prediction",
      b: ["**Interpolation**: predicting inside the range of the data - reliable.", "**Extrapolation**: predicting outside the range - risky.", "The line of best fit always passes through the mean point (x_mean, y_mean).", "Roughly half the points should lie above the line and half below."] },
    { ic: "🚩", t: "Outliers, clusters and non-linear patterns",
      b: ["An **outlier** is a point far from the rest; it can drag the line and change r a lot.", "**Clusters** suggest sub-groups in the data.", "A curved pattern means a straight-line model is a poor fit even if r is moderate.", "Always look at the picture, not only at r."] },
    { ic: "⚠️", t: "Exam approach and mistakes",
      b: ["Questions: describe the correlation, estimate y for a given x, identify an outlier, compare two scatter plots.", "To find which point has the highest y/x ratio, find the steepest line from the origin.", "Do not say 'x causes y' from a correlation.", "A slope that is steeper does not mean stronger correlation - strength depends on how tightly points hug the line."] },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "If r = 0.9, what is R squared and what does it mean?", s: ["R squared = 0.9 x 0.9 = 0.81"], a: "0.81, i.e. 81% of the variation in y is explained by x" },
           { q: "The line is y = 2x + 5. Predict y at x = 10 and find the residual if the actual y is 28.", s: ["Predicted y = 2 x 10 + 5 = 25", "Residual = actual - predicted = 28 - 25"], a: "Predicted 25, residual +3" },
           { q: "Points (1,3), (2,5), (3,7), (4,9) lie on a line. Find its equation.", s: ["Slope = (9 - 3)/(4 - 1) = 2", "Intercept = 3 - 2 x 1 = 1"], a: "y = 2x + 1 (and r = 1)" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["What does r = -0.95 tell you?", "A strong negative linear correlation."],
           ["Find the mean point of x = 2, 4, 6 and y = 3, 5, 10.", "(4, 6)"],
           ["Find the slope between (2, 4) and (6, 12).", "(12 - 4)/(6 - 2) = 2"],
           ["For y = 0.5x + 3, find y when x = 8.", "0.5 x 8 + 3 = 7"],
           ["Is extrapolation as reliable as interpolation?", "No. Predictions outside the observed range are less reliable."]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["If r is close to 0, are the variables unrelated?", "Only linearly unrelated. They may still have a curved relationship."],
           ["Should I delete an outlier?", "Do not delete it blindly. Check whether it is an error; otherwise report results with and without it."],
           ["What is the difference between r and R squared?", "r shows direction and strength; R squared is the share of variation in y explained by x."],
           ["Why does the best-fit line pass through the mean point?", "The least-squares method balances errors so the line always passes through (x_mean, y_mean)."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Correlation", "A measure of how two variables move together."], ["Regression line", "The straight line that best fits the points."], ["Residual", "Actual value minus predicted value."], ["Outlier", "A point that lies far away from the pattern."], ["Slope (m)", "The change in y for one unit change in x."], ["Intercept (c)", "The value of y when x is zero."]] }
  ],
  revise: ["r from -1 to +1", "Line passes through (x mean, y mean)", "m = Sxy / Sxx", "c = y mean - m x mean", "Interpolate, don't extrapolate", "Correlation != causation"]
},
/* ================================================================ HISTOGRAM */
histogram: {
  intro: "A histogram shows how continuous data is distributed across class intervals. Because the bars touch, area represents frequency. You will practise building frequency tables and computing mean, median and mode for grouped data.",
  sections: [
    { ic: "📶", t: "Histogram versus bar chart",
      b: ["Histogram: continuous data, bars touch, the x-axis is a number line of class intervals.", "Bar chart: separate categories with gaps between bars.", "**Class interval**: e.g. 10-20; **class width** h = upper - lower = 10.", "**Class mark (midpoint)** = (lower + upper) / 2.", "Class boundaries remove gaps between classes such as 10-19 and 20-29 (use 9.5-19.5)."] },
    { ic: "📋", t: "Frequency distribution tables",
      b: ["Tally the raw data into class intervals to get the frequency f.", "**Cumulative frequency** = running total of frequencies.", "**Relative frequency** = f / N, and percentage = f / N x 100.", "Total frequency N = sum of all f."],
      tr: "Always check that your frequencies add up to the number of raw observations." },
    { ic: "🧮", t: "Mean of grouped data",
      f: ["Mean = Sum(f x midpoint) / Sum(f)"],
      ex: [{ q: "Classes 0-10, 10-20, 20-30, 30-40, 40-50 with frequencies 5, 8, 15, 12, 5. Find the mean.", s: ["Midpoints 5, 15, 25, 35, 45", "Sum fx = 25 + 120 + 375 + 420 + 225 = 1165", "N = 45 -> 1165 / 45"], a: "25.89" }] },
    { ic: "📍", t: "Median and mode of grouped data",
      f: ["Median = L + ((N/2 - cf) / f) x h", "Mode = L + ((f1 - f0) / (2 f1 - f0 - f2)) x h"],
      ex: [{ q: "Same data as above. Find the median and the mode.", s: ["Cumulative f: 5, 13, 28, 40, 45; N/2 = 22.5 -> class 20-30", "Median = 20 + ((22.5 - 13)/15) x 10 = 26.33", "Mode class 20-30: f1 = 15, f0 = 8, f2 = 12", "Mode = 20 + (7 / (30 - 8 - 12)) x 10 = 27"], a: "Median = 26.33, Mode = 27" }],
      b: ["L = lower boundary of the median/modal class, h = class width, cf = cumulative frequency before the class."] },
    { ic: "↕️", t: "Unequal class widths",
      p: ["When class widths differ, bar height must be the **frequency density** so that area still represents frequency."],
      f: ["Frequency density = frequency / class width", "Frequency = density x class width"],
      ex: [{ q: "A class 20-30 has 15 observations and the class 30-50 has 20. Find the densities.", s: ["20-30: 15 / 10 = 1.5", "30-50: 20 / 20 = 1.0"], a: "1.5 and 1.0" }] },
    { ic: "🌄", t: "Shapes of distributions",
      b: ["**Symmetric**: mean = median = mode.", "**Right (positive) skew**: long tail on the right, mean > median > mode.", "**Left (negative) skew**: long tail on the left, mean < median < mode.", "**Bimodal**: two peaks.", "Empirical relation: Mode = 3 x Median - 2 x Mean."] },
    { ic: "⚠️", t: "Mistakes and exam tips",
      b: ["Using class limits instead of midpoints for the mean.", "Using N instead of N/2 to locate the median class.", "Forgetting frequency density with unequal widths.", "Reading the height of a bar as the class value instead of its frequency."] },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "Frequencies 4, 6, 10, 7, 3 for classes 0-10, 10-20, 20-30, 30-40, 40-50. How many are below 30 and what is the relative frequency of 20-30?", s: ["Below 30 = 4 + 6 + 10 = 20", "N = 30; relative frequency = 10/30"], a: "20 observations; 33.3%" },
           { q: "Class 10-20 has f = 30 and class 20-40 has f = 50. Find the frequency densities.", s: ["10-20: 30/10 = 3", "20-40: 50/20 = 2.5"], a: "3 and 2.5" },
           { q: "Classes 10-20, 20-30, 30-40 have frequencies 4, 6, 10. Find the mean.", s: ["Midpoints 15, 25, 35", "Sum fx = 60 + 150 + 350 = 560; N = 20"], a: "28" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["What is the class mark of the class 40-50?", "(40 + 50)/2 = 45"],
           ["What is the class width of 15-25?", "25 - 15 = 10"],
           ["Sum f = 50 and Sum fx = 1900. Find the mean.", "1900/50 = 38"],
           ["Find the mode when L = 20, f1 = 15, f0 = 8, f2 = 12 and h = 10.", "20 + (7/10) x 10 = 27"],
           ["In a right-skewed distribution, which is larger, the mean or the median?", "The mean is larger than the median."]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Why do histogram bars touch each other?", "Because the data is continuous, so one class ends exactly where the next begins."],
           ["In which class does a boundary value such as 20 go?", "By the usual convention each class includes its lower limit, so 20 goes to 20-30."],
           ["Is the grouped mean exact?", "No, it is an estimate because we assume every value lies at its class midpoint."],
           ["When must I use frequency density?", "Whenever class widths are unequal, so that area still equals frequency."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Class interval", "A range of values grouped together, such as 10-20."], ["Class width", "Upper limit minus lower limit of a class."], ["Frequency", "The number of observations in a class."], ["Cumulative frequency", "The running total of frequencies."], ["Modal class", "The class with the highest frequency."], ["Frequency density", "Frequency divided by class width."]] }
  ],
  revise: ["Mean = Sum fx / Sum f", "Median = L + ((N/2-cf)/f) h", "Mode = L + ((f1-f0)/(2f1-f0-f2)) h", "Density = f / width", "Mode = 3 median - 2 mean", "Midpoint = (lower+upper)/2"]
},
/* ================================================================ CASELET */
caselet: {
  intro: "A caselet is a short paragraph full of numbers with several questions below it. The secret is to convert the paragraph into a table, Venn diagram or tree before answering anything.",
  sections: [
    { ic: "📝", t: "How to attack a caselet",
      b: ["Read the whole paragraph once, then underline numbers and relationships.", "Decide the structure: sets (Venn), ratio/percentage split, successive change or an arrangement.", "Draw a table or Venn diagram and fill every number.", "Re-read the question and answer from your table - not from the paragraph."],
      tr: "Spend the first 2 minutes only on building the table. A good table makes each question a 10-second job." },
    { ic: "🔵", t: "Two-set Venn problems",
      f: ["n(A or B) = n(A) + n(B) - n(A and B)", "Only A = n(A) - n(A and B)", "Neither = Total - n(A or B)"],
      ex: [{ q: "In a survey of 500 people, 60% like tea, 50% like coffee and 20% like both. How many like neither?", s: ["Union = 60 + 50 - 20 = 90%", "Neither = 100 - 90 = 10%", "10% of 500"], a: "50 people" }] },
    { ic: "🟣", t: "Three-set Venn problems",
      f: ["n(A or B or C) = n(A) + n(B) + n(C) - n(A,B) - n(B,C) - n(A,C) + n(A,B,C)"],
      ex: [{ q: "In a class of 100: 60 Maths, 50 Physics, 40 Chemistry; 30 Maths+Physics, 20 Physics+Chem, 25 Maths+Chem; 10 all three. How many study none?", s: ["Union = 60 + 50 + 40 - 30 - 20 - 25 + 10 = 85", "None = 100 - 85"], a: "15 students" }],
      tr: "Fill the Venn diagram from the centre outwards: all three first, then exactly two, then exactly one." },
    { ic: "🥣", t: "Ratio and percentage caselets",
      p: ["Convert a ratio into actual parts using: part = ratio share / sum of ratio x total."],
      ex: [{ q: "A firm has 1000 employees, men : women = 3 : 2. 40% of men and 50% of women are graduates. How many graduates?", s: ["Men = 3/5 x 1000 = 600, women = 400", "Graduates = 40% of 600 + 50% of 400 = 240 + 200"], a: "440" }] },
    { ic: "🔗", t: "Successive change caselets",
      ex: [{ q: "A shop sells 400 items in January, 25% more in February, and 20% fewer in March than February. Total sales?", s: ["Feb = 400 x 1.25 = 500", "Mar = 500 x 0.8 = 400", "Total = 400 + 500 + 400"], a: "1300" }],
      b: ["Apply each change to the PREVIOUS period's value.", "Percent change multipliers: +25% -> x1.25, -20% -> x0.8."] },
    { ic: "↕️", t: "Minimum and maximum overlap",
      f: ["Maximum overlap = min(A, B)", "Minimum overlap = max(0, A + B - Total)"],
      ex: [{ q: "60 of 100 people like tea and 70 like coffee. What are the minimum and maximum who like both?", s: ["Max = min(60, 70) = 60", "Min = 60 + 70 - 100 = 30"], a: "Between 30 and 60" }] },
    { ic: "⚠️", t: "Common mistakes",
      b: ["Treating percentages of different bases as if they were of the same total.", "Double counting the 'both' group.", "Skipping the 'neither' group in a Venn diagram.", "Rounding too early - keep exact values until the answer."] },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "In a town 60% read newspaper A, 40% read B and 20% read both. What percent read neither?", s: ["Union = 60 + 40 - 20 = 80%", "Neither = 100 - 80"], a: "20%" },
           { q: "Three friends share Rs 4200 in the ratio 2 : 3 : 7. Find the largest share.", s: ["Total parts = 12", "Largest = 7/12 x 4200"], a: "Rs 2450" },
           { q: "A firm has 800 employees, 55% men. 30% of men and 40% of women are managers. How many managers?", s: ["Men = 440, women = 360", "Managers = 0.30 x 440 + 0.40 x 360 = 132 + 144"], a: "276" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["n(A) = 25, n(B) = 30, n(A and B) = 10. Find n(A or B).", "25 + 30 - 10 = 45"],
           ["Total = 80 and n(A or B) = 65. How many belong to neither?", "80 - 65 = 15"],
           ["Divide 360 in the ratio 4 : 5.", "160 and 200"],
           ["A quantity rises 20% and then falls 25%. Net change?", "1.2 x 0.75 = 0.9, so a 10% fall"],
           ["A = 70 and B = 60 out of 100. What is the minimum who are in both?", "70 + 60 - 100 = 30"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Where do I start in a long caselet?", "List all numbers and relationships, then build a table or Venn diagram before touching any question."],
           ["Percent of what? How do I find the base?", "Reread the sentence: 'of the men' means the base is the number of men, not the total."],
           ["What if the data is not enough?", "Check whether any hidden relationship (totals, ratios) gives another equation; if not, the answer is 'cannot be determined'."],
           ["Should I use fractions or decimals?", "Fractions are usually faster and more exact in caselets."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Caselet", "A short paragraph containing data and several questions."], ["Union", "Everything that is in at least one of the sets."], ["Intersection", "Everything that is in both sets."], ["Complement", "Everything outside a given set."], ["Inclusion-exclusion", "The method of adding sets and removing overlaps."], ["Successive change", "Percent changes applied one after another."]] }
  ],
  revise: ["Union = A + B - both", "Neither = total - union", "3-set inclusion-exclusion", "Part = ratio/sum x total", "+25% -> x1.25", "Build the table first"]
},
/* ================================================================ WEB / RADAR */
web: {
  intro: "A web (radar or spider) chart compares several quantities across many criteria on one picture. Each spoke is a criterion and the distance from the centre is its value. Exams ask you to read values, compare shapes and compute totals and averages.",
  sections: [
    { ic: "🕸", t: "Anatomy of a radar chart",
      b: ["Spokes (axes) radiate from the centre, one per criterion.", "Concentric rings mark equal scale steps; the centre is zero (or the minimum).", "Each entity is a polygon joining its points on every spoke.", "A legend maps colours to entities."] },
    { ic: "👁", t: "Reading values",
      b: ["Count how many rings out the point lies and multiply by the step.", "Interpolate between rings (halfway between 60 and 80 is 70).", "Check the scale of each axis - some radar charts use different scales for different spokes.", "Look at the direction of the point: always read along its own spoke."] },
    { ic: "🧮", t: "Calculations",
      f: ["Total score = Sum of all spoke values", "Average = Total / number of spokes", "Difference on a spoke = |value A - value B|", "Weighted score = Sum(weight x value)", "Polygon area = 1/2 x sin(360 / n) x Sum(r_i x r_(i+1))"],
      ex: [{ q: "Candidate A scores 80, 60, 70, 90. Candidate B scores 70, 80, 75, 80. Who has the higher average?", s: ["A: 300 / 4 = 75", "B: 305 / 4 = 76.25"], a: "B (76.25 vs 75)" }] },
    { ic: "⚖️", t: "Comparing shapes",
      b: ["A **larger polygon** generally means better overall performance.", "A **balanced (round) polygon** = consistent; a **spiky** one = strong in a few areas, weak in others.", "Where polygons overlap, the two entities are equal on that spoke.", "The farthest point from the centre is the strongest criterion for that entity."] },
    { ic: "🔍", t: "Strengths, weaknesses and ranking",
      b: ["Rank criteria for one entity by comparing spoke values.", "To rank entities by criterion, compare their points on that spoke.", "To find the most improved criterion, subtract the old value from the new on each spoke (for two radar charts of different years).", "Use totals and averages when the question says 'overall'."],
      ex: [{ q: "On the Physics spoke X scores 85 and Y scores 70. By what percentage is X higher than Y?", s: ["(85 - 70) / 70 x 100"], a: "21.43%" }] },
    { ic: "⚠️", t: "Pitfalls and tips",
      b: ["Area can mislead: changing the order of spokes changes the shape and area without changing the data.", "Do not compare spokes with different scales directly.", "Zero or missing values pull the polygon to the centre.", "If asked for an exact value and the point is between rings, state the estimate clearly."],
      tr: "Write the values for each entity in a small table first. Most radar questions then become simple tabular ones." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "A radar chart has 5 axes with values 60, 70, 80, 90, 50. Find the average and the strongest axis.", s: ["Sum = 350, average = 350/5", "Highest value 90 is on axis 4"], a: "Average 70; axis 4 is strongest" },
           { q: "On one spoke A = 84 and B = 70. By what percent is A higher than B?", s: ["(84 - 70)/70 x 100"], a: "20%" },
           { q: "Weights 30%, 20%, 50% with scores 80, 90, 70. Find the weighted score.", s: ["0.30 x 80 = 24", "0.20 x 90 = 18", "0.50 x 70 = 35"], a: "77" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["Find the average of 70, 80, 90 and 60.", "300/4 = 75"],
           ["A scores 75 and B scores 60 on a spoke. A is higher by what percent of B?", "15/60 x 100 = 25%"],
           ["Each ring is worth 20 and a point lies on the 3rd ring. What is its value?", "3 x 20 = 60"],
           ["A 4-axis radar has all radii equal to r. What is the polygon area?", "1/2 x sin 90 x (4 r squared) = 2 r squared"],
           ["Which shape shows a balanced performance: a spiky star or a near-circle?", "The near-circle."]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["Does the centre always mean zero?", "Usually yes, but always check the axis labels because some charts start rings at a minimum value."],
           ["Is a bigger area always better?", "Not necessarily. Area also depends on the order of the axes, so use it only as a rough guide."],
           ["Can I compare two spokes with different scales?", "Not directly. Convert both to the same scale or to percentages first."],
           ["How do I read a point between two rings?", "Estimate by interpolation, keeping the ring step in mind."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Spoke / axis", "A line from the centre representing one criterion."], ["Ring", "A concentric circle marking an equal scale step."], ["Polygon", "The closed shape joining an entity's points on all spokes."], ["Radar chart", "Another name for a web or spider chart."], ["Scale", "The value represented by each ring."], ["Benchmark", "A reference value or polygon used for comparison."]] }
  ],
  revise: ["Centre = zero", "Larger polygon = better overall", "Average = total / spokes", "Read along the spoke", "Check axis scales", "Convert to a table first"]
},
/* ================================================================ MISSING */
missing: {
  intro: "Missing data interpretation gives tables, charts or paragraphs with some values hidden. You recover them by using totals, averages, ratios and percentages. The method is always the same: find an equation that has exactly one unknown.",
  sections: [
    { ic: "🔎", t: "What is missing data interpretation?",
      b: ["Some cells are blank or marked with ?.", "Hints come from row totals, column totals, grand total, averages, ratios or percentages.", "The goal is to rebuild the whole table, then answer questions.", "Consistent data should never give negative counts or percentages above 100."] },
    { ic: "➕", t: "The row-column rule",
      f: ["Row total = sum of the cells in that row", "Column total = sum of the cells in that column", "Grand total = sum of row totals = sum of column totals"],
      ex: [{ q: "A row reads 12, ?, 20 with total 50. Find ?", s: ["? = 50 - 12 - 20"], a: "18" }],
      tr: "Always start with a row or column that has only ONE unknown." },
    { ic: "🔁", t: "Iterative solving",
      p: ["Solve one unknown, then re-scan: each solved value unlocks another equation."],
      b: ["Step 1: list all equations (rows, columns, grand total).", "Step 2: pick any equation with exactly one unknown and solve it.", "Step 3: substitute the new value everywhere.", "Step 4: repeat until nothing is left or you are stuck.", "Step 5: verify that every row and column adds up."],
      mi: "Solving a cell correctly but forgetting to update the other equations that use it." },
    { ic: "📊", t: "Using averages",
      f: ["Total = average x number of items", "Missing value = total - sum of known values"],
      ex: [{ q: "The average of 5 numbers is 24. Four of them are 20, 25, 30 and 18. Find the fifth.", s: ["Total = 24 x 5 = 120", "Known sum = 20 + 25 + 30 + 18 = 93", "Fifth = 120 - 93"], a: "27" }] },
    { ic: "✖️", t: "Using ratios and percentages",
      f: ["If A : B = a : b then A / B = a / b (cross multiply)", "x% of T = x / 100 x T"],
      ex: [{ q: "Boys : girls = 3 : 4 and there are 28 girls. How many boys?", s: ["Boys / 28 = 3 / 4", "Boys = 28 x 3 / 4"], a: "21" }],
      b: ["Convert percentages into actual values once the total is known.", "Percent of percent: 40% of 50% of N = 0.2 N."] },
    { ic: "🧷", t: "Two unknowns - simultaneous equations",
      p: ["If a line has two unknowns, look for a second equation (a column, a ratio or a difference) that involves the same unknowns."],
      ex: [{ q: "x + y = 30 and x - y = 6. Find x and y.", s: ["Add the equations: 2x = 36 -> x = 18", "y = 30 - 18"], a: "x = 18, y = 12" }],
      b: ["If you cannot find a second equation, the data is insufficient - say so.", "Check each solved value against all rows and columns."] },
    { ic: "✅", t: "Consistency checks and traps",
      b: ["Row totals must add up to the grand total, and so must column totals.", "A negative or fractional count of people signals an error.", "Percentages in a distribution must add up to 100.", "Beware of data that gives two different values for the same cell - the table is inconsistent."],
      tr: "After filling the table, re-add the grand total from rows AND from columns. If both agree, the table is almost certainly right." },
    { ic: "🧠", t: "Advanced solved problems",
      ex: [{ q: "A 2 x 2 table has row totals 30 and 50, column totals 45 and 35, and the top-left cell is 20. Find all cells.", s: ["Top-right = 30 - 20 = 10", "Bottom-left = 45 - 20 = 25", "Bottom-right = 50 - 25 = 25 (check column 2: 10 + 25 = 35)"], a: "20, 10, 25, 25" },
           { q: "The average of 6 numbers is 15. After removing one number the average of the rest is 14. Find the removed number.", s: ["Total = 90, remaining total = 5 x 14 = 70", "Removed = 90 - 70"], a: "20" },
           { q: "A : B = 2 : 3 and B : C = 4 : 5. Find A : B : C.", s: ["Make B equal: A : B = 8 : 12 and B : C = 12 : 15"], a: "8 : 12 : 15" }] },
    { ic: "❓", t: "Practice questions with answers (try first!)",
      qa: [["x / 12 = 5 / 6. Find x.", "x = 12 x 5/6 = 10"],
           ["The average of 4 numbers is 25. Three of them are 20, 30 and 22. Find the fourth.", "Total = 100; 100 - 72 = 28"],
           ["35% of N is 42. Find N.", "N = 42 / 0.35 = 120"],
           ["A row total is 90 and two cells are 25 and 40. Find the third cell.", "90 - 65 = 25"],
           ["The grand total is 300 and two row totals are 120 and 100. Find the third row total.", "300 - 220 = 80"]] },
    { ic: "🤔", t: "Frequently asked doubts",
      qa: [["What should I do when a row has two unknowns?", "Look for a column or ratio that contains one of them; solve that first, then return to the row."],
           ["What if the data seems to contradict itself?", "Re-check each value you solved; if two totals still disagree, the table is inconsistent."],
           ["Can a missing value be negative?", "Not for counts or amounts of money. A negative result usually means an arithmetic slip."],
           ["How do I know there is not enough data?", "When every remaining equation has two or more unknowns and you cannot find another independent equation."]] },
    { ic: "📖", t: "Glossary of key terms",
      terms: [["Unknown", "A value you must find, often marked ? or x."], ["Equation", "A statement that two expressions are equal."], ["Constraint", "A condition the data must satisfy, such as a row total."], ["Substitution", "Replacing a variable by its known value."], ["Consistent data", "Data in which all totals and equations agree."], ["Insufficient data", "Data that does not allow a unique answer."]] }
  ],
  revise: ["Start with one-unknown lines", "Row/column totals", "Total = average x n", "Cross multiply ratios", "Re-check grand total", "No negative counts"]
}
};

/* ---------- renderer ---------- */
const rich = (s) => String(s).split('**').map((p, i) => (i % 2 ? <b key={i}>{p}</b> : p));

function NotesView({ id, color }) {
  const N = NOTES[id], total = N.sections.length;
  const qaCount = N.sections.reduce((n, s) => n + (s.qa ? s.qa.length : 0), 0);
  const [open, setOpen] = useState({ 0: true });
  const [read, setRead] = useState(() => Store.get('read_' + id, []));
  const mark = (i) => {
    const r = read.includes(i) ? read.filter((x) => x !== i) : [...read, i];
    setRead(r); Store.set('read_' + id, r);
    if (r.length === total && !read.includes(i)) { fireConfetti(40); Sound.win(); toast('You finished all the notes of this module!', '🎓'); }
  };
  const goto = (i) => { setOpen({ ...open, [i]: true }); setTimeout(() => { const el = document.getElementById(id + '-s' + i); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 90); };
  const setAll = (v) => { const o = {}; N.sections.forEach((_, i) => { o[i] = v; }); setOpen(o); };
  const printNotes = () => { setAll(true); setTimeout(() => window.print(), 400); };
  return (
    <div className="notes">
      <div className="card notes-hero">
        <Ring pct={(read.length / total) * 100} size={96} color={color} />
        <div style={{ flex: 1, minWidth: 240 }}>
          <p>{N.intro}</p>
          <div className="eng-head" style={{ marginTop: 10, marginBottom: 0 }}>
            <span className="chip">📚 <b>{total}</b> sections</span>
            <span className="chip">❓ <b>{qaCount}</b> practice and FAQ questions</span>
            <span className="chip">✅ <b>{read.length}/{total}</b> read</span>
          </div>
        </div>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <button className="btn sm" onClick={() => setAll(true)}>Expand all</button>
          <button className="btn ghost sm" onClick={() => setAll(false)}>Collapse all</button>
          <button className="btn ghost sm" onClick={printNotes}>🖨 Print notes</button>
        </div>
      </div>
      <div className="notes-grid">
        <nav className="toc card">
          <h4>Contents</h4>
          {N.sections.map((s, i) => <button key={i} className={'toc-item' + (read.includes(i) ? ' read' : '')} onClick={() => goto(i)}><span>{read.includes(i) ? '✔' : s.ic}</span><span>{s.t}</span></button>)}
        </nav>
        <div className="note-list">
          {N.sections.map((s, i) => (
            <section key={i} id={id + '-s' + i} className={'note-sec' + (open[i] ? ' open' : '')} style={{ '--c': color, '--i': Math.min(i, 8) }}>
              <button className="note-head" onClick={() => setOpen({ ...open, [i]: !open[i] })}>
                <span className="n-ic">{s.ic}</span><span className="grow">{i + 1}. {s.t}</span>
                {read.includes(i) && <span className="read-badge">Read</span>}<span className="chev">▾</span>
              </button>
              {open[i] && (
                <div className="note-body">
                  {(s.p || []).map((x, k) => <p key={k}>{rich(x)}</p>)}
                  {s.b && <ul>{s.b.map((x, k) => <li key={k}>{rich(x)}</li>)}</ul>}
                  {(s.f || []).map((x, k) => <div className="formula" key={k}>{x}</div>)}
                  {[].concat(s.ex || []).map((e, k) => (
                    <div className="example" key={k}>
                      <div className="eq">✏️ Example: {e.q}</div>
                      <ol>{e.s.map((x, j) => <li key={j}>{x}</li>)}</ol>
                      <div className="ans">Answer: {e.a}</div>
                    </div>
                  ))}
                  {s.qa && <div style={{ marginTop: 8 }}>{s.qa.map((x, k) => <details key={k}><summary>Q{k + 1}. {x[0]}</summary><p style={{ marginTop: 8 }}><b>Answer:</b> {x[1]}</p></details>)}</div>}
                  {s.terms && <ul>{s.terms.map((x, k) => <li key={k}><b>{x[0]}</b> – {x[1]}</li>)}</ul>}
                  {s.tr && <div className="callout trick">💡 <b>Shortcut:</b> {rich(s.tr)}</div>}
                  {s.mi && <div className="callout mistake">⚠️ <b>Common mistake:</b> {rich(s.mi)}</div>}
                  <button className={'btn sm read-btn' + (read.includes(i) ? ' ghost' : ' green')} onClick={() => mark(i)}>{read.includes(i) ? 'Mark as unread' : '✔ Mark as read'}</button>
                </div>
              )}
            </section>
          ))}
          <div className="card revise"><h3>⚡ Quick revision</h3><div className="revise-chips">{N.revise.map((r, i) => <span key={i}>{r}</span>)}</div></div>
        </div>
      </div>
    </div>
  );
}