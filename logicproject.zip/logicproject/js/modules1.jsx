/* ============ modules1.jsx : Clock · Calendar · Figures & Pattern Recognition ============ */

/* ---------------- CLOCK ---------------- */
const clockAngle = (h, m) => { const a = Math.abs(30 * (h % 12) - 5.5 * m) % 360; return a > 180 ? 360 - a : a; };
const fmtT = (h, m) => `${h}:${String(m).padStart(2, '0')}`;
const mirrorTime = (h, m) => { const t = (h % 12) * 60 + m, r = (720 - t) % 720; return [Math.floor(r / 60) || 12, r % 60]; };
const toHMS = (mins) => {
  const secs = Math.round(mins * 60) % 43200;
  return `${Math.floor(secs / 3600) || 12}:${String(Math.floor((secs % 3600) / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}`;
};

function ClockSolver() {
  const [h, setH] = useState('4'), [m, setM] = useState('20'), [add, setAdd] = useState('45');
  const [live, setLive] = useState(false);
  const [now, setNow] = useState(new Date());
  useEffect(() => { if (!live) return; setNow(new Date()); const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, [live]);
  const valid = /^\d{1,2}$/.test(h) && /^\d{1,2}$/.test(m) && +h >= 1 && +h <= 12 && +m <= 59;
  const ok = live || valid;
  const H = live ? now.getHours() % 12 || 12 : +h, M = live ? now.getMinutes() : +m, S = live ? now.getSeconds() : null;
  const t = (H % 12) * 60 + M + (S ? S / 60 : 0);
  const addOk = /^-?\d{1,5}$/.test(add);
  let after = null;
  if (ok && addOk) { const r = ((((Math.floor(t) + +add) % 720) + 720) % 720); after = [Math.floor(r / 60) || 12, r % 60]; }
  const nextOv = (Math.floor((t * 11) / 720 + 1e-9) + 1) * 720 / 11;
  const k = Math.max(0, Math.floor((5.5 * t - 90) / 180 + 1e-9) + 1), nextRA = (90 + 180 * k) / 5.5;
  const ang = ok ? clockAngle(H, M) : 0;
  const mir = ok ? mirrorTime(H, M) : [0, 0];
  return (
    <div className="split">
      <div className="card">
        <h3>⏱ Enter a time</h3>
        <div className="form-row">
          <Field label="Hour (1 – 12)"><input value={h} disabled={live} maxLength={2} onChange={(e) => setH(e.target.value)} /></Field>
          <Field label="Minute (0 – 59)"><input value={m} disabled={live} maxLength={2} onChange={(e) => setM(e.target.value)} /></Field>
        </div>
        <label className="switch"><input type="checkbox" checked={live} onChange={(e) => setLive(e.target.checked)} /><span>Use live system clock</span></label>
        {!ok && <div className="err shake" key={h + m}>⚠ Hour must be 1–12 and minute 0–59 (whole numbers only).</div>}
        <div className="clock-box">{ok && <AnalogClock h={H} m={M} s={S} showAngle />}</div>
        {ok && <p style={{ textAlign: 'center', color: 'var(--muted)', marginTop: 8 }}>Time: <b>{fmtT(H, M)}{S !== null ? ':' + String(S).padStart(2, '0') : ''}</b></p>}
      </div>
      <div className="card">
        {ok && <>
          <h3>📐 Automatic analysis</h3>
          <div className="stats-grid">
            <Stat v={fmt(ang) + '°'} l="Smaller angle" /><Stat v={fmt(360 - ang) + '°'} l="Reflex angle" i={1} />
            <Stat v={fmtT(...mir)} l="Mirror image time" i={2} /><Stat v={toHMS(nextOv)} l="Next overlap of hands" i={3} />
            <Stat v={toHMS(nextRA)} l="Next 90° (right angle)" i={4} /><Stat v={fmt(30 * (H % 12) + M / 2) + '°'} l="Hour-hand angle (from 12)" i={5} />
          </div>
          <div className="steps">{`Angle = |30×H − 5.5×M| = |30×${H % 12} − 5.5×${M}| = ${fmt(Math.abs(30 * (H % 12) - 5.5 * M))}°`}</div>
          <h3 style={{ marginTop: 18 }}>➕ Time after / before N minutes</h3>
          <Field label="Minutes (negative for before)"><input value={add} maxLength={6} onChange={(e) => setAdd(e.target.value)} /></Field>
          {!addOk ? <div className="err shake" key={add}>⚠ Enter a whole number like 45 or -30.</div> : after && <div className="ok-msg">New time: <b>{fmtT(...after)}</b> (12-hour format)</div>}
        </>}
      </div>
    </div>
  );
}

function genClock() {
  const t = rand(1, 3);
  if (t === 1) {
    const h = rand(1, 12), m = rand(0, 59), raw = Math.abs(30 * (h % 12) - 5.5 * m), ans = clockAngle(h, m);
    return { text: `What is the smaller angle between the hour and minute hands at ${fmtT(h, m)}? (Use decimals if needed)`, visual: <div className="clock-box"><AnalogClock h={h} m={m} /></div>, answer: ans, unit: '°', tol: 0.01,
      explain: `Angle = |30H − 5.5M| = |30×${h % 12} − 5.5×${m}| = ${fmt(raw)}°\nSmaller angle = ${fmt(ans)}°` };
  }
  if (t === 2) {
    const h = rand(1, 11), m = rand(1, 59), [mh, mm] = mirrorTime(h, m);
    const pool = []; while (pool.length < 5) { const x = fmtT(rand(1, 12), rand(0, 59)); if (!pool.includes(x)) pool.push(x); }
    const { options, answer } = optionsFrom(fmtT(mh, mm), pool);
    return { text: `What is the mirror image of the time ${fmtT(h, m)} on a clock?`, visual: <div className="clock-box"><AnalogClock h={h} m={m} /></div>, options, answer,
      explain: `Mirror image = 11:60 − ${fmtT(h, m)} = ${fmtT(mh, mm)}` };
  }
  const h = rand(1, 10);
  return { text: `After how many minutes past ${h} o'clock will the hour and minute hands first overlap? (Answer to 2 decimals)`, answer: (60 * h) / 11, unit: 'min', tol: 0.011,
    explain: `Hands overlap when M = 60H/11 = 60×${h}/11 = ${fmt((60 * h) / 11, 4)} minutes past ${h}.` };
}

/* ---------------- CALENDAR ---------------- */
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
const mkDate = (y, m, d) => { const t = new Date(Date.UTC(2000, 0, 1)); t.setUTCFullYear(y, m, d); return t; };
const parseISO = (s) => { const mt = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return mt ? mkDate(+mt[1], +mt[2] - 1, +mt[3]) : null; };
const dayDiff = (a, b) => Math.round((b - a) / 86400000);
const fmtDate = (d) => `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
const dayOfYear = (d) => dayDiff(mkDate(d.getUTCFullYear(), 0, 1), d) + 1;
function ymd(a, b) {
  if (b < a) [a, b] = [b, a];
  let y = b.getUTCFullYear() - a.getUTCFullYear(), m = b.getUTCMonth() - a.getUTCMonth(), d = b.getUTCDate() - a.getUTCDate();
  if (d < 0) { m--; d += new Date(Date.UTC(b.getUTCFullYear(), b.getUTCMonth(), 0)).getUTCDate(); }
  if (m < 0) { y--; m += 12; }
  return [y, m, d];
}
function MonthGrid({ y, m, d }) {
  const first = mkDate(y, m, 1), start = first.getUTCDay();
  const dim = [31, isLeap(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m];
  const cells = [...Array(start).fill(null), ...Array.from({ length: dim }, (_, i) => i + 1)];
  return (
    <div key={y + '-' + m}>
      <h3 style={{ textAlign: 'center', marginTop: 8 }}>{MONTHS[m]} {y}</h3>
      <div className="cal-grid">
        {DAYS.map((x) => <div key={x} className="cal-h">{x.slice(0, 3)}</div>)}
        {cells.map((c, i) => <div key={i} style={{ '--i': i }} className={'cal-c' + (c === null ? ' empty' : '') + (c === d ? ' sel' : '') + (i % 7 === 0 ? ' sun' : '')}>{c}</div>)}
      </div>
    </div>
  );
}
function CalendarSolver() {
  const [d1, setD1] = useState(dKey(new Date()));
  const [d2, setD2] = useState('2026-12-31');
  const [n, setN] = useState('100');
  const a = parseISO(d1), b = parseISO(d2);
  const nOk = /^-?\d{1,6}$/.test(n);
  const addRes = a && nOk ? new Date(a.getTime() + +n * 86400000) : null;
  let diff = null;
  if (a && b) { const days = Math.abs(dayDiff(a, b)), [y, m, d] = ymd(a, b); diff = { days, w: Math.floor(days / 7), r: days % 7, y, m, d }; }
  return (
    <div className="split">
      <div className="stack">
        <div className="card">
          <h3>📅 Date inspector</h3>
          <Field label="Choose a date"><input type="date" value={d1} min="1600-01-01" max="2500-12-31" onChange={(e) => setD1(e.target.value)} /></Field>
          {!a ? <div className="err shake" key="e1">⚠ Please pick a valid date.</div> : (
            <div className="stats-grid">
              <Stat v={DAYS[a.getUTCDay()]} l="Day of the week" /><Stat v={isLeap(a.getUTCFullYear()) ? 'Leap year ✔' : 'Not leap ✘'} l={`Year ${a.getUTCFullYear()}`} i={1} />
              <Stat v={dayOfYear(a)} l="Day of the year" i={2} /><Stat v={(isLeap(a.getUTCFullYear()) ? 366 : 365) - dayOfYear(a)} l="Days left in year" i={3} />
              <Stat v={Math.ceil((dayOfYear(a) + mkDate(a.getUTCFullYear(), 0, 1).getUTCDay()) / 7)} l="Week of year" i={4} /><Stat v={dayOfYear(a) % 7} l="Odd days since 1 Jan" i={5} />
            </div>)}
        </div>
        <div className="card">
          <h3>↔ Difference between two dates</h3>
          <div className="form-row"><Field label="From"><input type="date" value={d1} onChange={(e) => setD1(e.target.value)} /></Field><Field label="To"><input type="date" value={d2} onChange={(e) => setD2(e.target.value)} /></Field></div>
          {!diff ? <div className="err shake" key="e2">⚠ Both dates are required.</div> : (
            <div className="stats-grid"><Stat v={diff.days} l="Total days" /><Stat v={`${diff.w}w ${diff.r}d`} l="Weeks + days" i={1} /><Stat v={`${diff.y}y ${diff.m}m ${diff.d}d`} l="Years/months/days" i={2} /><Stat v={diff.days % 7} l="Odd days (mod 7)" i={3} /></div>)}
        </div>
        <div className="card">
          <h3>➕ Add / subtract days</h3>
          <Field label="Number of days (negative = before)"><input value={n} maxLength={7} onChange={(e) => setN(e.target.value)} /></Field>
          {!nOk ? <div className="err shake" key={n}>⚠ Enter a whole number.</div> : a && <div className="ok-msg">{fmtDate(a)} {+n >= 0 ? '+' : '−'} {Math.abs(+n)} days = <b>{fmtDate(addRes)} ({DAYS[addRes.getUTCDay()]})</b></div>}
        </div>
      </div>
      <div className="card">{a ? <MonthGrid y={a.getUTCFullYear()} m={a.getUTCMonth()} d={a.getUTCDate()} /> : <p>Pick a date to see its calendar.</p>}</div>
    </div>
  );
}
function genCalendar() {
  const t = rand(1, 4);
  if (t === 1) {
    const y = rand(1950, 2050), m = rand(0, 11), d = rand(1, 28), dt = mkDate(y, m, d), ans = DAYS[dt.getUTCDay()];
    const { options, answer } = optionsFrom(ans, DAYS);
    return { text: `What day of the week is ${fmtDate(dt)}?`, options, answer, explain: `Counting odd days from a known reference date gives ${ans}. (Tip: leap years add 2 odd days, ordinary years 1.)` };
  }
  if (t === 2) {
    const y1 = rand(1900, 1980), y2 = y1 + rand(20, 60); let c = 0; for (let y = y1; y <= y2; y++) if (isLeap(y)) c++;
    return { text: `How many leap years are there from ${y1} to ${y2} (both inclusive)?`, answer: c, tol: 0, explain: `Leap years: divisible by 4 (but century years only if divisible by 400). Counting gives ${c}.` };
  }
  if (t === 3) {
    const y = rand(2000, 2030), a = mkDate(y, rand(0, 5), rand(1, 28)), b = new Date(a.getTime() + rand(30, 300) * 86400000), days = dayDiff(a, b);
    return { text: `How many days are there from ${fmtDate(a)} to ${fmtDate(b)}? (Exclude the start date, include the end date)`, answer: days, tol: 0, explain: `Subtract the two dates: ${days} days.` };
  }
  const di = rand(0, 6), N = rand(30, 400), ans = DAYS[(di + N) % 7], { options, answer } = optionsFrom(ans, DAYS);
  return { text: `Today is ${DAYS[di]}. What day of the week will it be after ${N} days?`, options, answer, explain: `${N} ÷ 7 leaves remainder ${N % 7} (odd days). ${DAYS[di]} + ${N % 7} days = ${ans}.` };
}

/* ---------------- FIGURES & PATTERNS ---------------- */
function detectSeries(a) {
  const n = a.length, eq = (x, y) => Math.abs(x - y) < 1e-9, diff = (arr) => arr.slice(1).map((v, i) => v - arr[i]);
  const allEq = (arr) => arr.length >= 2 && arr.every((v) => eq(v, arr[0]));
  const d1 = diff(a);
  if (allEq(d1)) return { name: 'Arithmetic Progression (AP)', rule: `Common difference d = ${fmt(d1[0], 3)}. Each term = previous + (${fmt(d1[0], 3)}).`, next: [1, 2, 3].map((k) => a[n - 1] + k * d1[0]) };
  if (a.every((v) => v !== 0)) {
    const rs = a.slice(1).map((v, i) => v / a[i]);
    if (allEq(rs)) return { name: 'Geometric Progression (GP)', rule: `Common ratio r = ${fmt(rs[0], 3)}. Each term = previous × ${fmt(rs[0], 3)}.`, next: [1, 2, 3].map((k) => a[n - 1] * Math.pow(rs[0], k)) };
  }
  if (n >= 4 && a.slice(2).every((v, i) => eq(v, a[i] + a[i + 1]))) {
    const nx = [...a]; for (let k = 0; k < 3; k++) nx.push(nx[nx.length - 1] + nx[nx.length - 2]);
    return { name: 'Fibonacci-type series', rule: 'Each term = sum of the previous two terms.', next: nx.slice(n) };
  }
  const d2 = diff(d1);
  if (allEq(d2)) { let dl = d1[d1.length - 1], last = a[n - 1]; const out = []; for (let k = 0; k < 3; k++) { dl += d2[0]; last += dl; out.push(last); }
    return { name: 'Quadratic pattern (squares-like)', rule: `1st differences: ${d1.join(', ')} → constant 2nd difference = ${fmt(d2[0], 3)}.`, next: out }; }
  const d3 = diff(d2);
  if (allEq(d3)) { let d2l = d2[d2.length - 1], dl = d1[d1.length - 1], last = a[n - 1]; const out = []; for (let k = 0; k < 3; k++) { d2l += d3[0]; dl += d2l; last += dl; out.push(last); }
    return { name: 'Cubic pattern (cubes-like)', rule: `Third differences are constant = ${fmt(d3[0], 3)}.`, next: out }; }
  if (d1.length >= 3 && d1.every((v) => v !== 0)) {
    const rs = d1.slice(1).map((v, i) => v / d1[i]);
    if (allEq(rs)) { let dl = d1[d1.length - 1], last = a[n - 1]; const out = []; for (let k = 0; k < 3; k++) { dl *= rs[0]; last += dl; out.push(last); }
      return { name: 'Differences form a GP', rule: `Differences ${d1.join(', ')} grow by ratio ${fmt(rs[0], 3)}.`, next: out }; }
  }
  if (n >= 6) {
    const odd = a.filter((_, i) => i % 2 === 0), even = a.filter((_, i) => i % 2 === 1), dO = odd[1] - odd[0], dE = even[1] - even[0];
    if (odd.every((v, i) => i === 0 || eq(v - odd[i - 1], dO)) && even.every((v, i) => i === 0 || eq(v - even[i - 1], dE))) {
      let lo = odd[odd.length - 1], le = even[even.length - 1]; const out = [];
      for (let k = 0; k < 3; k++) { if ((n + k) % 2 === 0) { lo += dO; out.push(lo); } else { le += dE; out.push(le); } }
      return { name: 'Two interleaved APs', rule: `Odd positions change by ${fmt(dO, 3)}, even positions change by ${fmt(dE, 3)}.`, next: out };
    }
  }
  return null;
}
function PatternSolver() {
  const [txt, setTxt] = useState('2, 6, 12, 20, 30');
  const parts = txt.split(/[\s,;]+/).filter(Boolean), nums = parts.map(Number);
  let error = '';
  if (parts.length < 4) error = 'Enter at least 4 numbers separated by commas.';
  else if (parts.length > 12) error = 'Maximum 12 numbers allowed.';
  else if (nums.some((x) => !isFinite(x))) error = 'Only numbers are allowed (example: 2, 6, 12, 20).';
  const res = !error ? detectSeries(nums) : null;
  const samples = ['3, 7, 11, 15, 19', '2, 6, 18, 54, 162', '1, 4, 9, 16, 25', '1, 1, 2, 3, 5, 8', '1, 8, 27, 64, 125', '2, 3, 5, 9, 17, 33'];
  return (
    <div className="split">
      <div className="card">
        <h3>🔢 Enter a number series</h3>
        <Field label="Numbers (comma separated)"><input value={txt} onChange={(e) => setTxt(e.target.value)} /></Field>
        {error && <div className="err shake" key={error}>⚠ {error}</div>}
        <div className="btn-row">{samples.map((s) => <button key={s} className="btn ghost sm" onClick={() => setTxt(s)}>{s}</button>)}</div>
        {!error && <div style={{ marginTop: 14 }}><LineChart key={txt} labels={[...nums, ...(res ? res.next : [])].map((_, i) => 'T' + (i + 1))} series={[{ name: 'Series', values: [...nums, ...(res ? res.next : [])] }]} predFrom={res ? nums.length : null} /></div>}
      </div>
      <div className="card">
        <h3>🧠 Pattern analysis</h3>
        {!error && (res ? (
          <div className="stack">
            <div className="ok-msg"><b>{res.name}</b></div>
            <div className="steps">{res.rule}</div>
            <div className="stats-grid">{res.next.map((v, i) => <Stat key={i} v={fmt(v, 3)} l={`Next term #${nums.length + i + 1}`} i={i} />)}</div>
            <p style={{ color: 'var(--muted)', fontSize: '.85rem' }}>The dashed pink line in the graph shows the predicted terms.</p>
          </div>
        ) : <div className="err">No standard pattern recognised. Try a longer series or a different type.</div>)}
      </div>
    </div>
  );
}
const FigureArrow = ({ ang, color = '#029EFF' }) => (
  <svg viewBox="0 0 60 60"><g transform={`rotate(${ang} 30 30)`}><path d="M30 6L45 30H35V54H25V30H15Z" fill={color} /></g></svg>
);
const DotFig = ({ n, kind }) => {
  const dots = [];
  if (kind === 'sq') for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) dots.push([c, r]);
  else for (let r = 0; r < n; r++) for (let c = 0; c <= r; c++) dots.push([c + (n - 1 - r) / 2, r]);
  return <svg viewBox={`-2 -2 ${n * 12 + 4} ${n * 12 + 4}`} style={{ width: 52, height: 52 }}>{dots.map(([x, y], i) => <circle key={i} cx={x * 12 + 6} cy={y * 12 + 6} r="4" fill={PALETTE[n % 8]} />)}</svg>;
};
function genPattern() {
  const t = pick(['num', 'num', 'letter', 'rot', 'dots']);
  if (t === 'num') {
    const k = rand(1, 6); let terms, ex;
    if (k === 1) { const s = rand(2, 20), d = rand(2, 9); terms = [0, 1, 2, 3, 4, 5].map((i) => s + i * d); ex = `AP: add ${d} each time.`; }
    else if (k === 2) { const s = rand(1, 5), r = rand(2, 3); terms = [0, 1, 2, 3, 4, 5].map((i) => s * Math.pow(r, i)); ex = `GP: multiply by ${r} each time.`; }
    else if (k === 3) { const c = rand(0, 9); terms = [1, 2, 3, 4, 5, 6].map((i) => i * i + c); ex = `Terms are n² + ${c}.`; }
    else if (k === 4) { terms = [1, 2, 3, 4, 5, 6].map((i) => i * i * i); ex = 'Terms are perfect cubes n³.'; }
    else if (k === 5) { const a = rand(1, 5), b = rand(2, 7); terms = [a, b]; while (terms.length < 6) terms.push(terms[terms.length - 1] + terms[terms.length - 2]); ex = 'Each term is the sum of the previous two.'; }
    else { const s = rand(1, 9), inc = rand(1, 4); terms = [s]; for (let i = 1; i < 6; i++) terms.push(terms[i - 1] + inc + i - 1); ex = `Differences increase by 1: +${inc}, +${inc + 1}, +${inc + 2}…`; }
    return { text: `Find the next number: ${terms.slice(0, 5).join(', ')}, ?`, answer: terms[5], tol: 0, explain: ex + `\nNext term = ${terms[5]}` };
  }
  if (t === 'letter') {
    const st = rand(0, 8), step = rand(2, 4), L = (i) => String.fromCharCode(65 + (((i % 26) + 26) % 26)), seq = [0, 1, 2, 3, 4].map((i) => L(st + i * step)), ans = L(st + 5 * step);
    const { options, answer } = optionsFrom(ans, [ans, ...shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')).slice(0, 6)]);
    return { text: `Find the next letter: ${seq.join(', ')}, ?`, options, answer, explain: `Each letter moves ${step} positions forward in the alphabet → ${ans}.` };
  }
  if (t === 'rot') {
    const step = pick([45, 90, 135, 180]), a0 = rand(0, 7) * 45, ans = (a0 + 4 * step) % 360;
    const pool = [0, 45, 90, 135, 180, 225, 270, 315], { options: angs, answer } = optionsFrom(ans, pool);
    return { text: 'Which figure completes the sequence?', answer,
      visual: <div className="fig-row">{[0, 1, 2, 3].map((i) => <React.Fragment key={i}><div className="fig" style={{ '--i': i }}><FigureArrow ang={(a0 + i * step) % 360} /></div><span className="arrow-t">→</span></React.Fragment>)}<div className="fig q">?</div></div>,
      options: angs.map((a) => <FigureArrow key={a} ang={a} color="#E62A89" />), explain: `The arrow rotates ${step}° clockwise at every step. Next angle = ${ans}°.` };
  }
  const kind = pick(['sq', 'tri']), N = rand(6, 9), ans = kind === 'sq' ? N * N : (N * (N + 1)) / 2;
  return { text: `Dots are arranged in a pattern. How many dots will Figure ${N} have?`, answer: ans, tol: 0,
    visual: <div className="fig-row">{[1, 2, 3, 4].map((n) => <div key={n}><div className="fig" style={{ '--i': n, width: 72, height: 72 }}><DotFig n={n} kind={kind} /></div><div className="fig-cap">Fig {n}</div></div>)}</div>,
    explain: kind === 'sq' ? `Figure n has n×n dots → ${N}² = ${ans}.` : `Figure n has n(n+1)/2 dots → ${N}×${N + 1}/2 = ${ans}.` };
}