/* ============ modules2.jsx : Tabular · Bar · Pie · Line · Scatter ============ */
const pctChange = (a, b) => (a === 0 ? 0 : ((b - a) / a) * 100);

/* ---------------- TABULAR ---------------- */
function genTable() {
  const names = shuffle(['Alpha', 'Bravo', 'Cosmo', 'Delta', 'Eclipse', 'Fusion', 'Gamma']).slice(0, rand(4, 5));
  const years = [2019, 2020, 2021, 2022, 2023];
  const data = names.map(() => { let v = rand(40, 120); return years.map(() => { v = Math.max(20, v + rand(-15, 30)); return v; }); });
  return { names, years, data };
}
function DataTable({ t, onEdit, hlRow = -1, hlCol = -1 }) {
  const max = Math.max(...t.data.flat());
  const colT = t.years.map((_, j) => sum(t.data.map((r) => r[j])));
  return (
    <div className="tbl-wrap"><table className="tbl">
      <thead><tr><th>Company</th>{t.years.map((y) => <th key={y}>{y}</th>)}<th>Total</th></tr></thead>
      <tbody>
        {t.data.map((r, i) => (
          <tr key={i}><td>{t.names[i]}</td>
            {r.map((v, j) => <td key={j} className={i === hlRow || j === hlCol ? 'hl' : ''} style={{ background: `rgba(2,158,255,${0.08 + (v / max) * 0.45})` }}>
              {onEdit ? <input className="cell-in" style={{ width: 70, textAlign: 'center' }} value={v} onChange={(e) => onEdit(i, j, e.target.value)} /> : v}</td>)}
            <td className="tot">{sum(r)}</td></tr>))}
        <tr><td>Total</td>{colT.map((v, j) => <td key={j} className="tot">{v}</td>)}<td className="tot">{sum(colT)}</td></tr>
      </tbody></table></div>
  );
}
function TabularSolver() {
  const [t, setT] = useState(() => genTable());
  const [ri, setRi] = useState(0), [ci, setCi] = useState(0), [err, setErr] = useState('');
  const edit = (i, j, v) => {
    if (v === '') v = '0';
    if (!/^\d{1,6}$/.test(v)) { setErr('Only whole, non-negative numbers (max 6 digits) are allowed in the table.'); return; }
    setErr(''); setT({ ...t, data: t.data.map((r, a) => r.map((x, b) => (a === i && b === j ? Number(v) : x))) });
  };
  const R = t.data[Math.min(ri, t.names.length - 1)], rIdx = Math.min(ri, t.names.length - 1), s = describe(R, t.years);
  const col = t.data.map((r) => r[ci]), cs = describe(col, t.names);
  return (
    <div className="stack">
      <div className="card">
        <h3>📋 Sales table (₹ crore) – edit any cell</h3>
        <DataTable t={t} onEdit={edit} hlRow={rIdx} hlCol={ci} />
        {err && <div className="err shake" key={err + Math.random()}>⚠ {err}</div>}
        <div className="btn-row"><button className="btn" onClick={() => { setT(genTable()); setErr(''); }}>🎲 Generate new data</button></div>
      </div>
      <div className="split">
        <div className="card">
          <h3>🏢 Company analysis</h3>
          <Field label="Select company"><select value={rIdx} onChange={(e) => setRi(+e.target.value)}>{t.names.map((n, i) => <option key={i} value={i}>{n}</option>)}</select></Field>
          <div className="stats-grid">
            <Stat v={s.total} l="Total (5 yrs)" /><Stat v={fmt(s.mean)} l="Average / yr" i={1} /><Stat v={`${s.maxL} (${s.max})`} l="Best year" i={2} />
            <Stat v={`${s.minL} (${s.min})`} l="Weakest year" i={3} /><Stat v={fmt(pctChange(R[0], R[R.length - 1])) + '%'} l={`Growth ${t.years[0]}→${t.years[4]}`} i={4} />
          </div>
          <BarChart key={rIdx} labels={t.years.map(String)} series={[{ name: t.names[rIdx], values: R }]} />
        </div>
        <div className="card">
          <h3>📆 Year analysis</h3>
          <Field label="Select year"><select value={ci} onChange={(e) => setCi(+e.target.value)}>{t.years.map((y, i) => <option key={y} value={i}>{y}</option>)}</select></Field>
          <div className="stats-grid">
            <Stat v={cs.total} l="Year total" /><Stat v={fmt(cs.mean)} l="Average" i={1} /><Stat v={cs.maxL} l="Top company" i={2} /><Stat v={fmt((cs.max / cs.total) * 100) + '%'} l="Top company share" i={3} />
          </div>
          <PieChart key={ci} labels={t.names} values={col} donut />
        </div>
      </div>
    </div>
  );
}
function genTabular() {
  const t = genTable(), ri = rand(0, t.names.length - 1), j = rand(0, 3), y = rand(0, 4), table = <DataTable t={t} />;
  const k = rand(1, 4);
  if (k === 1) return { text: `What is the total sales of ${t.names[ri]} over all five years? (₹ crore)`, visual: table, answer: sum(t.data[ri]), tol: 0, explain: `${t.data[ri].join(' + ')} = ${sum(t.data[ri])}` };
  if (k === 2) { const col = t.data.map((r) => r[y]), mx = Math.max(...col), { options, answer } = optionsFrom(t.names[col.indexOf(mx)], t.names, Math.min(4, t.names.length));
    return { text: `Which company had the highest sales in ${t.years[y]}?`, visual: table, options, answer, explain: `Highest value in ${t.years[y]} is ${mx} (${t.names[col.indexOf(mx)]}).` }; }
  if (k === 3) { const a = t.data[ri][j], b = t.data[ri][j + 1]; return { text: `Percentage change in ${t.names[ri]}'s sales from ${t.years[j]} to ${t.years[j + 1]}? (1 decimal; negative if a fall)`, visual: table, answer: pctChange(a, b), unit: '%', tol: 0.06, explain: `(${b} − ${a}) / ${a} × 100 = ${fmt(pctChange(a, b), 3)}%` }; }
  const col = t.data.map((r) => r[y]);
  return { text: `What is the average sales of all companies in ${t.years[y]}? (2 decimals if needed)`, visual: table, answer: sum(col) / col.length, tol: 0.011, explain: `${col.join(' + ')} = ${sum(col)}; ÷ ${col.length} = ${fmt(sum(col) / col.length, 3)}` };
}

/* ---------------- BAR ---------------- */
function BarSolver() {
  const [rows, setRows] = useState(() => ['Jan', 'Feb', 'Mar', 'Apr', 'May'].map((l) => ({ l, a: String(rand(30, 90)), b: String(rand(20, 80)) })));
  const [two, setTwo] = useState(true), [sort, setSort] = useState('none');
  const bad = rows.some((r) => isNaN(parseNum(r.a)) || (two && isNaN(parseNum(r.b))));
  let view = rows.map((r) => ({ l: r.l || '?', a: parseNum(r.a) || 0, b: parseNum(r.b) || 0 }));
  if (sort === 'asc') view = [...view].sort((x, y) => x.a - y.a); if (sort === 'desc') view = [...view].sort((x, y) => y.a - x.a);
  const A = view.map((v) => v.a), B = view.map((v) => v.b), L = view.map((v) => v.l);
  const sa = describe(A, L), sb = describe(B, L);
  return (
    <div className="split">
      <div className="card">
        <h3>✏️ Edit data</h3>
        <label className="switch"><input type="checkbox" checked={two} onChange={(e) => setTwo(e.target.checked)} /><span>Compare two series (grouped bars)</span></label>
        <RowsEditor rows={rows} setRows={setRows} maxRows={8} mk={(i) => ({ l: 'Item' + (i + 1), a: '50', b: '40' })}
          cols={[{ key: 'l', label: 'Label', type: 'text' }, { key: 'a', label: 'Series A', type: 'num' }, ...(two ? [{ key: 'b', label: 'Series B', type: 'num' }] : [])]} />
        {bad && <div className="err shake" key="bb">⚠ Highlighted cells need non-negative numbers (e.g. 45 or 12.5). They are treated as 0 for now.</div>}
        <div className="btn-row">
          <button className="btn ghost sm" onClick={() => setSort('asc')}>↑ Sort A</button><button className="btn ghost sm" onClick={() => setSort('desc')}>↓ Sort A</button>
          <button className="btn ghost sm" onClick={() => setSort('none')}>Original</button>
          <button className="btn sm" onClick={() => setRows(rows.map((r) => ({ ...r, a: String(rand(20, 95)), b: String(rand(20, 95)) })))}>🎲 Random</button>
        </div>
      </div>
      <div className="card">
        <BarChart key={String(two)} labels={L} series={two ? [{ name: 'Series A', values: A }, { name: 'Series B', values: B }] : [{ name: 'Series A', values: A }]} />
        <div className="stats-grid">
          <Stat v={fmt(sa.total)} l="Total (A)" /><Stat v={fmt(sa.mean)} l="Mean (A)" i={1} /><Stat v={fmt(sa.median)} l="Median (A)" i={2} /><Stat v={`${sa.maxL}: ${fmt(sa.max)}`} l="Highest (A)" i={3} />
          <Stat v={`${sa.minL}: ${fmt(sa.min)}`} l="Lowest (A)" i={4} /><Stat v={fmt(sa.range)} l="Range (A)" i={5} />
          {two && <><Stat v={fmt(sb.total)} l="Total (B)" i={6} /><Stat v={fmt(sa.total - sb.total)} l="Total A − B" i={7} /></>}
        </div>
      </div>
    </div>
  );
}
function genBar() {
  const set = pick([['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'], ['Maths', 'Physics', 'Chem', 'Bio', 'CS', 'Eng'], ['Tata', 'Honda', 'Kia', 'Audi', 'BMW', 'Ford']]);
  const labels = set.slice(0, rand(4, 6)), vals = uniqueVals(labels.length, 20, 95), chart = <BarChart labels={labels} series={[{ name: 'Value', values: vals }]} />;
  const k = rand(1, 4), i = rand(0, labels.length - 1); let j = rand(0, labels.length - 1); while (j === i) j = rand(0, labels.length - 1);
  if (k === 1) { const mx = Math.max(...vals), { options, answer } = optionsFrom(labels[vals.indexOf(mx)], labels); return { text: 'Which bar has the highest value?', visual: chart, options, answer, explain: `Tallest bar = ${labels[vals.indexOf(mx)]} (${mx}).` }; }
  if (k === 2) return { text: `What is the difference between the bars of ${labels[i]} and ${labels[j]}?`, visual: chart, answer: Math.abs(vals[i] - vals[j]), tol: 0, explain: `|${vals[i]} − ${vals[j]}| = ${Math.abs(vals[i] - vals[j])}` };
  if (k === 3) return { text: 'What is the total of all the bars?', visual: chart, answer: sum(vals), tol: 0, explain: `${vals.join(' + ')} = ${sum(vals)}` };
  return { text: `${labels[i]} is what percent of ${labels[j]}? (1 decimal)`, visual: chart, answer: (vals[i] / vals[j]) * 100, unit: '%', tol: 0.06, explain: `${vals[i]} / ${vals[j]} × 100 = ${fmt((vals[i] / vals[j]) * 100, 3)}%` };
}

/* ---------------- PIE ---------------- */
function PieSolver() {
  const [rows, setRows] = useState([{ l: 'Rent', v: '30' }, { l: 'Food', v: '25' }, { l: 'Travel', v: '15' }, { l: 'Savings', v: '20' }, { l: 'Other', v: '10' }]);
  const [donut, setDonut] = useState(false);
  const bad = rows.some((r) => isNaN(parseNum(r.v)));
  const vals = rows.map((r) => parseNum(r.v) || 0), tot = sum(vals);
  return (
    <div className="split">
      <div className="card">
        <h3>✏️ Edit sectors</h3>
        <RowsEditor rows={rows} setRows={setRows} maxRows={8} mk={(i) => ({ l: 'Part' + (i + 1), v: '10' })} cols={[{ key: 'l', label: 'Sector', type: 'text' }, { key: 'v', label: 'Value', type: 'num' }]} />
        {bad && <div className="err shake" key="pb">⚠ Values must be non-negative numbers.</div>}
        {tot === 0 && !bad && <div className="err">Total is zero – enter at least one positive value.</div>}
        <label className="switch"><input type="checkbox" checked={donut} onChange={(e) => setDonut(e.target.checked)} /><span>Donut style</span></label>
        <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Sector</th><th>Value</th><th>%</th><th>Angle</th></tr></thead>
          <tbody>{rows.map((r, i) => <tr key={i}><td>{r.l}</td><td>{fmt(vals[i])}</td><td>{fmt(tot ? (vals[i] / tot) * 100 : 0)}%</td><td>{fmt(tot ? (vals[i] / tot) * 360 : 0)}°</td></tr>)}
            <tr><td className="tot">Total</td><td className="tot">{fmt(tot)}</td><td className="tot">100%</td><td className="tot">360°</td></tr></tbody></table></div>
      </div>
      <div className="card">{tot > 0 ? <PieChart key={String(donut)} labels={rows.map((r) => r.l || '?')} values={vals} donut={donut} /> : <p>Add values to draw the chart.</p>}</div>
    </div>
  );
}
function genPie() {
  const names = pick([['Rent', 'Food', 'Travel', 'Savings', 'Misc'], ['Maths', 'Science', 'English', 'History', 'Arts'], ['Tea', 'Coffee', 'Juice', 'Milk', 'Soda']]);
  const units = [1, 1, 1, 1, 1]; for (let k = 0; k < 15; k++) units[rand(0, 4)]++;
  const pcts = units.map((u) => u * 5), total = pick([800, 1200, 1500, 2000, 2400]), vis = <><PieChart labels={names} values={pcts} unit="%" /><p style={{ textAlign: 'center', color: 'var(--muted)' }}>Total = <b>{total}</b></p></>;
  const i = rand(0, 4); let j = rand(0, 4); while (j === i) j = rand(0, 4);
  const k = rand(1, 4);
  if (k === 1) return { text: `What is the value of the "${names[i]}" sector?`, visual: vis, answer: (pcts[i] * total) / 100, tol: 0.01, explain: `${pcts[i]}% of ${total} = ${(pcts[i] * total) / 100}` };
  if (k === 2) return { text: `What is the central angle of the "${names[i]}" sector?`, visual: vis, answer: pcts[i] * 3.6, unit: '°', tol: 0.01, explain: `${pcts[i]}% × 360° = ${fmt(pcts[i] * 3.6)}°` };
  if (k === 3) return { text: `What is the difference in value between "${names[i]}" and "${names[j]}"?`, visual: vis, answer: (Math.abs(pcts[i] - pcts[j]) * total) / 100, tol: 0.01, explain: `|${pcts[i]}% − ${pcts[j]}%| of ${total} = ${(Math.abs(pcts[i] - pcts[j]) * total) / 100}` };
  const mx = Math.max(...pcts), ans = names[pcts.indexOf(mx)], { options, answer } = optionsFrom(ans, names);
  return { text: 'Which sector is the largest?', visual: vis, options, answer, explain: `${ans} has the biggest share (${mx}%).` };
}

/* ---------------- LINE ---------------- */
function LineSolver() {
  const [rows, setRows] = useState([2019, 2020, 2021, 2022, 2023, 2024].map((y) => ({ l: String(y), a: String(rand(40, 120)) })));
  const bad = rows.some((r) => isNaN(parseNum(r.a)));
  const vals = rows.map((r) => parseNum(r.a) || 0), labels = rows.map((r) => r.l || '?');
  const ch = vals.slice(1).map((v, i) => pctChange(vals[i], v)), diffs = vals.slice(1).map((v, i) => v - vals[i]);
  const bi = diffs.indexOf(Math.max(...diffs)), wi = diffs.indexOf(Math.min(...diffs)), n = vals.length - 1;
  const cagr = vals[0] > 0 && vals[n] > 0 ? (Math.pow(vals[n] / vals[0], 1 / n) - 1) * 100 : 0;
  return (
    <div className="split">
      <div className="card">
        <h3>✏️ Edit points</h3>
        <RowsEditor rows={rows} setRows={setRows} minRows={3} maxRows={10} mk={(i) => ({ l: 'P' + (i + 1), a: '60' })} cols={[{ key: 'l', label: 'Label', type: 'text' }, { key: 'a', label: 'Value', type: 'num' }]} />
        {bad && <div className="err shake" key="lb">⚠ Highlighted values must be non-negative numbers.</div>}
        <div className="btn-row"><button className="btn sm" onClick={() => setRows(rows.map((r) => ({ ...r, a: String(rand(30, 130)) })))}>🎲 Random</button></div>
        <div className="tbl-wrap" style={{ marginTop: 12 }}><table className="tbl"><thead><tr><th>Period</th><th>Change</th><th>% change</th></tr></thead>
          <tbody>{ch.map((c, i) => <tr key={i}><td>{labels[i]}→{labels[i + 1]}</td><td style={{ color: diffs[i] >= 0 ? 'var(--ok)' : 'var(--bad)' }}>{diffs[i] >= 0 ? '▲' : '▼'} {fmt(Math.abs(diffs[i]))}</td><td>{fmt(c)}%</td></tr>)}</tbody></table></div>
      </div>
      <div className="card">
        <LineChart labels={labels} series={[{ name: 'Value', values: vals }]} />
        <div className="stats-grid">
          <Stat v={fmt(sum(vals) / vals.length)} l="Average" /><Stat v={`${labels[bi + 1]} (+${fmt(diffs[bi])})`} l="Biggest rise" i={1} /><Stat v={`${labels[wi + 1]} (${fmt(diffs[wi])})`} l="Biggest fall / smallest rise" i={2} />
          <Stat v={fmt(pctChange(vals[0], vals[n])) + '%'} l="Overall change" i={3} /><Stat v={fmt(cagr) + '%'} l="CAGR (per period)" i={4} />
        </div>
      </div>
    </div>
  );
}
function genLine() {
  const labels = ['2018', '2019', '2020', '2021', '2022', '2023'], rev = uniqueVals(6, 60, 200), cost = rev.map((v) => Math.round(v * (0.5 + Math.random() * 0.3)));
  const chart = <LineChart labels={labels} series={[{ name: 'Revenue', values: rev }, { name: 'Cost', values: cost }]} />;
  const k = rand(1, 4), i = rand(0, 4);
  if (k === 1) return { text: `What is the % change in Revenue from ${labels[i]} to ${labels[i + 1]}? (1 decimal)`, visual: chart, answer: pctChange(rev[i], rev[i + 1]), unit: '%', tol: 0.06, explain: `(${rev[i + 1]} − ${rev[i]}) / ${rev[i]} × 100 = ${fmt(pctChange(rev[i], rev[i + 1]), 3)}%` };
  if (k === 2) { const d = rev.slice(1).map((v, x) => v - rev[x]), bi = d.indexOf(Math.max(...d)), { options, answer } = optionsFrom(labels[bi + 1], labels.slice(1), 4);
    return { text: 'In which year was the year-on-year rise in Revenue the highest? (If every year fell, choose the smallest fall)', visual: chart, options, answer, explain: `Largest change = ${d[bi]} landing in ${labels[bi + 1]}.` }; }
  if (k === 3) return { text: `What was the profit (Revenue − Cost) in ${labels[i]}?`, visual: chart, answer: rev[i] - cost[i], tol: 0, explain: `${rev[i]} − ${cost[i]} = ${rev[i] - cost[i]}` };
  return { text: 'What is the average Revenue over the six years? (2 decimals)', visual: chart, answer: sum(rev) / 6, tol: 0.011, explain: `${rev.join(' + ')} = ${sum(rev)}; ÷ 6 = ${fmt(sum(rev) / 6, 3)}` };
}

/* ---------------- SCATTER ---------------- */
function regress(pts) {
  const n = pts.length, mx = sum(pts.map((p) => p.x)) / n, my = sum(pts.map((p) => p.y)) / n;
  let sxy = 0, sxx = 0, syy = 0; pts.forEach((p) => { sxy += (p.x - mx) * (p.y - my); sxx += (p.x - mx) ** 2; syy += (p.y - my) ** 2; });
  const m = sxx ? sxy / sxx : 0, c = my - m * mx, r = sxx && syy ? sxy / Math.sqrt(sxx * syy) : 0;
  return { m, c, r, r2: r * r };
}
const corrWord = (r) => (Math.abs(r) < 0.3 ? 'No / negligible correlation' : (r > 0 ? 'Positive' : 'Negative') + (Math.abs(r) > 0.8 ? ' – strong' : Math.abs(r) > 0.5 ? ' – moderate' : ' – weak'));
function ScatterSolver() {
  const mk = (type) => { const out = []; for (let x = 1; x <= 12; x++) { const y = type === 'pos' ? 3 * x + rand(-5, 5) + 5 : type === 'neg' ? 60 - 4 * x + rand(-6, 6) : rand(10, 60); out.push(`${x}, ${y}`); } return out.join('\n'); };
  const [txt, setTxt] = useState(() => mk('pos')), [px, setPx] = useState('15');
  const lines = txt.split('\n').map((l) => l.trim()).filter(Boolean);
  let error = '', pts = [];
  if (lines.length < 3) error = 'Enter at least 3 points (one "x, y" pair per line).';
  else if (lines.length > 60) error = 'Maximum 60 points.';
  else for (let i = 0; i < lines.length; i++) { const p = lines[i].split(/[\s,;]+/).filter(Boolean).map(Number); if (p.length !== 2 || p.some((v) => !isFinite(v))) { error = `Line ${i + 1} must look like "x, y" with numbers only.`; break; } pts.push({ x: p[0], y: p[1] }); }
  if (!error && new Set(pts.map((p) => p.x)).size < 2) error = 'The x-values must not all be identical.';
  const reg = !error ? regress(pts) : null, pxOk = isFinite(Number(px)) && px.trim() !== '';
  return (
    <div className="split">
      <div className="card">
        <h3>✏️ Data points</h3>
        <Field label="One point per line: x, y"><textarea value={txt} onChange={(e) => setTxt(e.target.value)} style={{ minHeight: 220 }} /></Field>
        {error && <div className="err shake" key={error}>⚠ {error}</div>}
        <div className="btn-row"><button className="btn ghost sm" onClick={() => setTxt(mk('pos'))}>📈 Positive</button><button className="btn ghost sm" onClick={() => setTxt(mk('neg'))}>📉 Negative</button><button className="btn ghost sm" onClick={() => setTxt(mk('none'))}>🌫 None</button></div>
      </div>
      <div className="card">
        {reg && <>
          <ScatterChart key={txt.length + '' + reg.r.toFixed(3)} points={pts} line={reg} />
          <div className="stats-grid">
            <Stat v={fmt(reg.r, 3)} l="Correlation r" /><Stat v={fmt(reg.r2, 3)} l="R²" i={1} /><Stat v={`y = ${fmt(reg.m, 3)}x ${reg.c >= 0 ? '+' : '−'} ${fmt(Math.abs(reg.c), 3)}`} l="Line of best fit" i={2} /><Stat v={corrWord(reg.r)} l="Interpretation" i={3} />
          </div>
          <Field label="Predict y for x ="><input value={px} onChange={(e) => setPx(e.target.value)} /></Field>
          {!pxOk ? <div className="err shake" key={px}>⚠ Enter a valid number.</div> : <div className="ok-msg">Predicted y ≈ <b>{fmt(reg.m * Number(px) + reg.c, 3)}</b></div>}
        </>}
      </div>
    </div>
  );
}
function genScatter() {
  if (rand(0, 1) === 0) {
    const type = pick(['pos', 'neg', 'none']); let pts, r;
    do { pts = []; for (let x = 1; x <= 12; x++) pts.push({ x, y: type === 'pos' ? 3 * x + rand(-4, 4) + 5 : type === 'neg' ? 60 - 4 * x + rand(-5, 5) : rand(10, 60) }); r = regress(pts).r; }
    while (type === 'pos' ? r < 0.85 : type === 'neg' ? r > -0.85 : Math.abs(r) > 0.3);
    const opts = ['Positive correlation', 'Negative correlation', 'No correlation'];
    return { text: 'What kind of relationship does this scatter diagram show?', visual: <ScatterChart points={pts} />, options: opts, answer: type === 'pos' ? 0 : type === 'neg' ? 1 : 2,
      explain: type === 'none' ? 'Points are scattered with no trend → no correlation.' : `Points trend ${type === 'pos' ? 'upwards' : 'downwards'} (r ≈ ${fmt(r, 2)}).` };
  }
  const m = rand(2, 6) + rand(0, 9) / 10, c = rand(1, 20), x = rand(8, 20), pts = []; for (let i = 1; i <= 10; i++) pts.push({ x: i, y: m * i + c + rand(-3, 3) });
  return { text: `The line of best fit is y = ${fmt(m, 1)}x + ${c}. Using it, predict y when x = ${x}. (2 decimals)`, visual: <ScatterChart points={pts} line={{ m, c }} />, answer: m * x + c, tol: 0.011, explain: `y = ${fmt(m, 1)} × ${x} + ${c} = ${fmt(m * x + c, 3)}` };
}