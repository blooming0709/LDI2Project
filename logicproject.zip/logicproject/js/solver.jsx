/* ============ solver.jsx : Snap & Solve (image -> text -> answer) ============ */
const numsOf = (s) => (String(s).replace(/(\d),(?=\d{3}\b)/g, '$1').match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
const MON3 = '(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*';
const M3 = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

function findDates(t) {
  const l = t.toLowerCase(), out = [];
  const add = (idx, d, m, y) => { if (d >= 1 && d <= 31 && m >= 0 && m <= 11 && y >= 1000 && y <= 9999) out.push({ idx, date: mkDate(y, m, d) }); };
  let r, re1 = new RegExp('(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?' + MON3 + '\\.?,?\\s+(\\d{4})', 'g');
  while ((r = re1.exec(l))) add(r.index, +r[1], M3.indexOf(r[2]), +r[3]);
  let re2 = new RegExp(MON3 + '\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?,?\\s+(\\d{4})', 'g');
  while ((r = re2.exec(l))) add(r.index, +r[2], M3.indexOf(r[1]), +r[3]);
  let re3 = /(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/g;
  while ((r = re3.exec(l))) add(r.index, +r[1], +r[2] - 1, +r[3]);
  return out.sort((a, b) => a.idx - b.idx).map((x) => x.date);
}

/* returns {type, answer, steps[]} or null */
function solveQuestion(raw) {
  const t = String(raw).replace(/[×✕]/g, '*').replace(/÷/g, '/').replace(/[–—−]/g, '-').replace(/\s+/g, ' ').trim();
  const l = t.toLowerCase();
  const R = (type, answer, steps) => ({ type, answer: String(answer), steps });

  /* plain arithmetic expression */
  const ex = t.replace(/[=?]+\s*$/, '').trim();
  if (/^[\d+\-*/().\s^%]+$/.test(ex) && /\d\s*[+\-*/^]\s*\(?\d/.test(ex)) {
    try { const v = Function('"use strict";return (' + ex.replace(/\^/g, '**') + ')')(); if (isFinite(v)) return R('Arithmetic', fmt(v, 6), ['Evaluate: ' + ex, '= ' + fmt(v, 6)]); } catch (e) {}
  }

  /* number series */
  if (/series|next (number|term)|what comes next|find the next|missing number/.test(l)) {
    let part = t; const ci = t.lastIndexOf(':');
    if (ci > -1 && numsOf(t.slice(ci)).length >= 3) part = t.slice(ci);
    const a = numsOf(part);
    if (a.length >= 4) { const r = detectSeries(a); if (r) return R('Number series – ' + r.name, fmt(r.next[0], 4), [r.rule, 'Series used: ' + a.join(', '), 'Next three terms: ' + r.next.map((x) => fmt(x, 4)).join(', ')]); }
  }

  /* calendar: leap years */
  if (/leap/.test(l)) {
    const ys = (l.match(/\b\d{4}\b/g) || []).map(Number);
    if (/how many|number of|count/.test(l) && ys.length >= 2) {
      const f = (y) => Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400), a = Math.min(ys[0], ys[1]), b = Math.max(ys[0], ys[1]);
      return R('Calendar – leap years', f(b) - f(a - 1), ['Leap years up to Y = Y/4 - Y/100 + Y/400', `f(${b}) - f(${a - 1}) = ${f(b)} - ${f(a - 1)}`]);
    }
    if (ys.length === 1) return R('Calendar – leap year', isLeap(ys[0]) ? 'Yes, it is a leap year' : 'No, it is not a leap year', ['Rule: divisible by 4, but century years must be divisible by 400', `${ys[0]} -> ${isLeap(ys[0]) ? 'leap' : 'not leap'}`]);
  }

  /* calendar: day after / before N days */
  const wd = l.match(/(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/);
  const nd = l.match(/(\d+)\s*days/);
  if (wd && nd && /after|before|later|ago|from now/.test(l) && !findDates(t).length) {
    const di = DAYS.map((d) => d.toLowerCase()).indexOf(wd[1]), N = +nd[1], back = /before|ago/.test(l), r = N % 7, idx = (((di + (back ? -r : r)) % 7) + 7) % 7;
    return R('Calendar – day after N days', DAYS[idx], [`${N} mod 7 = ${r} odd days`, `${DAYS[di]} ${back ? '-' : '+'} ${r} day(s) = ${DAYS[idx]}`]);
  }
  const dates = findDates(t);
  if (dates.length >= 2 && /how many days|number of days|days between|difference|days from/.test(l)) {
    const d = Math.abs(dayDiff(dates[0], dates[1])); return R('Calendar – days between dates', d, [`${fmtDate(dates[0])} to ${fmtDate(dates[1])}`, `= ${d} days (${Math.floor(d / 7)} weeks and ${d % 7} days)`]);
  }
  if (dates.length >= 1 && /day|week/.test(l)) {
    const d = dates[0]; return R('Calendar – day of the week', DAYS[d.getUTCDay()], [`Date: ${fmtDate(d)}`, `Day of the year = ${dayOfYear(d)}`, `Weekday = ${DAYS[d.getUTCDay()]}`]);
  }

  /* clock */
  if (/clock|hands?\b|minute hand|hour hand/.test(l)) {
    const m = l.match(/(\d{1,2})\s*[:.]\s*(\d{2})/), o = l.match(/(\d{1,2})\s*o'?\s*clock/);
    let h = null, mi = 0;
    if (m) { h = +m[1]; mi = +m[2]; } else if (o) { h = +o[1]; mi = 0; }
    if (h !== null && h >= 1 && h <= 12 && mi >= 0 && mi <= 59) {
      if (/mirror/.test(l)) { const r = mirrorTime(h, mi); return R('Clock – mirror image', fmtT(...r), ['Mirror image = 11:60 - time', `11:60 - ${fmtT(h, mi)} = ${fmtT(...r)}`]); }
      if (/water/.test(l)) { const tt = (h % 12) * 60 + mi, r = (360 - tt + 720) % 720; return R('Clock – water image', fmtT(Math.floor(r / 60) || 12, r % 60), ['Water image = 5:60 - time']); }
      if (/overlap|coincide|together/.test(l) && mi === 0) return R('Clock – overlap', `${fmt(60 * h / 11, 4)} minutes past ${h}`, ['Overlap: M = 60H / 11', `M = 60 x ${h} / 11 = ${fmt(60 * h / 11, 4)}`]);
      const raw2 = Math.abs(30 * (h % 12) - 5.5 * mi), a = clockAngle(h, mi);
      return R('Clock – angle between hands', fmt(a) + ' degrees', ['Angle = |30H - 5.5M|', `= |30 x ${h % 12} - 5.5 x ${mi}| = ${fmt(raw2)} degrees`, raw2 > 180 ? `Smaller angle = 360 - ${fmt(raw2)} = ${fmt(a)} degrees` : 'Already the smaller angle']);
    }
  }

  /* pie: angle <-> value */
  const deg = l.match(/(\d+(?:\.\d+)?)\s*(?:°|degrees?)/), tot = l.match(/total\s*(?:of|is|=|:)?\s*(\d+(?:\.\d+)?)/);
  if (/pie|sector|central angle/.test(l) || (deg && tot)) {
    if (deg && tot) { const v = (+deg[1] / 360) * +tot[1]; return R('Pie chart – sector value', fmt(v, 4), ['Value = angle / 360 x total', `= ${deg[1]} / 360 x ${tot[1]} = ${fmt(v, 4)}`]); }
    const pc = l.match(/(\d+(?:\.\d+)?)\s*%/);
    if (pc && /angle/.test(l)) return R('Pie chart – central angle', fmt(+pc[1] * 3.6, 4) + ' degrees', ['Angle = percentage x 3.6', `= ${pc[1]} x 3.6 = ${fmt(+pc[1] * 3.6, 4)}`]);
  }

  /* percentage patterns */
  let m = l.match(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)/);
  if (m) { const v = (+m[1] * +m[2]) / 100; return R('Percentage of a number', fmt(v, 4), [`${m[1]}% of ${m[2]} = ${m[1]}/100 x ${m[2]}`, `= ${fmt(v, 4)}`]); }
  m = l.match(/(\d+(?:\.\d+)?)\s*is\s*what\s*(?:percent|percentage|%)\s*of\s*(\d+(?:\.\d+)?)/);
  if (m) { const v = (+m[1] / +m[2]) * 100; return R('Percentage', fmt(v, 4) + '%', [`${m[1]} / ${m[2]} x 100`, `= ${fmt(v, 4)}%`]); }
  m = l.match(/what\s*(?:percent|percentage|%)\s*of\s*(\d+(?:\.\d+)?)\s*is\s*(\d+(?:\.\d+)?)/);
  if (m) { const v = (+m[2] / +m[1]) * 100; return R('Percentage', fmt(v, 4) + '%', [`${m[2]} / ${m[1]} x 100`, `= ${fmt(v, 4)}%`]); }
  m = l.match(/(increase|decrease|change|growth|rise|fall|drop).*?from\s*(\d+(?:\.\d+)?)\s*to\s*(\d+(?:\.\d+)?)/);
  if (m && /percent|%/.test(l)) { const a = +m[2], b = +m[3], v = ((b - a) / a) * 100; return R('Percentage change', fmt(v, 4) + '%', ['Change % = (new - old) / old x 100', `= (${b} - ${a}) / ${a} x 100 = ${fmt(v, 4)}%`]); }

  /* ratio split */
  const rm = l.match(/(\d+)\s*:\s*(\d+)/);
  if (rm && /ratio|divide|share|distribute/.test(l)) {
    const n = numsOf(l.replace(rm[0], ' ')); if (n.length) {
      const T = n[0], a = +rm[1], b = +rm[2], s = a + b;
      return R('Ratio split', `${fmt((T * a) / s, 4)} and ${fmt((T * b) / s, 4)}`, [`Total parts = ${a} + ${b} = ${s}`, `First share = ${T} x ${a} / ${s} = ${fmt((T * a) / s, 4)}`, `Second share = ${T} x ${b} / ${s} = ${fmt((T * b) / s, 4)}`]);
    }
  }

  /* profit & loss */
  const cp = l.match(/cost price[^\d]*(\d+(?:\.\d+)?)/), sp = l.match(/selling price[^\d]*(\d+(?:\.\d+)?)/);
  if (cp && sp) { const c = +cp[1], s = +sp[1], d = s - c, p = (d / c) * 100; return R(d >= 0 ? 'Profit percentage' : 'Loss percentage', fmt(Math.abs(p), 4) + '%', [`CP = ${c}, SP = ${s}`, `${d >= 0 ? 'Profit' : 'Loss'} = ${fmt(Math.abs(d))}`, `% = ${fmt(Math.abs(d))} / ${c} x 100 = ${fmt(Math.abs(p), 4)}%`]); }

  /* two-set Venn */
  if (/neither|none of|both|at least one|only/.test(l)) {
    const toks = [...l.matchAll(/(\d+(?:\.\d+)?)\s*(%)?/g)].map((x) => ({ v: +x[1], p: !!x[2] }));
    let Tt, A, B, C, note = '';
    const plain = toks.filter((x) => !x.p), pcts = toks.filter((x) => x.p);
    if (plain.length >= 1 && pcts.length >= 3) { Tt = plain[0].v; A = (pcts[0].v * Tt) / 100; B = (pcts[1].v * Tt) / 100; C = (pcts[2].v * Tt) / 100; note = 'Assumed: total, then % in set A, % in set B, % in both (in that order).'; }
    else if (plain.length >= 4) { Tt = plain[0].v; A = plain[1].v; B = plain[2].v; C = plain[3].v; note = 'Assumed order of numbers: total, set A, set B, both.'; }
    if (Tt !== undefined && C <= Math.min(A, B) && A + B - C <= Tt) {
      const u = A + B - C, ne = Tt - u;
      let ans, what;
      if (/neither|none of/.test(l)) { ans = ne; what = 'Neither'; } else if (/only/.test(l)) { ans = A - C; what = 'Only A (first set)'; } else if (/at least one|either/.test(l)) { ans = u; what = 'At least one'; } else { ans = C; what = 'Both'; }
      return R('Two-set Venn problem – ' + what, fmt(ans, 4), [note, `n(A or B) = ${fmt(A)} + ${fmt(B)} - ${fmt(C)} = ${fmt(u)}`, `Only A = ${fmt(A - C)}, Only B = ${fmt(B - C)}, Neither = ${fmt(ne)}`]);
    }
  }

  /* average */
  if (/average|mean/.test(l)) {
    const n = numsOf(t.slice(Math.max(0, l.search(/average|mean/))));
    if (n.length >= 2) { const s = sum(n); return R('Average', fmt(s / n.length, 4), [`Numbers: ${n.join(', ')}`, `Sum = ${fmt(s)}, count = ${n.length}`, `Average = ${fmt(s)} / ${n.length} = ${fmt(s / n.length, 4)}`]); }
  }
  return null;
}

/* ---------- OCR engine is loaded only when needed (never blocks the page) ---------- */
function ensureTesseract() {
  return new Promise((resolve, reject) => {
    if (typeof Tesseract !== 'undefined') { resolve(); return; }
    const urls = ['https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js', 'https://unpkg.com/tesseract.js@5.1.1/dist/tesseract.min.js'];
    let i = 0;
    const tryNext = () => {
      if (i >= urls.length) { reject(new Error('Could not download the OCR engine. Check your internet connection.')); return; }
      const s = document.createElement('script'); s.src = urls[i++];
      const timer = setTimeout(() => { s.remove(); tryNext(); }, 15000);
      s.onload = () => { clearTimeout(timer); if (typeof Tesseract !== 'undefined') resolve(); else tryNext(); };
      s.onerror = () => { clearTimeout(timer); s.remove(); tryNext(); };
      document.head.appendChild(s);
    };
    tryNext();
  });
}

/* ---------- image helpers ---------- */
function loadImg(file) {
  return new Promise((res, rej) => { const img = new Image(), u = URL.createObjectURL(file); img.onload = () => { URL.revokeObjectURL(u); res(img); }; img.onerror = () => rej(new Error('Could not read this image.')); img.src = u; });
}
async function preprocess(file) {
  const img = await loadImg(file);
  let sc = Math.min(3, Math.max(1, 1600 / img.width)); if (img.width * sc * img.height * sc > 12e6) sc = Math.sqrt(12e6 / (img.width * img.height));
  const c = document.createElement('canvas'); c.width = Math.round(img.width * sc); c.height = Math.round(img.height * sc);
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
  const d = x.getImageData(0, 0, c.width, c.height), p = d.data;
  for (let i = 0; i < p.length; i += 4) { const g = 0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2], v = Math.max(0, Math.min(255, (g - 128) * 1.5 + 128)); p[i] = p[i + 1] = p[i + 2] = v; }
  x.putImageData(d, 0, 0);
  return new Promise((res) => c.toBlob(res, 'image/png'));
}

const SAMPLES = [
  'Find the angle between the hands of a clock at 4:20.',
  'Find the next number in the series: 2, 6, 12, 20, 30, ?',
  'What day of the week was 15 August 1947?',
  'What is 35% of 640?',
  'The average of 12, 18, 25 and 33 is?',
  'Divide 840 in the ratio 3:4.',
  'In a survey of 500 people, 60% like tea, 50% like coffee and 20% like both. How many like neither?'
];

function SnapSolver() {
  const [file, setFile] = useState(null), [url, setUrl] = useState(''), [text, setText] = useState('');
  const [busy, setBusy] = useState(false), [prog, setProg] = useState(0), [status, setStatus] = useState('');
  const [err, setErr] = useState(''), [res, setRes] = useState(null), [over, setOver] = useState(false);
  const inputRef = useRef();

  const load = (f) => {
    if (!f) return;
    if (!/^image\/(png|jpe?g|webp|bmp|gif)$/i.test(f.type)) { setErr('Please choose an image file (PNG, JPG or WEBP).'); return; }
    if (f.size > 8 * 1024 * 1024) { setErr('That image is larger than 8 MB. Please use a smaller one.'); return; }
    setErr(''); setFile(f); setRes(null); if (url) URL.revokeObjectURL(url); setUrl(URL.createObjectURL(f)); Sound.click();
  };
  useEffect(() => {
    const onPaste = (e) => { const items = e.clipboardData ? [...e.clipboardData.items] : []; const it = items.find((i) => i.type.indexOf('image/') === 0); if (it) load(it.getAsFile()); };
    window.addEventListener('paste', onPaste); return () => window.removeEventListener('paste', onPaste);
  }, [url]);

  const done = (s) => { setRes(s || { none: true }); Store.set('snap_count', Store.get('snap_count', 0) + 1); Stats.save(); if (s) { Sound.ok(); fireConfetti(18); } else Sound.bad(); };

  const runOCR = async () => {
    if (!file) { setErr('Upload an image first.'); return; }
    setBusy(true); setErr(''); setProg(0); setStatus('loading OCR engine (first time only, needs internet)'); setRes(null);
    try {
      await ensureTesseract();
      setStatus('preparing image');
      const blob = await preprocess(file);
      const r = await Tesseract.recognize(blob, 'eng', { logger: (m) => { if (m.status) setStatus(m.status.replace(/_/g, ' ')); if (m.status === 'recognizing text') setProg(Math.round(m.progress * 100)); } });
      const out = (r.data.text || '').trim();
      if (!out) setErr('No text could be read. Try a clearer, closer picture, or type the question in the text box.');
      else { setText(out); done(solveQuestion(out)); }
    } catch (e) { setErr('Could not read the image: ' + (e && e.message ? e.message : 'unknown error')); }
    setBusy(false);
  };
  const solveNow = () => { if (!text.trim()) { setErr('Type or extract a question first.'); return; } setErr(''); done(solveQuestion(text)); };

  return (
    <div>
      <div className="mod-head" style={{ '--c': '#00E5FF' }}><div className="mod-icon">📸</div><div><h1>Snap & Solve</h1><p>Upload, drop or paste (Ctrl+V) a photo of a question, or type the question, and get the answer.</p></div></div>
      <div className="split">
        <div className="card">
          <h3>1️⃣ Add the question image</h3>
          <div className={'drop' + (over ? ' over' : '')} onClick={() => inputRef.current.click()}
            onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); load(e.dataTransfer.files[0]); }}>
            <span className="big">🖼️</span><b>Click, drop or paste an image</b><br /><small>PNG / JPG / WEBP · max 8 MB</small>
            <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => load(e.target.files[0])} />
          </div>
          {url && <div className="preview"><img src={url} alt="Your question" /></div>}
          {busy && <div><div className="ocr-bar"><i style={{ width: prog + '%' }} /></div><p style={{ fontSize: '.82rem', color: 'var(--muted)', marginTop: 6 }}>{status}… {prog}%</p></div>}
          {err && <div className="err shake" key={err}>⚠ {err}</div>}
          <div className="btn-row">
            <button className="btn" disabled={!file || busy} onClick={runOCR}>🔍 Read text & solve</button>
            <button className="btn ghost" disabled={!file} onClick={() => { URL.revokeObjectURL(url); setFile(null); setUrl(''); setText(''); setRes(null); }}>✕ Remove</button>
          </div>
          <div className="warn-box">📌 Tips: crop to just the question, use good light, keep the text straight. Printed text works far better than handwriting.</div>
        </div>

        <div className="card">
          <Field label="2️⃣ Question text (edit if the OCR made mistakes, or type your own question)"><textarea className="big" value={text} onChange={(e) => setText(e.target.value)} placeholder="The text read from your image appears here. You can also type a question directly…" /></Field>
          <div className="btn-row"><button className="btn green" onClick={solveNow}>⚡ Solve</button><button className="btn ghost" onClick={() => { setText(''); setRes(null); }}>Clear</button></div>
          <div className="sample-row">{SAMPLES.map((s, i) => <button key={i} className="btn ghost sm" onClick={() => { setText(s); setRes(null); }}>Sample {i + 1}</button>)}</div>
          {res && !res.none && (
            <div className="answer-card">
              <span className="chip">{res.type}</span>
              <div className="ans-big grad-text">{res.answer}</div>
              <div className="steps stagger" style={{ whiteSpace: 'normal' }}>{res.steps.map((s, i) => <div key={i} style={{ '--i': i, padding: '3px 0' }}>• {s}</div>)}</div>
            </div>
          )}
          {res && res.none && <div className="err shake" key="none">I could not recognise this question type. The solver handles: number series, clock angle / mirror image, calendar day / leap year / days between dates, percentages, percent change, ratio split, averages, two-set Venn, profit/loss and simple arithmetic. Edit the text and try again.</div>}
        </div>
      </div>
    </div>
  );
}