/* ============ utils.jsx (v2) : helpers, progress, sound, quiz engine ============ */
const { useState, useEffect, useMemo, useRef } = React;

const PALETTE = ['#029EFF', '#E62A89', '#55B538', '#FFAA00', '#893A6E', '#FF5A5A', '#00E5FF', '#FFD700'];
const rand = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const pick = (arr) => arr[rand(0, arr.length - 1)];
const shuffle = (arr) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = rand(0, i); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const sum = (a) => a.reduce((x, y) => x + y, 0);
const fmt = (n, d = 2) => (n === null || n === undefined || isNaN(n)) ? '–' : (Number.isInteger(n) ? String(n) : String(+n.toFixed(d)));
const parseNum = (s, signed) => { s = String(s).trim(); const re = signed ? /^-?\d+(\.\d+)?$/ : /^\d+(\.\d+)?$/; return re.test(s) ? Number(s) : NaN; };
const uniqueVals = (n, lo, hi) => { const s = new Set(); while (s.size < n) s.add(rand(lo, hi)); return shuffle([...s]); };
const dKey = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const optionsFrom = (correct, pool, n = 4) => {
  const others = shuffle(pool.filter((x) => x !== correct)).slice(0, n - 1);
  const opts = shuffle([correct, ...others]);
  return { options: opts, answer: opts.indexOf(correct) };
};
const describe = (vals, labels) => {
  const s = [...vals].sort((a, b) => a - b), n = vals.length;
  const med = n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2;
  const mx = Math.max(...vals), mn = Math.min(...vals);
  return { total: sum(vals), mean: sum(vals) / n, median: med, max: mx, min: mn, maxL: labels[vals.indexOf(mx)], minL: labels[vals.indexOf(mn)], range: mx - mn };
};
const copyText = (t) => {
  try { if (navigator.clipboard) return navigator.clipboard.writeText(t); } catch (e) {}
  const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove();
};

/* ---------- seeded random (for the Daily Challenge) ---------- */
function mulberry32(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function withSeed(seed, fn) { const orig = Math.random; Math.random = mulberry32(seed); try { return fn(); } finally { Math.random = orig; } }

/* ---------- storage + progress ---------- */
const Store = {
  get(k, d) { try { const v = localStorage.getItem('logiciq_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('logiciq_' + k, JSON.stringify(v)); } catch (e) {} }
};
const LEVELS = ['Novice', 'Learner', 'Thinker', 'Analyst', 'Strategist', 'Expert', 'Master', 'Grandmaster'];
const Stats = {
  data: Store.get('stats', {}),
  days: Store.get('days', {}),
  listeners: new Set(),
  save() { Store.set('stats', this.data); Store.set('days', this.days); this.listeners.forEach((f) => f()); },
  record(id, ok) {
    const s = this.data[id] || { a: 0, c: 0 };
    s.a++; if (ok) s.c++;
    this.data[id] = s;
    const k = dKey(new Date()); this.days[k] = (this.days[k] || 0) + 1;
    this.save();
  },
  reset() { this.data = {}; this.days = {}; Store.set('badges', null); this.save(); },
  totals() { let a = 0, c = 0; Object.values(this.data).forEach((s) => { a += s.a; c += s.c; }); return { a, c }; },
  streak() {
    let n = 0; const d = new Date();
    if (!this.days[dKey(d)]) d.setDate(d.getDate() - 1);
    while (this.days[dKey(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  },
  level() {
    const t = this.totals(), xp = t.c * 10 + (t.a - t.c) * 2, lv = Math.floor(Math.sqrt(xp / 40)) + 1;
    return { lv, xp, lo: 40 * (lv - 1) * (lv - 1), hi: 40 * lv * lv, name: LEVELS[Math.min(lv - 1, LEVELS.length - 1)] };
  }
};
function useStats() {
  const [, f] = useState(0);
  useEffect(() => { const l = () => f((x) => x + 1); Stats.listeners.add(l); return () => Stats.listeners.delete(l); }, []);
  return Stats;
}

/* ---------- sound + toast ---------- */
const Sound = {
  on: Store.get('sound', true), ctx: null,
  play(freqs, dur = 0.12, type = 'sine') {
    if (!this.on) return;
    try {
      if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      const c = this.ctx; if (c.state === 'suspended') c.resume();
      freqs.forEach((f, i) => {
        const o = c.createOscillator(), g = c.createGain(), t0 = c.currentTime + i * dur;
        o.type = type; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(0.16, t0 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        o.connect(g); g.connect(c.destination); o.start(t0); o.stop(t0 + dur + 0.02);
      });
    } catch (e) {}
  },
  ok() { this.play([660, 880, 1175]); }, bad() { this.play([300, 220], 0.16, 'sawtooth'); },
  click() { this.play([520], 0.05, 'triangle'); }, win() { this.play([523, 659, 784, 1047], 0.13); },
  toggle() { this.on = !this.on; Store.set('sound', this.on); }
};
function toast(msg, icon) {
  let box = document.querySelector('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; document.body.appendChild(box); }
  const d = document.createElement('div'); d.className = 'toast'; d.textContent = (icon || '✨') + '  ' + msg; box.appendChild(d);
  setTimeout(() => d.classList.add('out'), 2800); setTimeout(() => d.remove(), 3400);
}

/* ---------- hooks ---------- */
function useMounted() {
  const [m, setM] = useState(false);
  useEffect(() => { const t = setTimeout(() => setM(true), 40); return () => clearTimeout(t); }, []);
  return m;
}
function useCount(target, ms = 1000) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf, start;
    const step = (t) => { if (!start) start = t; const p = Math.min(1, (t - start) / ms); setV(Math.round(target * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return v;
}
function useTypewriter(text, speed = 45) {
  const [t, setT] = useState('');
  useEffect(() => {
    let i = 0; setT('');
    const id = setInterval(() => { i++; setT(text.slice(0, i)); if (i >= text.length) clearInterval(id); }, speed);
    return () => clearInterval(id);
  }, [text]);
  return t;
}

/* ---------- confetti ---------- */
function fireConfetti(n = 26) {
  for (let i = 0; i < n; i++) {
    const d = document.createElement('i');
    d.className = 'confetti';
    d.style.setProperty('--x', (Math.random() * 2 - 1) * 240 + 'px');
    d.style.setProperty('--y', -(Math.random() * 240 + 80) + 'px');
    d.style.setProperty('--r', Math.random() * 720 + 'deg');
    d.style.background = PALETTE[i % PALETTE.length];
    d.style.left = '50%'; d.style.top = '55%';
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 1300);
  }
}

/* ---------- small UI parts ---------- */
function Field({ label, children }) { return <label className="field"><span>{label}</span>{children}</label>; }
function Stat({ v, l, i = 0 }) { return <div className="stat" style={{ '--i': i }}><div className="stat-v">{v}</div><div className="stat-l">{l}</div></div>; }
function Ring({ pct = 0, size = 64, color = '#029EFF', label }) {
  const r = size / 2 - 6, c = 2 * Math.PI * r;
  const m = useMounted();
  return (
    <svg width={size} height={size} className="ring">
      <circle cx={size / 2} cy={size / 2} r={r} className="ring-bg" />
      <circle cx={size / 2} cy={size / 2} r={r} stroke={color} className="ring-fg" strokeDasharray={c}
        strokeDashoffset={m ? c * (1 - Math.min(100, pct) / 100) : c} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      <text x="50%" y="50%" dy=".35em" textAnchor="middle" className="ring-t">{label !== undefined ? label : Math.round(pct) + '%'}</text>
    </svg>
  );
}
function Tilt({ children, className = '', style, ...rest }) {
  const ref = useRef();
  const mv = (e) => {
    const r = ref.current.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    ref.current.style.transform = `perspective(700px) rotateX(${-y * 9}deg) rotateY(${x * 9}deg) translateY(-5px)`;
  };
  const lv = () => { ref.current.style.transform = ''; };
  return <div ref={ref} className={className} style={style} onMouseMove={mv} onMouseLeave={lv} {...rest}>{children}</div>;
}

function RowsEditor({ rows, setRows, cols, maxRows = 10, minRows = 2, mk }) {
  const upd = (i, k, v) => setRows(rows.map((r, j) => (j === i ? { ...r, [k]: v } : r)));
  return (
    <div>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead><tr>{cols.map((c) => <th key={c.key}>{c.label}</th>)}<th></th></tr></thead>
          <tbody>{rows.map((r, i) => (
            <tr key={i} className="row-in">
              {cols.map((c) => {
                const bad = c.type === 'num' && isNaN(parseNum(r[c.key], c.signed));
                return <td key={c.key}><input className={'cell-in' + (bad ? ' bad' : '')} value={r[c.key]}
                  onChange={(e) => upd(i, c.key, e.target.value)} inputMode={c.type === 'num' ? 'decimal' : 'text'} maxLength={c.type === 'num' ? 8 : 14} /></td>;
              })}
              <td><button className="icon-btn" style={{ width: 32, height: 32 }} disabled={rows.length <= minRows} onClick={() => setRows(rows.filter((_, j) => j !== i))}>✕</button></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <div className="btn-row"><button className="btn ghost sm" disabled={rows.length >= maxRows} onClick={() => setRows([...rows, mk(rows.length)])}>＋ Add row</button></div>
    </div>
  );
}

/* ---------- question engine ---------- */
function evalAnswer(q, sel, val) {
  if (q.options) {
    if (sel === null || sel === undefined) return { error: 'Please select an option first.' };
    return { ok: sel === q.answer };
  }
  const s = String(val).trim();
  if (s === '') return { error: 'Please type your answer before checking.' };
  if (!/^-?\d*\.?\d+$/.test(s)) return { error: 'Invalid input – use digits and an optional decimal point only.' };
  return { ok: Math.abs(parseFloat(s) - q.answer) <= (q.tol === undefined ? 0.01 : q.tol) };
}

function QuestionView({ q, sel, setSel, val, setVal, reveal, ok, err, onEnter }) {
  return (
    <div>
      <div className="q-text">{q.text}</div>
      {q.visual && <div className="q-visual">{q.visual}</div>}
      {q.options ? (
        <div className="opts">{q.options.map((o, i) => {
          let cls = 'opt'; if (sel === i) cls += ' sel';
          if (reveal) { if (i === q.answer) cls += ' correct'; else if (sel === i) cls += ' wrong'; }
          return <button key={i} className={cls} disabled={reveal} onClick={() => { Sound.click(); setSel(i); }} style={{ '--i': i }}>
            <span className="opt-k">{String.fromCharCode(65 + i)}</span><span className="opt-v">{o}</span></button>;
        })}</div>
      ) : (
        <div className="num-in">
          <input type="text" inputMode="decimal" value={val} disabled={reveal} placeholder="Type your answer…"
            onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && onEnter) onEnter(); }} />
          {q.unit && <span className="unit">{q.unit}</span>}
        </div>
      )}
      {err && <div className="err shake" key={err + Math.random()}>⚠ {err}</div>}
      {reveal && (
        <div className={'explain ' + (ok ? 'good' : 'bad')}>
          <b>{ok ? '✔ Correct!' : '✘ Not quite.'}</b>
          {!q.options && !ok && <> Correct answer: <b>{fmt(q.answer)}{q.unit || ''}</b></>}
          <div className="steps">{q.explain}</div>
        </div>
      )}
    </div>
  );
}

function SummaryModal({ sc, onClose, onReset }) {
  const acc = sc.t ? (sc.c / sc.t) * 100 : 0;
  const msg = acc >= 85 ? '🏆 Outstanding! You are a Logic Master.' : acc >= 60 ? '👍 Good going – keep practising!' : '💪 Keep trying – every attempt makes you sharper.';
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>📊 Result Summary</h2>
        <div style={{ margin: '16px 0' }}><Ring pct={acc} size={120} color="#55B538" /></div>
        <div className="stats-grid">
          <Stat v={sc.t} l="Attempted" /><Stat v={sc.c} l="Correct" i={1} /><Stat v={sc.t - sc.c} l="Wrong" i={2} /><Stat v={sc.best} l="Best streak" i={3} />
        </div>
        <p style={{ margin: '10px 0 18px', color: 'var(--muted)' }}>{msg}</p>
        <div className="btn-row" style={{ justifyContent: 'center' }}>
          <button className="btn" onClick={onClose}>Continue</button>
          <button className="btn ghost" onClick={onReset}>Reset session</button>
        </div>
      </div>
    </div>
  );
}

function PracticeEngine({ moduleId, gen }) {
  const [q, setQ] = useState(() => gen());
  const [sel, setSel] = useState(null);
  const [val, setVal] = useState('');
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  const [sc, setSc] = useState({ c: 0, t: 0, st: 0, best: 0 });
  const [done, setDone] = useState(false);
  const check = () => {
    if (res !== null) return;
    const r = evalAnswer(q, sel, val);
    if (r.error) { setErr(r.error); Sound.bad(); return; }
    setErr(''); setRes(r.ok); Stats.record(moduleId, r.ok);
    setSc((s) => { const st = r.ok ? s.st + 1 : 0; return { c: s.c + (r.ok ? 1 : 0), t: s.t + 1, st, best: Math.max(s.best, st) }; });
    if (r.ok) { fireConfetti(); Sound.ok(); } else Sound.bad();
  };
  const next = () => { Sound.click(); setQ(gen()); setSel(null); setVal(''); setRes(null); setErr(''); };
  const enter = () => (res === null ? check() : next());
  const acc = sc.t ? Math.round((sc.c / sc.t) * 100) : 0;
  return (
    <div className="card">
      <div className="eng-head">
        <span className="chip">✅ Score <b>{sc.c}/{sc.t}</b></span>
        <span className={'chip' + (sc.st >= 3 ? ' fire' : '')}>🔥 Streak <b>{sc.st}</b></span>
        <span className="chip">🎯 Accuracy <b>{acc}%</b></span>
      </div>
      <QuestionView q={q} sel={sel} setSel={setSel} val={val} setVal={setVal} reveal={res !== null} ok={res === true} err={err} onEnter={enter} />
      <div className="btn-row">
        {res === null ? <button className="btn" onClick={check}>Check Answer</button> : <button className="btn" onClick={next}>Next Question →</button>}
        {res === null && <button className="btn ghost" onClick={next}>Skip</button>}
        <button className="btn ghost" disabled={sc.t === 0} onClick={() => setDone(true)}>Finish & Summary</button>
      </div>
      {done && <SummaryModal sc={sc} onClose={() => setDone(false)} onReset={() => { setSc({ c: 0, t: 0, st: 0, best: 0 }); setDone(false); next(); }} />}
    </div>
  );
}