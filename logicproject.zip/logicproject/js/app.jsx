/* ============ app.jsx : Logentra – registry, pages, layout ============ */
const MODULES = [
  { id: 'clock', title: 'Clock Problems', icon: '🕒', color: '#029EFF', desc: 'Angles, mirror images, overlaps of clock hands.', Solver: ClockSolver, gen: genClock },
  { id: 'calendar', title: 'Calendar Problems', icon: '📅', color: '#E62A89', desc: 'Day of the week, leap years, date arithmetic.', Solver: CalendarSolver, gen: genCalendar },
  { id: 'pattern', title: 'Figures & Patterns', icon: '🧩', color: '#55B538', desc: 'Number series, letter series and figure rotations.', Solver: PatternSolver, gen: genPattern },
  { id: 'tabular', title: 'Tabular Data', icon: '📋', color: '#FFAA00', desc: 'Read, compare and calculate from tables.', Solver: TabularSolver, gen: genTabular },
  { id: 'bar', title: 'Bar Graph Analysis', icon: '📊', color: '#9A5A8C', desc: 'Compare quantities with single and grouped bars.', Solver: BarSolver, gen: genBar },
  { id: 'pie', title: 'Pie Chart Analysis', icon: '🥧', color: '#FF5A5A', desc: 'Percentages, angles and sector values.', Solver: PieSolver, gen: genPie },
  { id: 'line', title: 'Line Graph Analysis', icon: '📈', color: '#00E5FF', desc: 'Trends, growth rates and averages.', Solver: LineSolver, gen: genLine },
  { id: 'scatter', title: 'Scatter Diagram', icon: '✨', color: '#FFD700', desc: 'Correlation, regression and prediction.', Solver: ScatterSolver, gen: genScatter },
  { id: 'histogram', title: 'Histogram Analysis', icon: '📶', color: '#86CF4A', desc: 'Frequency distributions and grouped statistics.', Solver: HistogramSolver, gen: genHistogram },
  { id: 'caselet', title: 'Caselet DI', icon: '📝', color: '#E36876', desc: 'Word-paragraph data with Venn logic.', Solver: CaseletSolver, gen: genCaselet },
  { id: 'web', title: 'Web-based DI', icon: '🕸', color: '#0A2FFF', desc: 'Radar (web) charts comparing many criteria.', Solver: WebSolver, gen: genWeb },
  { id: 'missing', title: 'Missing Data', icon: '🧮', color: '#F77F27', desc: 'Find unknown cells from totals.', Solver: MissingSolver, gen: genMissing }
];
const GEN = {}; MODULES.forEach((m) => { GEN[m.id] = m.gen; });
const TEAM = [
  { name: 'Vaishnavi Gholap', roll: '241101004', color: '#029EFF' },
  { name: 'Harshvardhan Kale', roll: '241101015', color: '#55B538' },
  { name: 'Samrudhi Kanase', roll: '251102011', color: '#E62A89' },
  { name: 'Dhruv Koli', roll: '241101041', color: '#FFAA00' }
];
const TIPS = ['1/8 = 12.5%, 1/7 = 14.28%, 1/6 = 16.67%', 'Angle between clock hands = |30H − 5.5M|', 'Leap year: divisible by 4, century years by 400', '1% of a pie = 3.6°', 'Growth % = (new − old) ÷ old × 100', 'Mirror image of a clock time = 11:60 − T', 'Fill Venn diagrams from the centre outwards', 'Interpolate between gridlines for exact bar values', 'Mean (grouped) = Σfx ÷ Σf', 'Check units (lakh / crore) before calculating'];
const SYMS = ['∑', 'π', '∞', '√', '%', '≈', '÷', '×', 'Δ', 'θ', '∫', '±'];

function useHash() {
  const get = () => (location.hash || '#/dashboard').replace('#/', '') || 'dashboard';
  const [p, setP] = useState(get());
  useEffect(() => { const f = () => { setP(get()); window.scrollTo(0, 0); }; window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  return [p, (x) => { location.hash = '#/' + x; }];
}
function badgeList(st) {
  const t = st.totals(), acc = t.a ? Math.round((t.c / t.a) * 100) : 0, tried = Object.keys(st.data).length, streak = st.streak();
  return [
    { id: 'first', e: '🚀', n: 'First Step', d: 'Answer 1 question', ok: t.a >= 1 },
    { id: 'sharp', e: '🎯', n: 'Sharp Shooter', d: '80%+ accuracy, 10+ answers', ok: t.a >= 10 && acc >= 80 },
    { id: 'explorer', e: '🧭', n: 'Explorer', d: 'Try 7 modules', ok: tried >= 7 },
    { id: 'master', e: '👑', n: 'Master', d: 'Try all 12 modules', ok: tried >= 12 },
    { id: 'cent', e: '💯', n: 'Centurion', d: 'Answer 100 questions', ok: t.a >= 100 },
    { id: 'fire', e: '🔥', n: 'On Fire', d: '3-day streak', ok: streak >= 3 },
    { id: 'daily', e: '📆', n: 'Daily Hero', d: 'Finish a daily challenge', ok: Store.get('daily_count', 0) >= 1 },
    { id: 'mock', e: '⏱', n: 'Test Taker', d: 'Finish a mock test', ok: Store.get('mocks', []).length >= 1 },
    { id: 'snap', e: '📸', n: 'Snap Solver', d: 'Solve a question from an image', ok: Store.get('snap_count', 0) >= 1 }
  ];
}

/* ---------------- error boundary (shows errors instead of a blank page) ---------------- */
class ErrorBoundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(e) { return { err: e }; }
  componentDidCatch(e, info) { if (window.__showErr) window.__showErr('React error: ' + e.message + '\n' + (info && info.componentStack ? info.componentStack : '')); }
  render() {
    if (this.state.err) {
      return (
        <div className="card" style={{ margin: 20, position: 'relative', zIndex: 5 }}>
          <h2>⚠ Something went wrong</h2>
          <p style={{ margin: '10px 0' }}>{String(this.state.err.message)}</p>
          <div className="btn-row">
            <button className="btn" onClick={() => this.setState({ err: null })}>Try again</button>
            <button className="btn ghost" onClick={() => { try { localStorage.clear(); } catch (e) {} location.reload(); }}>Reset saved data & reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

/* ---------------- module page ---------------- */
function ModulePage({ m }) {
  const [tab, setTab] = useState('learn');
  const S = m.Solver;
  return (
    <div>
      <div className="mod-head" style={{ '--c': m.color }}><div className="mod-icon">{m.icon}</div><div><h1>{m.title}</h1><p>{m.desc}</p></div></div>
      <div className="tabs">{[['learn', '📘 Learn'], ['solver', '🧮 Solver'], ['practice', '🎯 Practice']].map(([id, l]) => <button key={id} className={'tab' + (tab === id ? ' active' : '')} onClick={() => { Sound.click(); setTab(id); }}>{l}</button>)}</div>
      <div key={tab} className="tab-body">
        {tab === 'learn' && <NotesView id={m.id} color={m.color} />}
        {tab === 'solver' && <S />}
        {tab === 'practice' && <PracticeEngine moduleId={m.id} gen={m.gen} />}
      </div>
    </div>
  );
}

/* ---------------- dashboard ---------------- */
function Dashboard({ go }) {
  const st = useStats(), tot = st.totals(), tried = Object.keys(st.data).length, acc = tot.a ? Math.round((tot.c / tot.a) * 100) : 0, streak = st.streak(), lv = st.level();
  const c1 = useCount(tot.a), c2 = useCount(acc), c3 = useCount(streak), c4 = useCount(tried);
  const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const week = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); return { l: names[d.getDay()], v: st.days[dKey(d)] || 0 }; });
  const hour = new Date().getHours(), greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const badges = badgeList(st), daily = Store.get('daily_' + dKey(new Date()), null);
  return (
    <div>
      <div className="hero">
        <h1>{greet}! 👋 Welcome to <span className="grad-text">Logentra</span></h1>
        <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: '.72rem', letterSpacing: '.14em', textTransform: 'uppercase', opacity: 0.8, marginBottom: 8 }}>Created by</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
            {TEAM.map((m, i) => (
              <div key={m.name} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 14px', borderRadius: 14, background: 'rgba(0,0,0,.22)', border: '1px solid rgba(255,255,255,.2)', animation: 'rise .6s both', animationDelay: (i * 120) + 'ms' }}>
                <span style={{ width: 32, height: 32, borderRadius: '50%', display: 'grid', placeItems: 'center', fontWeight: 800, color: '#fff', background: m.color }}>{m.name[0]}</span>
                <span><b style={{ display: 'block', fontSize: '.92rem' }}>{m.name}</b><small style={{ opacity: 0.8 }}>Roll no. {m.roll}</small></span>
              </div>
            ))}
          </div>
        </div>
        <div className="btn-row">
          <button className="btn" onClick={() => go('daily')}>🔥 Daily Challenge</button>
          <button className="btn orange" onClick={() => go('snap')}>📸 Snap & Solve</button>
          <button className="btn ghost" onClick={() => go('mock')}>⏱ Mock Test</button>
        </div>
      </div>
      <div className="ticker"><div className="ticker-track">{[...TIPS, ...TIPS].map((t, i) => <span key={i}><b>💡</b>{t}</span>)}</div></div>
      <div className="stats-grid">
        <Stat v={c1} l="Questions attempted" /><Stat v={c2 + '%'} l="Overall accuracy" i={1} /><Stat v={c3 + ' 🔥'} l="Day streak" i={2} /><Stat v={c4 + ' / 12'} l="Modules explored" i={3} />
      </div>
      <div className="card" style={{ marginBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}><b>🏆 Level {lv.lv} · {lv.name}</b><span style={{ color: 'var(--muted)', fontSize: '.85rem' }}>{lv.xp} / {lv.hi} XP</span></div>
        <div className="xp"><i style={{ width: Math.min(100, ((lv.xp - lv.lo) / (lv.hi - lv.lo)) * 100) + '%' }} /></div>
        <p style={{ color: 'var(--muted)', fontSize: '.8rem', marginTop: 6 }}>Correct answers give 10 XP, wrong answers still give 2 XP for trying.</p>
      </div>
      <div className="split">
        <div className="card"><h3>📅 Last 7 days activity</h3><BarChart labels={week.map((w) => w.l)} series={[{ name: 'Questions', values: week.map((w) => w.v) }]} /></div>
        <div className="stack">
          <div className="card daily-card"><h3>🔥 Today's Daily Challenge</h3>
            {daily ? <p>You scored <b>{daily.score}/5</b> today. Come back tomorrow for 5 new questions!</p> : <p style={{ color: 'var(--muted)' }}>5 questions from random modules – same for every student today. Keep your streak alive!</p>}
            <div className="btn-row"><button className="btn orange" onClick={() => go('daily')}>{daily ? 'View result' : 'Start now'}</button></div></div>
          <div className="card"><h3>🏅 Achievements</h3><div className="badges">{badges.map((b) => <div key={b.id} className={'badge ' + (b.ok ? 'got' : 'locked')}><span className="be">{b.e}</span><b>{b.n}</b><br /><small>{b.d}</small></div>)}</div></div>
        </div>
      </div>
      <h2 style={{ marginTop: 26 }}>🧠 All 12 modules</h2>
      <div className="mod-grid">
        {MODULES.map((m, i) => { const s = st.data[m.id], a = s ? Math.round((s.c / s.a) * 100) : 0;
          return <Tilt key={m.id} className="mod-card" style={{ '--c': m.color, '--i': i }} onClick={() => go(m.id)}>
            <div className="mi">{m.icon}</div><h4>{m.title}</h4><p>{m.desc}</p>
            <div className="bar-prog"><i style={{ width: a + '%' }} /></div>
            <div className="mc-foot"><span>{s ? `${s.c}/${s.a} correct` : 'Not started'}</span><span>{a}%</span></div></Tilt>; })}
      </div>
      <button className="btn ghost sm" onClick={() => { if (confirm('Reset all saved progress?')) Stats.reset(); }}>♻ Reset progress</button>
    </div>
  );
}

/* ---------------- daily challenge ---------------- */
function DailyChallenge() {
  const key = dKey(new Date());
  const qs = useMemo(() => withSeed(hashStr('logentra' + key), () => shuffle(MODULES.map((m) => m.id)).slice(0, 5).map((id) => ({ id, q: GEN[id]() }))), [key]);
  const [done, setDone] = useState(() => Store.get('daily_' + key, null));
  const [idx, setIdx] = useState(0), [sel, setSel] = useState(null), [val, setVal] = useState(''), [res, setRes] = useState(null), [err, setErr] = useState(''), [score, setScore] = useState(0);
  const title = (id) => MODULES.find((m) => m.id === id).title;
  if (done) return (
    <div className="card" style={{ maxWidth: 520, textAlign: 'center' }}>
      <h2>🔥 Daily Challenge complete!</h2>
      <div style={{ margin: '16px 0' }}><Ring pct={(done.score / 5) * 100} size={130} color="#FFAA00" label={done.score + '/5'} /></div>
      <p style={{ color: 'var(--muted)' }}>New questions arrive tomorrow. Meanwhile, keep practising in the modules or try a mock test.</p>
      <p style={{ marginTop: 8 }}>Challenges completed so far: <b>{Store.get('daily_count', 0)}</b></p>
    </div>);
  const cur = qs[idx];
  const check = () => {
    if (res !== null) return;
    const r = evalAnswer(cur.q, sel, val);
    if (r.error) { setErr(r.error); Sound.bad(); return; }
    setErr(''); setRes(r.ok); Stats.record(cur.id, r.ok); if (r.ok) { setScore(score + 1); fireConfetti(); Sound.ok(); } else Sound.bad();
  };
  const next = () => {
    if (idx + 1 >= qs.length) {
      Store.set('daily_' + key, { score }); Store.set('daily_count', Store.get('daily_count', 0) + 1); Stats.save();
      setDone({ score }); Sound.win(); if (score >= 3) fireConfetti(50); return;
    }
    setIdx(idx + 1); setSel(null); setVal(''); setRes(null); setErr(''); Sound.click();
  };
  return (
    <div className="card">
      <div className="eng-head"><span className="chip">🔥 Daily Challenge</span><span className="chip">Question <b>{idx + 1}/5</b></span><span className="chip">{title(cur.id)}</span><span className="chip">Score <b>{score}</b></span></div>
      <div className="progress"><i style={{ width: (idx / 5) * 100 + '%' }} /></div>
      <div key={idx} className="tab-body"><QuestionView q={cur.q} sel={sel} setSel={setSel} val={val} setVal={setVal} reveal={res !== null} ok={res === true} err={err} onEnter={() => (res === null ? check() : next())} /></div>
      <div className="btn-row">{res === null ? <button className="btn" onClick={check}>Check Answer</button> : <button className="btn" onClick={next}>{idx + 1 === 5 ? 'Finish 🎉' : 'Next →'}</button>}</div>
    </div>
  );
}

/* ---------------- mock test ---------------- */
function MockTest() {
  const [phase, setPhase] = useState('setup'), [n, setN] = useState(10), [mins, setMins] = useState(10);
  const [qs, setQs] = useState([]), [idx, setIdx] = useState(0), [ans, setAns] = useState([]);
  const [sel, setSel] = useState(null), [val, setVal] = useState(''), [err, setErr] = useState(''), [left, setLeft] = useState(0), [result, setResult] = useState(null);
  const startRef = useRef(0);
  const hist = Store.get('mocks', []);
  const finish = (list) => {
    list.forEach((a, i) => { if (!a.skipped && qs[i]) Stats.record(qs[i].id, a.ok); });
    const correct = list.filter((a) => a.ok).length, pct = Math.round((correct / qs.length) * 100);
    const h = Store.get('mocks', []); h.push({ d: dKey(new Date()), pct, c: correct, n: qs.length }); Store.set('mocks', h.slice(-10)); Stats.save();
    setResult({ list, time: Math.round((Date.now() - startRef.current) / 1000) }); setPhase('done');
    if (pct >= 60) { fireConfetti(40); Sound.win(); } else Sound.bad();
  };
  const start = () => {
    const ids = shuffle(MODULES.map((m) => m.id)), list = [];
    for (let i = 0; i < n; i++) { const id = ids[i % ids.length]; list.push({ id, q: GEN[id]() }); }
    setQs(shuffle(list)); setAns([]); setIdx(0); setSel(null); setVal(''); setErr(''); setLeft(mins * 60); startRef.current = Date.now(); setPhase('run'); Sound.click();
  };
  useEffect(() => { if (phase !== 'run') return; const id = setInterval(() => setLeft((l) => l - 1), 1000); return () => clearInterval(id); }, [phase]);
  useEffect(() => { if (phase === 'run' && left <= 0) finish(ans); }, [left, phase]);
  const submit = (skip) => {
    let entry;
    if (skip) entry = { skipped: true, ok: false, sel: null, val: '' };
    else { const r = evalAnswer(qs[idx].q, sel, val); if (r.error) { setErr(r.error); return; } entry = { ok: r.ok, sel, val }; }
    const na = [...ans, entry]; setAns(na); setErr(''); setSel(null); setVal(''); Sound.click();
    if (idx + 1 >= qs.length) finish(na); else setIdx(idx + 1);
  };
  const mmss = (s) => `${String(Math.max(0, Math.floor(s / 60))).padStart(2, '0')}:${String(Math.max(0, s % 60)).padStart(2, '0')}`;
  const title = (id) => MODULES.find((m) => m.id === id).title;
  if (phase === 'setup') return (
    <div className="split">
      <div className="card">
        <h2>⏱ Mixed Mock Test</h2><p style={{ color: 'var(--muted)', margin: '8px 0 16px' }}>Random questions from all 12 modules. Answers are revealed at the end.</p>
        <div className="form-row">
          <Field label="Questions"><select value={n} onChange={(e) => setN(+e.target.value)}>{[5, 10, 15, 20].map((x) => <option key={x}>{x}</option>)}</select></Field>
          <Field label="Time limit (minutes)"><select value={mins} onChange={(e) => setMins(+e.target.value)}>{[5, 10, 15, 20, 30].map((x) => <option key={x}>{x}</option>)}</select></Field>
        </div>
        <button className="btn" onClick={start}>🚀 Start test</button>
      </div>
      <div className="card"><h3>📈 Your recent scores</h3>
        {hist.length >= 2 ? <LineChart labels={hist.map((h, i) => '#' + (i + 1))} series={[{ name: 'Score %', values: hist.map((h) => h.pct) }]} unit="%" /> : <p style={{ color: 'var(--muted)' }}>Finish at least two mock tests to see your progress chart here.</p>}
        {hist.length > 0 && <p style={{ marginTop: 8 }}>Best score: <b>{Math.max(...hist.map((h) => h.pct))}%</b> · Tests taken: <b>{hist.length}</b></p>}
      </div>
    </div>);
  if (phase === 'run') return (
    <div className="card">
      <div className="eng-head"><span className="chip">Question <b>{idx + 1}/{qs.length}</b></span><span className="chip">{title(qs[idx].id)}</span><span className={'timer' + (left < 60 ? ' low' : '')}>⏳ {mmss(left)}</span></div>
      <div className="progress"><i style={{ width: (idx / qs.length) * 100 + '%' }} /></div>
      <div key={idx} className="tab-body"><QuestionView q={qs[idx].q} sel={sel} setSel={setSel} val={val} setVal={setVal} reveal={false} err={err} onEnter={() => submit(false)} /></div>
      <div className="btn-row"><button className="btn" onClick={() => submit(false)}>{idx + 1 === qs.length ? 'Submit test' : 'Submit & Next →'}</button><button className="btn ghost" onClick={() => submit(true)}>Skip</button></div>
    </div>);
  const list = result.list, correct = list.filter((a) => a.ok).length, attempted = list.filter((a) => !a.skipped).length, acc = (correct / qs.length) * 100;
  const mods = [...new Set(qs.map((x) => x.id))], per = mods.map((id) => ({ l: title(id).split(' ')[0], c: qs.reduce((s, x, i) => s + (x.id === id && list[i] && list[i].ok ? 1 : 0), 0), t: qs.filter((x) => x.id === id).length }));
  const download = () => {
    const lines = ['Logentra – Mock Test Report', `Date: ${new Date().toLocaleString()}`, `Score: ${correct}/${qs.length} (${Math.round(acc)}%)`, `Attempted: ${attempted}`, `Time taken: ${mmss(result.time)}`, '', 'Module-wise:', ...per.map((p) => `  ${p.l}: ${p.c}/${p.t}`)];
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/plain' })); a.download = 'logentra_report.txt'; a.click();
  };
  return (
    <div className="stack">
      <div className="split">
        <div className="card" style={{ textAlign: 'center' }}><h2>📊 Test Result</h2><div style={{ margin: '16px 0' }}><Ring pct={acc} size={140} color="#55B538" label={`${correct}/${qs.length}`} /></div>
          <div className="stats-grid"><Stat v={Math.round(acc) + '%'} l="Accuracy" /><Stat v={attempted} l="Attempted" i={1} /><Stat v={qs.length - attempted} l="Skipped" i={2} /><Stat v={mmss(result.time)} l="Time taken" i={3} /></div>
          <div className="btn-row" style={{ justifyContent: 'center' }}><button className="btn" onClick={() => setPhase('setup')}>🔁 New test</button><button className="btn ghost" onClick={download}>⬇ Download report</button></div></div>
        <div className="card"><h3>Module-wise performance</h3><BarChart labels={per.map((p) => p.l)} series={[{ name: 'Correct', values: per.map((p) => p.c) }, { name: 'Asked', values: per.map((p) => p.t) }]} /></div>
      </div>
      <div className="card"><h3>🔍 Review answers</h3>
        {qs.map((x, i) => <details key={i}><summary>{list[i] && list[i].skipped ? '⏭' : list[i] && list[i].ok ? '✅' : '❌'} Q{i + 1} · {title(x.id)}</summary>
          <div style={{ marginTop: 12 }}><QuestionView q={x.q} sel={list[i] ? list[i].sel : null} setSel={() => {}} val={list[i] ? list[i].val : ''} setVal={() => {}} reveal ok={!!(list[i] && list[i].ok)} /></div></details>)}
      </div>
    </div>);
}

/* ---------------- formula sheet ---------------- */
function FormulaSheet() {
  const [q, setQ] = useState(''), [mod, setMod] = useState('all');
  const items = useMemo(() => MODULES.flatMap((m) => NOTES[m.id].sections.flatMap((s) => (s.f || []).map((f) => ({ id: m.id, mt: m.title, icon: m.icon, color: m.color, sec: s.t, f })))), []);
  const list = items.filter((x) => (mod === 'all' || x.id === mod) && (x.f + ' ' + x.sec + ' ' + x.mt).toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <div className="mod-head" style={{ '--c': '#FFD700' }}><div className="mod-icon">📐</div><div><h1>Formula Sheet</h1><p>{items.length} formulas from all modules. Click a card to copy it.</p></div></div>
      <div className="card">
        <Field label="Search formulas"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. angle, mean, percentage…" /></Field>
        <div className="chips"><button className={'chip-btn' + (mod === 'all' ? ' on' : '')} onClick={() => setMod('all')}>All</button>
          {MODULES.map((m) => <button key={m.id} className={'chip-btn' + (mod === m.id ? ' on' : '')} onClick={() => setMod(m.id)}>{m.icon} {m.title.split(' ')[0]}</button>)}</div>
        {list.length === 0 && <div className="err">No formula matches your search.</div>}
        <div className="f-grid">{list.map((x, i) => (
          <div key={x.id + i} className="f-card" style={{ '--c': x.color, '--i': Math.min(i, 20) }} onClick={() => { copyText(x.f); toast('Formula copied!', '📋'); Sound.click(); }}>
            <small>{x.icon} {x.mt} · {x.sec}</small><div className="formula">{x.f}</div></div>))}</div>
      </div>
    </div>
  );
}

/* ---------------- about ---------------- */
function About() {
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="card" style={{ textAlign: 'center' }}>
        <h2>Team <span className="grad-text">Logentra</span></h2>
        <p style={{ color: 'var(--muted)' }}>Group project · Logic and Data Interpretation – II</p>
        <div className="team-grid">{TEAM.map((m, i) => <div key={m.name} className="member" style={{ '--c': m.color, '--i': i }}><div className="avatar">{m.name[0]}</div><h4>{m.name}</h4><small>Roll no. {m.roll}</small></div>)}</div>
      </div>
      <div className="card about">
        <h3>About Logentra</h3>
        <p style={{ color: 'var(--muted)', lineHeight: 1.7 }}>Logentra is a Logic & Data Interpretation learning application built with React (loaded through a CDN, no npm), hand-written SVG charts and in-browser OCR.</p>
        <h3 style={{ marginTop: 14 }}>Syllabus coverage (12 / 12 modules)</h3>
        <ul>{MODULES.map((m) => <li key={m.id}><b>{m.icon} {m.title}</b> – {m.desc}</li>)}</ul>
        <h3 style={{ marginTop: 14 }}>Features</h3>
        <ul><li>10 sections of notes per module: formulas, worked examples, shortcuts, practice questions, FAQs and glossary</li><li>Solver and Practice for each module with input validation and step-by-step explanations</li><li>Snap & Solve: upload a question image or type a question and get the answer</li><li>Daily Challenge, timed Mock Test with analysis, formula sheet with search and copy</li><li>XP levels, streaks, badges and sound effects</li><li>Animated bar, pie, donut, line, scatter, histogram, radar and Venn charts</li><li>Dark and light themes with a responsive mobile layout</li></ul>
        <h3 style={{ marginTop: 14 }}>Technology</h3>
        <p style={{ color: 'var(--muted)' }}>React 18 · Babel Standalone · Tesseract.js (OCR) · SVG · CSS animations · Web Audio · localStorage</p>
      </div>
    </div>
  );
}

/* ---------------- app shell ---------------- */
function NavItem({ id, icon, label, page, nav }) {
  return <button className={'nav-item' + (page === id ? ' active' : '')} onClick={() => { Sound.click(); nav(id); }}><span className="nav-ic">{icon}</span>{label}</button>;
}
function Background() {
  const syms = useMemo(() => [...Array(16)].map((_, i) => ({ s: SYMS[i % SYMS.length], l: Math.random() * 100, z: 22 + Math.random() * 40, d: 22 + Math.random() * 26, dl: -Math.random() * 40, c: PALETTE[i % PALETTE.length] })), []);
  return <div className="bg"><i className="blob" /><i className="blob" /><i className="blob" /><i className="blob" />{syms.map((x, i) => <span key={i} className="sym" style={{ left: x.l + '%', fontSize: x.z, animationDuration: x.d + 's', animationDelay: x.dl + 's', color: x.c }}>{x.s}</span>)}</div>;
}

function App() {
  const [theme, setTheme] = useState(() => Store.get('theme', 'dark'));
  const [page, go] = useHash();
  const [menu, setMenu] = useState(false), [q, setQ] = useState(''), [snd, setSnd] = useState(Sound.on);
  const [boot, setBoot] = useState(true), [gone, setGone] = useState(false);
  const glow = useRef();
  const st = useStats(), lv = st.level();
  useEffect(() => { window.__appStarted = true; const b = document.getElementById('boot'); if (b) b.remove(); }, []);
  useEffect(() => { document.documentElement.setAttribute('data-theme', theme); Store.set('theme', theme); }, [theme]);
  useEffect(() => { const a = setTimeout(() => setBoot(false), 1600), b = setTimeout(() => setGone(true), 2300); return () => { clearTimeout(a); clearTimeout(b); }; }, []);
  useEffect(() => {
    const f = (e) => { if (glow.current) { glow.current.style.setProperty('--mx', e.clientX + 'px'); glow.current.style.setProperty('--my', e.clientY + 'px'); } };
    window.addEventListener('mousemove', f); return () => window.removeEventListener('mousemove', f);
  }, []);
  useEffect(() => {
    const blist = badgeList(st), earned = blist.filter((b) => b.ok).map((b) => b.id), prev = Store.get('badges', null);
    if (prev === null) { Store.set('badges', earned); return; }
    const fresh = earned.filter((x) => prev.indexOf(x) < 0);
    if (fresh.length) { Store.set('badges', earned); fresh.forEach((id) => toast('Badge unlocked: ' + blist.find((b) => b.id === id).n, '🏅')); fireConfetti(40); Sound.win(); }
  });
  const mod = MODULES.find((m) => m.id === page), nav = (id) => { go(id); setMenu(false); };
  const list = MODULES.filter((m) => m.title.toLowerCase().includes(q.toLowerCase()));
  const titles = { dashboard: 'Dashboard', daily: 'Daily Challenge', snap: 'Snap & Solve', mock: 'Mock Test', formulas: 'Formula Sheet', about: 'About' };
  const pageTitle = mod ? mod.title : titles[page] || 'Dashboard';
  return (
    <>
      {!gone && <div className={'splash' + (boot ? '' : ' hide')}><div className="splash-in"><div className="splash-logo">🧠</div><h1 className="grad-text">Logentra</h1><p>Logic & Data Interpretation Academy</p><div className="splash-bar"><i /></div></div></div>}
      <Background /><div className="cursor-glow" ref={glow} />
      <div className={'app' + (menu ? ' menu-open' : '')}>
        <aside className="sidebar">
          <div className="brand" onClick={() => nav('dashboard')}><div className="logo">🧠</div><div><b className="grad-text">Logentra</b><small>Logic & Data Interpretation</small></div></div>
          <input className="search" placeholder="🔎 Search modules…" value={q} onChange={(e) => setQ(e.target.value)} />
          <div className="nav-label">Main</div>
          <NavItem id="dashboard" icon="🏠" label="Dashboard" page={page} nav={nav} />
          <NavItem id="daily" icon="🔥" label="Daily Challenge" page={page} nav={nav} />
          <NavItem id="snap" icon="📸" label="Snap & Solve" page={page} nav={nav} />
          <NavItem id="mock" icon="⏱" label="Mock Test" page={page} nav={nav} />
          <NavItem id="formulas" icon="📐" label="Formula Sheet" page={page} nav={nav} />
          <div className="nav-label">Modules</div>
          {list.map((m) => <NavItem key={m.id} id={m.id} icon={m.icon} label={m.title} page={page} nav={nav} />)}
          {list.length === 0 && <p style={{ padding: 10, color: 'var(--muted)', fontSize: '.85rem' }}>No module found.</p>}
          <div className="nav-label">More</div><NavItem id="about" icon="ℹ️" label="About" page={page} nav={nav} />
        </aside>
        {menu && <div className="scrim" onClick={() => setMenu(false)} />}
        <main className="main">
          <header className="topbar">
            <button className="icon-btn hamburger" onClick={() => setMenu(true)}>☰</button>
            <h3 className="grow" style={{ margin: 0 }}>{pageTitle}</h3>
            <span className="lvl-chip">Lv {lv.lv} · {lv.name}</span>
            <button className="icon-btn" title="Sound on/off" onClick={() => { Sound.toggle(); setSnd(Sound.on); Sound.click(); }}>{snd ? '🔊' : '🔇'}</button>
            <button className="icon-btn" title="Toggle theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀️' : '🌙'}</button>
          </header>
          <div key={page} className="page-in">
            {mod ? <ModulePage key={mod.id} m={mod} /> : page === 'daily' ? <DailyChallenge /> : page === 'snap' ? <SnapSolver /> : page === 'mock' ? <MockTest /> : page === 'formulas' ? <FormulaSheet /> : page === 'about' ? <About /> : <Dashboard go={nav} />}
          </div>
        </main>
      </div>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<ErrorBoundary><App /></ErrorBoundary>);